# Accepted-source checkpoint: coordinator disposition, 2026-10-26

This is STEP1 source/research preservation only. No new cleanup repair, pilot, performance qualification, production integration or external publication is selected here.

Canonical source baseline: 0628322e4b48e0efad19cdc32238a622d4aaa7a8.
First accepted delta: telemetry fixture initialization1->10 only; src/io.rs SHA836c8a6ceac0f1e972bf77ab3e54be30333f28e763ff1d0ec2f1bff3b34a599d. Complete31 tests and real80,976,318-byte fixture passed on all3 native hosts.
Second accepted delta: Linux checkpoint-resume repair, runtime26 manifest43a298bb575b724187eea89de6d55176d67992c2ed3f025e78f8e46d90c981cb; physical_lifetime SHA36603ef499aa29234441f28b2095627ba8c93e3a1657a6f35aaa3a3198c4d8e0; focused9 tests/workbound/non-testcompile and independent review accepted. This proves bounded checkpoint recovery improvement, NOT final drainage/timing.
Rejected source must NOT enter accepted crate: isolated27-file candidate01bc6bc93a827c0490e45b712647d70eebd35cc1facbb5f76dbb64ee57c804c3 (cheap ancestor-sync optimization), failed two-call regression and open CWR01/02. Preserve patch/review/results as rejected research.
Current native results:
- Windows older fixture10 pilot functionalPASS,16engine+4checker,H3 publication-before-activation,16.1077172s heldoldreader,H2removed,backlog0,allcleanup<=25.9851ms.
- Mac older fixture10 pilot functional complete with preserved NameError prefix + proof-only continuation,19engine+1checker,16.103821917s oldreader,H2removed/backlog0/fulloraclePASS; cleanup51.227250/52.667042ms misses. Original temporary source mostly missing now; reconstruct from Git and exact delta. Unknown cause; don't claim current tmp copy intact.
- Linux latest accepted checkpoint26 pilot17engine,realH3/16.113507960s oldreader,initial cleanup5batches,final2calls backlog6->8,H2remained,completeoracleUNRUN,7/8cleanup>50ms. CLI058c306ea04c6b06057aa51a0197eead832363482c1c9559b1de6431a5dedf40. Source and734retained files preserved.
- Linux drainage assessment explains6-1+3=8: one actual allocation deletion,3existing oldgeneration metadata paths become selectedgarbage; retirement/persistence consumes callbudget before H2 job; no falseoracle repair selected.
- Rejected optimization per-site witness: redundant root syncs5.489–5.967microseconds vs mandatory file/newnamespace8.7–9.25milliseconds. Its negative result corrects earlier costly-ancestor hypothesis; not a passing repair.
- Windows directory-sync path explicitly reports unsupported, Unix performs sync_all; crosshost timing is not equal durability proof.
Preservation scope: exact source commits+selected source/research evidence, not massive corpora/targets/caches/binaries or whole chats. Never alter prior failed reports or main checkout. No blanket cleanup. Stable Git worktree outside /tmp and source/hash correspondence required. All original datasets/raw originals remain in place where present; record omitted bulk and any missingsolecopies.


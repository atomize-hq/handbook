# File-native database experiment: consolidated inventory and completion path

Date: October 24, 2026, America/Indianapolis.
Coordinator: 01a16f73-5070-7431-868e-b9e0e174b06e.

## Outcome of the audit

All three fresh host audits completed. They found substantial reusable product implementation, native evidence, binaries, fixtures and protected backups. They did not find a complete build/test/pilot result for the final integrated online-maintenance candidate on any host.

The right resumption point is the final engine candidate and the first missing native product results, not completion of every launcher qualification. No source rollback, worktree deletion, corpus reset or new Pro consultation follows from this inventory. This document recommends future execution; the audit authorized no build/test/engine execution.

The experiment is standalone research toward Handbook storage. Finishing it means completing the required evidence and reaching an honest KEEP/ADJUST/PIVOT decision. It does not mean the candidate must pass, nor does it itself authorize production Handbook migration or a public disk-format/API freeze.

## Audit records and source of claims

- [macOS full report](macos-report.md): local report copied byte-for-byte from /private/tmp/file-native-macos-inventory-20261024/report.md.
- [Windows owner return](windows-owner-return.md): complete substantive final response retrieved through read_thread. Original report is C:/Users/spmcc/.codex/visualizations/2026/10/24/01a16fd3-b2c6-7af1-b036-fd72bdba257d/windows-inventory/report.md.
- [Linux full report and handoff](linux-owner-return.md): complete final response carrying REPORT.md and COORDINATOR-HANDOFF.md. Original directory is /tmp/file-native-host-inventory-linux-20261024-01a16fd3 on spenser-linux.

Owners: macOS 01a16fd3-4723-7f62-828a-265fa095e28a; Windows 01a16fd3-b2c6-7af1-b036-fd72bdba257d; Linux 01a16fd3-c1d9-72d0-abc3-73533ad78d2f. All were observed completed/idle. Failed or unavailable cross-chat report delivery was recovered through read_thread; it is not an outstanding audit blocker. Windows reported no actual environment approval pending despite the app's earlier waiting flag.

Host observations and selected raw evidence checks were performed by their owners. The coordinator inspected all three returns, the complete Mac report, the archived product closeout, original matrix checklist, final focused protocol and original experiment brief. The coordinator also independently confirmed that the final candidate and archived closeout have exactly the same incremental-engine subtree:
291bcd9bd6d9f2aab18466e37a5d8e3bbed95237.

## What is authoritative

| Item | Identity and meaning |
| --- | --- |
| Earlier packing core | d70f3864f2888d46d9112213b4a03f8d82745a8e |
| Earlier integrated research/evidence | a0b92fe5dc64269508601dcddf7e2e2ca477e30d |
| Final online-maintenance engine candidate | 0628322e4b48e0efad19cdc32238a622d4aaa7a8 |
| Final imported code freeze | SHA256 464dcf878410def63bd3b04d4f48f17d75418c04262cb4745ebc0e6d5e1de6b3 |
| Final 31-test catalog | SHA256 9306071c419670e5d50049d217978e67361a5167c3cdbace1116f908c7c08e6b |
| Archived experiment closeout | 6b689db5afb589a6967c504200afca24add6fb73 |
| Later Mac harness | 04ea1d7e985e85b8ae49b86c07d7b26fcd8975e0 plus retained dirty/untracked readiness work; not the engine pin |

The archive and final source are on different Git ancestry paths, but contain the identical complete engine subtree. That is a verified correspondence, not an assumption based on commit dates.

Windows verified 30 frozen source/control files. Mac and Linux verified the 25 imported Rust/Cargo/consumer files; the five additional CP4 protocol/document files were outside those imported code sets. These counts describe different scopes, not a source mismatch.

## Host and checkout map

### macOS: Mac / macOS 26.6.1 / arm64 / APFS

Four relevant registered worktrees share /Users/spensermcconnell/__Active_Code/atomize-hq/handbook/.git:

| Location | State / role |
| --- | --- |
| /Users/spensermcconnell/__Active_Code/atomize-hq/handbook | Coordination checkout at 379af4e on feat/handbook-b04-source-review. Untracked handoff/orchestration records. |
| /private/tmp/file-native-mac-launch-recovery-213507 | Harness branch at 04ea1d7e; eleven local commits after archived closeout, five tracked modifications plus substantial untracked readiness work. Preserve. |
| /Users/spensermcconnell/.codex/worktrees/file-native-n-macos-20261019/handbook | Clean N navigation/result worktree at faa9e9d0. |
| /Users/spensermcconnell/.codex/worktrees/file-native-q-macos-20261019/handbook | Clean Q recovery/result worktree at 82520a70. |

Final engine: /private/tmp/file-native-online-macos-20261020/source/final-engine.
Prepared SDK/pilot/oracles: sibling source/pilot-sdk-20261021.
Earlier packing source, native binary and results: /private/tmp/file-native-p-macos-20261020.
Older incremental/prerequisite families under /private/tmp survive partly as receipts, archives or directory skeletons rather than runnable checkouts.

The final online build/target/private-cache directories are absent. This does not establish that ordinary Cargo dependencies are unavailable. P and N native binaries survive and match their recorded hashes. Q's final executable is absent; the remaining binary is a legacy fixture builder. Preserve Q results but do not use that builder as the Q final engine.

### Windows: SPENSERSDESKTOP / native Windows-MSVC / NTFS

The audit found eleven experiment worktrees plus the primary checkout, sharing C:/Users/spmcc/Documents/__Project_Code/handbook/.git, and 23 standalone C:/file-native-* roots.

| Important location | State / role |
| --- | --- |
| C:/Users/spmcc/Documents/__Project_Code/handbook | Primary at 379af4e, 39 untracked groups. |
| C:/Users/spmcc/.codex/worktrees/file-native-online-cp2-20261020/handbook | Clean final engine at 0628322e; active branch is codex/file-native-online-cp3-20261020. Directory name is misleading. |
| C:/Users/spmcc/.codex/worktrees/file-native-online-maintenance-20261020/handbook | Closeout at 6b689db5, eleven untracked later readiness/consultation families. Engine files are intentionally omitted through skip-worktree settings. |
| C:/Users/spmcc/.codex/worktrees/file-native-online-matrix-20261020/handbook | 5bb4d800, three tracked changes and 22 untracked groups containing matrix, decoder/checker and readiness work. Preserve. |
| Other worktrees | Incremental, navigation, CP1, packing, Q-Linux, N-Linux, QNP integration and recovery; full paths/heads in Windows return. |

Final Cargo manifest:
C:/Users/spmcc/.codex/worktrees/file-native-online-cp2-20261020/handbook/docs/research/file-native-incremental-engine-experiment-2026-10-18/Cargo.toml.

Online shared build/evidence: C:/file-native-online-cp1-20261020.
History/matrix: C:/file-native-online-matrix-20261020.
Earlier packing, executable and operational backups: C:/file-native-packing-20261020.
Incremental/history: C:/file-native-incremental-20261018.
Additional publication, followup, navigation, recovery and returned native evidence roots remain.

No unpublished committed tail was found on inspected Windows experiment HEADs relative to locally retained remote refs. Untracked/dirty work is substantial. No fetch established live server state.

### Native Linux: spenser-linux / Manjaro / x86_64 / ext4

The connected host has the expected experiment roots and matching historical platform records. The connection label differs from kernel hostname; no evidence indicates the experiment was audited on an unrelated Linux machine.

Final source: /home/spenser/file-native-online-linux-20261020/source/final-engine.
Earlier online build/evidence: /home/spenser/file-native-online-linux-20261020/{target,evidence}.
Other substantial families:
- /home/spenser/file-native-p-linux-20261020
- /home/spenser/file-native-n-linux-20261019
- /home/spenser/file-native-q-linux-20261019-final
- /home/spenser/file-native-recovery-20261019
- incremental source/build generations for initial, replay, audit, accounting, rootfix and recipe
- prerequisite, source transport and evidence/preservation archives.

No atomize-hq/handbook Git checkout was found in searched roots. These experiments are standalone copied source trees. The similarly named /home/spenser/__Active_code/project-handbook is an unrelated older Spenquatch repository with preserved dirty files. Do not use it to infer experiment ancestry or unpublished state.

## Product implementation and reusable evidence

The final candidate implements the generation-lifetime/online-cleanup, rolling-tail/deferred-eligibility and authenticated paged-index changes. Earlier CP1/CP2/CP3 runs provide focused, version-specific evidence and regression cases; they do not prove the integrated final candidate.

| Evidence family | What can be reused | Limit |
| --- | --- | --- |
| Earlier d70 packing/recovery | Native binaries, strict/packing/recovery cases, source bindings, oracles, operational backups and ordinary extraction cases | Earlier pin only. Unix packing 52 cases; Windows applicability differs. Complete recovery followups include 24 cases/282 events. Do not reopen completed old Mac recovery or all-four B comparisons. |
| N navigation | Final binaries/oracles and focused results; small A/B document-count matrices | N1000 is document count, not H1000 accepted history. N10k incomplete work is outside the online-maintenance experiment's selected non-goals. |
| Q recovery | Original negatives plus successful later native continuations, compatibility/restore/lifetime fixtures | Some current executables are absent or older than their result records. |
| CP1 online cleanup | Fault/ownership/cleanup results, full-oracle checks and earlier binary/source pair | Final source changed afterward. |
| CP2 rolling | Retired/delta/outcome/exclusion progress regressions; build3 had four passed, one filtered | Heavy boundary test excluded. |
| CP3 paged remediation | Build9 had eleven passed, three filtered; A/B conversion/dedup/corruption tests and accounting repairs | Larger structural/heavy tests excluded and subsequent source differs. |
| Earlier Windows CP4 build | Seven binaries match compile-only receipt, including engine f154d60f... | Twenty compiled test functions, zero tests or engine calls executed. Not final 31-test source. |
| Windows diagnostic | Twenty-seven expected outcomes and inspected raw bindings/closure | INCONCLUSIVE_UNREPRODUCED; not final engine qualification. |
| Linux v3 controls | Sixteen interface-control results and retained raw closure | Explicitly no engine case qualified. |
| Mac supervised NORMAL | Actual normal process lifecycle/output/closure evidence | CONTROL_ONLY synthetic; not engine build/test/pilot or forced-stop proof. |

### Valuable retained data

Windows is the main location for authentic scaled histories and long operational backups:
- C:/file-native-online-matrix-20261020/history contains reusable H1002/H10002 cohorts and baseline/oracle records.
- C:/file-native-packing-20261020/packed-operational-backup retains the H101007 archive: 313,275,597 transport bytes; historical verified scope 5,807 entries and 592,458,971 uncompressed bytes, including the expected ledger. Successor backup is separate.
- C:/file-native-recovery-20261019/history-operational-backup retains the earlier large transport/inventory.
- Original protected history stores remain under C:/file-native-incremental-20261018.
- Failed/incomplete preservation prefixes coexist with completed alternatives; use manifests, not filenames, to choose them.

H101007 denotes accepted publication history; 504,833 is the earlier eligible physical-record count, not a second accepted-history length.

Linux preserves earlier P unit and recovery stores in two-roots and three-roots archives after historical reclamation. The earlier real 80,976,318-byte fixture was exercised on an older source; it does not satisfy the final candidate's test. Mac retains small P/N/Q fixtures and build/unit archives; no equivalent large accepted-history cohort was found.

Do not clone these cohorts to every host. Verify the relevant donor's exact identity and accepted history before extending it, reuse appropriate small native fixtures, and restore long history only where that product measurement needs it.

## What remains: ordered completion sequence

### 1. Obtain final-candidate builds and complete unit results on all three native hosts

Use the existing final source locations above. Establish actual toolchain/dependency availability, writable scratch target/fixture locations, retained stdout/stderr/exit status and proportionate stopping/resource control. Preserve older binaries rather than overwriting their evidence.

Build, list and run the complete unfiltered workspace: 31 engine test bodies plus applicable consumers, including the actual 80,976,318-byte boundary fixture on this exact source. A successful compile is not a successful test run. Any compiler, dependency, fixture or test failure is the next concrete issue to diagnose.

No existing final build/test result was discovered on any host. Missing old private Cargo clones do not prove ordinary dependencies are missing.

### 2. Establish a small real online path on every host

Use the retained A/N64/H3 pilot behavior, with at most 37 engine invocations, rather than treating that number as an observation already made.

Required behavior:
- Base representation and a genuinely unmapped accepted tail.
- Distinct real old reader, maintainer and publisher.
- Publication accepted after maintenance capture and before changed physical activation.
- Exact resulting semantic selection and physical target.
- Old reader valid for more than 15 seconds, including cleanup while it is held.
- Correct fresh/current and retained old results.
- After reader release, actual removal of obsolete loose data and independently established drained backlog.
- Complete independent outcome/source/graph/physical verification and bounded process/output closure.

Prepared pilot/adapter code still has stale clocks and unresolved final source/schema/interface bindings. Resolve only those required to execute and observe this behavior. Do not assume an old source-only README's PENDING wording proves final engine support is absent; check the actual final implementation.

### 3. Complete final-pin native correctness and regression coverage

Run the applicable workspace, strict-input, packing, recovery, ordinary shell extraction and new online/paged/lifetime cases on one final source pin across Windows/Linux/macOS. Windows-specific sharing cases run on Windows; applicable skips are explicit.

Reuse existing case IDs and extend cases for new schemas rather than duplicating whole historical suites. Archived planning totals of Windows166/Linux158 are coverage registers to reconcile against final adapters, not passing results or immutable process-count targets. The case-level crosswalk must preserve all required behavior.

Cover held readers through two successors, physical-before-semantic capture, fresh-instance/path-reuse safety, competing maintenance/stale parent selection, cancellation/death, journal/selection/crash boundaries, actual old-container deletion, packets/preparations/snapshots, legacy activation/old-client behavior, mapped corruption and complete negative routes.

Validate final schema support in the independent decoder/checker. Final terminal-conflict ownership/release and quota behavior must work under concurrent offered load; a fake peer or stale schema decoder cannot establish this.

### 4. Complete the original primary-host product matrix

Windows and native Linux are the primary correctness/availability platforms. Mac supplies mandatory final-pin native compatibility/recovery/file-lifetime evidence, not another full copy of every expensive benchmark.

| Family | Required remaining product evidence |
| --- | --- |
| Small A/B | N64/H64, three real publish/compact/reopen cycles with at least sixteen accepted publications per cycle, configurations 1/4/1 publishers and four independent readers, critical crash oracles and old-reader/two-successor schedule. |
| Scaled history | Authentic A/N128 histories near H1k/H10k; use retained H1002/H10002 donors where appropriate; three cycles adding at least 100 accepted publications; one/four publishers and four readers, all accepted outcomes and exact NOOP/conflict accounting. |
| Paced HISTORY | All sixteen planned phases; four readers, ten batches of 1,000 warm queries per reader per phase; 640,000 warm and 640 first observations overall. Separate accepted history from physical activations and retain source-specific pacing semantics. |
| Matched lookup | Exact H1k/H10k/retained long cohort; early/middle/recent/missing/cancelled/lost-reply categories; final frozen plan's fifty fresh starts/category and 500 warm/category, with legacy/paged provenance and complete samples. New process does not mean device-cold. |
| Document controls | A/B at N64/N1000, payload/title operations with/without maintenance; four matched pairs, eight stores, sixteen publications, eight complete H3 oracles in the archived refined plan. |
| Physical activation stress | At least 1,000 actual Windows physical mapping activations with real changed representation, all timing samples and bounded generation/journal state. Small/native64 controls do not substitute. |
| Paged and memory bounds | Touched route/record corruption refuses even with a good loose duplicate; untouched damage discovered by complete audit; every relevant-segment negative proof; complete preselection verification, real cache/construction/transient bounds and record/pack/index/segment limits. |
| Rolling, quota, ownership | Late eligibility, partial cursor holes, permanent exclusions, consolidation/collateral, stale candidates, cancellation/restart, automatic packing benefit/refusal/progress, retained snapshots/packets/readers, authentic reduced quota and eventual drainage. |
| Additional operational coverage | Reconcile the prepared seventy quota/checker controls and thirty-eight context/archive controls with actual final product obligations; run required native cases, including ownership/retirement and real interruption, rather than counting pure controls as results. |
| Long operation and recovery | Complete chosen H101007 representation verification, exact outcomes and current source/navigation, full backup/restore, independent oracles and accepted H101008 successor. Preserve permanent history and mandatory B controls. |
| Cleanup/resource result | Real deletion/census, zero unprotected backlog after two passes once producers/blockers end, retained-data floor and temporary coexistence, all original resource and performance measurements. |

Existing earlier histories are fixtures, not final-candidate results. Critical small crash boundaries, scaled cycles and final restore require complete independent oracles.

### 5. Evaluate and close the experiment

Retain original experimental gates:
- No historical walks/full-index verification/rewrite/delete under global capture/writer exclusion.
- Activation initial p95 <=10ms, exploratory p99 <=25ms, max <=100ms; ordinary p95 <=1.25x matched control and p99 <=1.5x only with adequate samples.
- Zero maintenance-induced frontend timeouts at admitted load; semantic conflict, maintainer contention and resource backpressure reported separately.
- Cleanup <=1,000 candidates or 50ms cooperative batch, with blocking native-call overruns reported honestly.
- Fixed-delta H10k discovery work <=2x H1k and no hidden unchanged-history scans.
- Lookup startup/routing <=64KiB plus <=192KiB index metadata/key; at least 2x affected long-history fresh median improvement; warm tolerance max(20%,0.2ms).
- Preserve 64MiB cache including transients, 64-pack/pack/index/record limits, streaming bookkeeping and host RSS/free-space constraints.
- Automatic packing benefit and the new >=95% replaceable-representation reduction at H>=1k; preserve prior whole-cohort A60.71%/B32.14% failures and B controls.

A missed performance target is a valid experiment finding, not a reason to hide evidence or repeat until lucky. An unexecuted mandatory case means incomplete. If engine repairs change the final pin, rerun affected evidence and make all final native correspondence explicit.

Deliver one exact reviewed research source pin, case coverage/results, raw observations, complete oracles, resource conclusions, preserved failures and KEEP/ADJUST/PIVOT recommendation. Research commit/publication and eventual Handbook product integration follow their applicable authorization; this audit itself does not publish or adopt the engine.

## What must not become another prerequisite campaign

Do not automatically revive expired October21 deadlines, all-nine-profile prefunding, small per-role receipt quotas, private-cache cloning, phase templates or a new owner topology. These were selected execution methods. Existing real defects matter when the chosen route relies on them.

Keep genuine protections: protected evidence/data, 44GiB/5-million-file cumulative human boundary and inside reserve unless later explicitly changed, actual host free-space/RSS constraints, build concurrency two, one active long-history mutation lane, accurate identity/results, practical stopping and honest measurement. Refresh the actual resources needed for the selected workload once; do not turn that into historical accounting reconstruction.

Historical Linux Path.is_junction()/SIGALRM findings do not prove a direct Cargo route is broken. The inspected Linux source did not contain the exact reported failing helper, and repair status remains UNKNOWN for that old route. Likewise current missing Mac rare terminal witnesses do not prove Cargo cannot compile. Functional build/test, sampled-resource qualification and hard all-instants memory bounds remain separate claims.

## Scope and remaining uncertainty

These were bounded host inventories, not exhaustive forensic searches of every disk or hidden path. Mac had an inaccessible daemon directory; Windows used DriveInfo after Get-Volume denial; Linux had no relevant atomize-hq Git graph. No live remote-ref refresh, full dataset census/rehash or full archive validation occurred. Source and selected binary hashes checked today are distinguished in host reports from historical recorded hashes.

All three audits left existing sources, dirty files, data, archives and prior failures intact. The consolidated reports are new coordinator-owned output only. The recommended execution has not begun.


# Windows accepted-source research preservation

This is a byte-preserving, bounded evidence export prepared October26,2026 on
SPENSERSDESKTOP. It contains actual reports, commands, outcomes, complete corrected
pilot event/stream/identity receipts, independent oracle proofs, source/binary
bindings and the sole accepted Windows fixture patch. Historical original paths
in those files are provenance; the evidence bytes needed for these results are
included here rather than represented by temporary paths alone.

Source is baseline0628322e4b48e0efad19cdc32238a622d4aaa7a8 PLUS ONLY telemetry
fixture n1→10. Corrected io.rs SHA256:
836c8a6ceac0f1e972bf77ab3e54be30333f28e763ff1d0ec2f1bff3b34a599d.
No Windows source commit was created. Index/staging is unchanged; all30 expected
files were freshly verified,29 baseline files unchanged, and prior test binaries
freshly rehashed. Canonical Mac owner should apply/verify this same patch once;
Linux accepted checkpoint repair belongs to its separate canonical commit.
Unsuccessful optimization is absent from this source/export.

Durable results:
- tests-pass: corrected full unfiltered no-fail-fast workspace31/31 PASS plus
  actual80,976,318-byte fixture; all consumer/doc targets completed. Source,
  binary hashes, original stdout/stderr and receipts included. Datasets/binaries
  themselves intentionally excluded.
- pilot-pass: native A/N64/H3 PASS,16engine calls+4independent checker processes,
  oldreader16.1077172s, H3accepted before changed activation, actual tail deletion,
  two drainage calls, independent0unprotected/20protected/0excluded backlog,
  full independentH3 oracle, all original waits/EOFs/exit0/Job closure, zero50ms
  cleanup misses in four batches. Full event/stream and oracle receipts included.
  This is functional evidence, not40ms/hardpeak/fullmatrix qualification.
- pilot-failed-history: original one-call H1 init succeeded but native transport
  immediate Job-empty assertion failed. Missing PID31268 birth/image remains
  unknown. Post-kill final emptiness is not spontaneous closure. Original report,
  decisive native/stream/resource evidence and failed transport source included.
- tests-failed-history: original baseline unfiltered30pass/1fixture-setup failure,
  no ignored/filtered tests, heavy real boundary passed. Corrected result does
  not erase this historical failure.

manifest.json records every export path, original provenance path, bytes and
SHA256 (excluding itself). All copies are exact bytes. No store datasets, Cargo
targets/caches, executable binaries, credentials, huge redundant log families,
new test/pilot/cleanup or Git mutation/publication are included/performed.
The complete corrected pilot raw directory was only184634B/120files, so it is
preserved in full; the316315B event file preserves actual ordering and complete
before/after store inventories without copying the store payload itself.

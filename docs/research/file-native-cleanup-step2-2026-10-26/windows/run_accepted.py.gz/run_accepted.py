"""Rebind the existing native Cargo supervisor to clean accepted source; no pilot."""
import hashlib
import json
import os
import pathlib
import re
import subprocess
import sys
import time

OUT = pathlib.Path(__file__).resolve().parent
PRIOR = OUT.parent / 'final062-fixture10-20261025'
ORIGINAL = PRIOR / 'run_stage.py'
WT = pathlib.Path('C:/Users/spmcc/.codex/worktrees/file-native-accepted-checkpoint-20261026/handbook')
REL = 'docs/research/file-native-incremental-engine-experiment-2026-10-18'
SRC = WT / REL
PIN = '38e246500ff60e0d45821ec4de1ed11d886b3091'
TREE = '2ae2705545b8ab361466875379744638ba631bad'
MANIFEST = OUT.parent / 'step1-research-export-20261026/canonical-c2-import/reviewed26-manifest.json'
MANIFEST_SHA = '43a298bb575b724187eea89de6d55176d67992c2ed3f025e78f8e46d90c981cb'
FREEZE = pathlib.Path('C:/Users/spmcc/.codex/visualizations/2026/10/20/01a15b15-3362-7133-b789-1ff556b75d04/cp4-final31-source-freeze-final-v3.json')

def sha(p):
    return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()

def save(name, data):
    (OUT / name).write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')

def git(*args):
    return subprocess.check_output(['git','-C',str(WT),*args], env=dict(os.environ,GIT_OPTIONAL_LOCKS='0'), text=True).strip()

def verify(label):
    assert sha(MANIFEST) == MANIFEST_SHA
    manifest = json.loads(MANIFEST.read_bytes())
    assert len(manifest) == 26
    checks = []
    for row in manifest:
        p = SRC / row['path']
        checks.append(dict(path=row['path'],bytes=p.stat().st_size,sha256=sha(p),matches=p.stat().st_size==row['bytes'] and sha(p)==row['sha256']))
    actual = {p.relative_to(SRC).as_posix() for d in [SRC/'src',SRC/'consumers'] for p in d.rglob('*') if p.is_file()}
    actual |= {p.name for p in SRC.glob('Cargo.*') if p.is_file()}
    assert actual == {r['path'] for r in manifest}
    head = git('rev-parse','HEAD'); tree = git('rev-parse','HEAD^{tree}'); status = git('status','--porcelain=v1','--untracked-files=all')
    index = git('write-tree')
    result = dict(head=head,tree=tree,index_tree=index,git_status=status,manifest_sha256=MANIFEST_SHA,files=checks,all_match=all(r['matches'] for r in checks),when_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
    save(label+'-source.json', result)
    assert head==PIN and tree==TREE and index==TREE and not status and result['all_match']
    assert sha(FREEZE)=='464dcf878410def63bd3b04d4f48f17d75418c04262cb4745ebc0e6d5e1de6b3'
    catalog=json.loads(FREEZE.read_text(encoding='utf-8-sig'))['source_unit_catalog']
    added=re.findall(r'#\[test\]\s*fn\s+(\w+)\s*\(', (SRC/'src/physical_checkpoint_tests.rs').read_text())
    assert len(added)==9
    catalog['accepted_checkpoint_tests']=added
    assert sum(map(len,catalog.values()))==40
    return dict(source_unit_catalog=catalog)

original = ORIGINAL.read_text(encoding='utf-8')
replacements = [('len(names)==31','len(names)==40'),('expected_count=31','expected_count=40'),("'31-test catalog mismatch'","'40-test catalog mismatch'")]
for before,after in replacements:
    assert original.count(before)==1
    original=original.replace(before,after,1)
supervisor=OUT/'native_supervisor.py'
if supervisor.exists():
    assert supervisor.read_text(encoding='utf-8')==original
else:
    supervisor.write_text(original,encoding='utf-8')
scope=dict(original_path=str(ORIGINAL),original_sha256=sha(ORIGINAL),task_copy=str(supervisor),task_copy_sha256=sha(supervisor),literal_rebindings=replacements,global_rebindings=['OUT','WT','SRC','PIN','verify'],native_process_supervision_unchanged=True,resource_limits_unchanged=True,product_source_unchanged=True)
save('adapter-binding.json',scope)
ns=dict(__name__='existing_native_supervisor',__file__=str(supervisor))
exec(compile(original,str(supervisor),'exec'),ns)
ns.update(OUT=OUT,WT=WT,SRC=SRC,PIN=PIN,verify=verify)
ns['run'](sys.argv[1])

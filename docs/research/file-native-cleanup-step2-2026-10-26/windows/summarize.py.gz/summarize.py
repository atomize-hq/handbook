import hashlib,json,os,pathlib,re,subprocess,time
P=pathlib.Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def save(n,v):(P/n).write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
stages={s:json.loads((P/(s+'-result.json')).read_bytes()) for s in ['compile','list','test']}
assert all(r['exit']==0 and not r['stop_reason'] and r['job_empty'] for r in stages.values())
source={name:json.loads((P/(name+'-source.json')).read_bytes()) for name in [s+'-'+w for s in stages for w in ['before','after']]}
assert all(r['head']=='38e246500ff60e0d45821ec4de1ed11d886b3091' and r['tree']==r['index_tree']=='2ae2705545b8ab361466875379744638ba631bad' and r['all_match'] and not r['git_status'] and len(r['files'])==26 for r in source.values())
before=json.loads((P/'test-binaries-before.json').read_bytes())
after=[dict(path=r['path'],bytes=pathlib.Path(r['path']).stat().st_size,sha256=sha(r['path'])) for r in before]
assert before==after
save('test-binaries-after.json',after)
stdout=(P/'logs/test.stdout.log').read_text()
stderr=(P/'logs/test.stderr.log').read_text()
result_blocks=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',stdout)
assert result_blocks==[('40','0','0','0','0')]+[('0','0','0','0','0')]*4
actual_tests=re.findall(r'^test ([^\r\n]+) \.\.\. ok\s*$',stdout,re.M)
catalog=json.loads((P/'catalog-reconciliation.json').read_bytes())
assert len(actual_tests)==40 and sorted(actual_tests)==sorted(catalog['actual_names'])
executed=re.findall(r'Running unittests .*? \((.+?\.exe)\)',stderr)
assert set(executed)=={r['path'] for r in after} and len(executed)==4
roots=list((P/'fixtures').glob('packing-cache-boundary-*'))
assert len(roots)==1
fixture_files=[dict(path=str(f),bytes=f.stat().st_size,sha256=sha(f)) for f in sorted(roots[0].rglob('*')) if f.is_file()]
assert sum(f['bytes'] for f in fixture_files)==80976318
assert len([f for f in fixture_files if f['path'].endswith('.idx') and f['bytes']==13496053])==6
receipts=[line for line in (stdout+'\n'+stderr).splitlines() if line.startswith('cache-boundary-receipt')]
assert len(receipts)==1 and str(roots[0]) in receipts[0]
assert 'packing::tests::loading_indexes_evicts_before_transient_allocation' in actual_tests
boundary=dict(root=str(roots[0]),files=fixture_files,total_bytes=sum(f['bytes'] for f in fixture_files),receipt=receipts,test_passed=True)
save('boundary-fixture.json',boundary)
old=pathlib.Path('C:/Users/spmcc/.codex/worktrees/file-native-online-cp2-20261020/handbook')
env=dict(os.environ,GIT_OPTIONAL_LOCKS='0')
old_head=subprocess.check_output(['git','-C',str(old),'rev-parse','HEAD'],env=env,text=True).strip()
old_status=subprocess.check_output(['git','-C',str(old),'status','--porcelain=v1','--untracked-files=all'],env=env,text=True).splitlines()
rel='docs/research/file-native-incremental-engine-experiment-2026-10-18/src/io.rs'
assert old_head=='0628322e4b48e0efad19cdc32238a622d4aaa7a8' and old_status==[' M '+rel]
assert sha(old/rel)=='836c8a6ceac0f1e972bf77ab3e54be30333f28e763ff1d0ec2f1bff3b34a599d'
bindings=[dict(path=str(p.relative_to(P)),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(P.glob('*.json'))]+[dict(path=str(p.relative_to(P)),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted((P/'logs').glob('*')) if p.is_file()]
save('log-bindings.json',bindings)
receipt=dict(status='PASS_COMPLETE_UNFILTERED_WINDOWS_ACCEPTED38E_FULL40',head=source['test-after']['head'],tree=source['test-after']['tree'],source_manifest_sha256='43a298bb575b724187eea89de6d55176d67992c2ed3f025e78f8e46d90c981cb',source_file_count=26,all_source_before_after_checks_pass=True,final_git_clean=True,toolchain=json.loads((P/'toolchain.json').read_bytes()),stages=stages,passed=40,failed=0,ignored=0,filtered=0,actual_test_names=actual_tests,workspace_result_blocks=result_blocks,executed_binaries=after,binaries_unchanged=True,boundary=boundary,old_dirty_worktree_preserved=dict(path=str(old),head=old_head,status=old_status,io_sha256=sha(old/rel)),pilot_run=False,engine_changes=False,commits_created=False,push=False,hold=True)
save('verification-receipt.json',receipt)
report=f'''# Windows accepted checkpoint: full workspace PASS

Exact clean source HEAD `{receipt['head']}`, tree/index `{receipt['tree']}`. All26 Cargo/Rust/consumer files match accepted manifest `{receipt['source_manifest_sha256']}` before and after compile, catalog and test. This validates the accepted checkpoint repair on native Windows; no pilot or cleanup-drainage qualification ran.

The complete unfiltered release workspace ran once: **40passed,0failed,0ignored,0filtered** (original31 plus all nine accepted checkpoint regressions). Engine main, project consumer, research consumer and doctests also passed. Five successful result blocks and all40 actual names reconcile to the enumerated catalog.

Ordinary existing Cargo1.89.0/rustc1.89.0, locked/offline cache. Fresh output, target, fixtures and temp directories. Commands, controlled environment, toolchain details and complete raw stdout/stderr are retained. Common argv: `cargo test --manifest-path <canonical crate>/Cargo.toml --locked --workspace --release -j2 --target-dir <this output>/target`; compile added `--no-run`; catalog added `-- --list`; complete suite added `--no-fail-fast -- --test-threads=1 --nocapture`.

| Stage | Exit | Supervisor seconds |
| --- | --- | --- |
| Compile |0|{stages['compile']['elapsed_seconds']:.3f}|
| Catalog |0|{stages['list']['elapsed_seconds']:.3f}|
| Full workspace once |0|{stages['test']['elapsed_seconds']:.3f}|

The actual boundary fixture contains six13,496,053-byte indexes and a zero-byte pack: **80,976,318bytes**, re-enumerated and hashed. `packing::tests::loading_indexes_evicts_before_transient_allocation` passed; exact emitted cache/allocation/refusal receipt is in [boundary-fixture.json](boundary-fixture.json). No constructor, count, timing or correctness assertion was changed.

All four executed test binaries are SHA-bound before and after execution and unchanged. Library test binary:4,140,032bytes, SHA256 `{after[0]['sha256']}`. Full bindings: [test-binaries-after.json](test-binaries-after.json). Source-to-binary association is the fresh compile command and six clean source snapshots, followed by exact executed-path matches in Cargo stderr.

Existing native Windows Job supervision was reused. Cargo was created suspended, assigned before resume, with unchanged4GiB job/2GiB test-process commit limits and finite timeout/free-space checks. All stages exited0 with empty Jobs and no resource stop. Compile ended with only positively identified Job-owned MSVC `vctip.exe` telemetry helper; existing supervisor closed it after original Cargo exit and recorded its image. Test/catalog needed no helper closure. Sampled test aggregate RSS{stages['test']['sampled_peak_job_rss']:,}bytes; not40ms monitoring or hard all-instants qualification. Final free space{stages['test']['free_bytes_after']/1024**3:.2f}GiB. Raw file logs were read after all Job-owned processes and inherited file handles closed.

The task-only adapter copied the prior supervisor and rebound clean source/paths plus catalog literals31to40. Native process control/resource limits remained unchanged; bindings retained in [adapter-binding.json](adapter-binding.json). Original dirty CP2/CP3 checkout remains HEAD062 with the sole io.rs fixture edit and original hash. No engine edits, pilot, new commit, push, cleanup or deletion occurred. Holding for coordinator.

Full machine-readable result: [verification-receipt.json](verification-receipt.json).
'''
(P/'report.md').write_text(report,encoding='utf-8')
print(json.dumps(dict(status=receipt['status'],head=receipt['head'],source_manifest=receipt['source_manifest_sha256'],tests=40,boundary_bytes=boundary['total_bytes'],library_binary_sha256=after[0]['sha256'],receipt=str(P/'verification-receipt.json'),receipt_bytes=(P/'verification-receipt.json').stat().st_size,receipt_sha256=sha(P/'verification-receipt.json'),report_sha256=sha(P/'report.md'),pilot=False),indent=2))

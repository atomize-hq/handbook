"""Task-owned ordinary Cargo supervision; never imports experiment modules."""
import ctypes as c
from ctypes import wintypes as w
import hashlib, json, os, pathlib, re, shutil, subprocess, sys, time

OUT = pathlib.Path(__file__).resolve().parent
WT = pathlib.Path('C:/Users/spmcc/.codex/worktrees/file-native-online-cp2-20261020/handbook')
REL = 'docs/research/file-native-incremental-engine-experiment-2026-10-18'
SRC = WT / REL
PIN = '0628322e4b48e0efad19cdc32238a622d4aaa7a8'
FREEZE = pathlib.Path('C:/Users/spmcc/.codex/visualizations/2026/10/20/01a15b15-3362-7133-b789-1ff556b75d04/cp4-final31-source-freeze-final-v3.json')
FREEZE_SHA = '464dcf878410def63bd3b04d4f48f17d75418c04262cb4745ebc0e6d5e1de6b3'
IO_REL = REL+'/src/io.rs'
CORRECTED_IO_SHA = '836c8a6ceac0f1e972bf77ab3e54be30333f28e763ff1d0ec2f1bff3b34a599d'
CARGO = 'C:/Users/spmcc/.cargo/bin/cargo.exe'
GIB = 1024**3
MIB = 1024**2
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def save(name, obj): (OUT/name).write_text(json.dumps(obj, indent=2)+'\n', encoding='utf-8')
def inventory(root):
    size = files = 0
    for base, dirs, names in os.walk(root):
        for name in names:
            size += (pathlib.Path(base)/name).stat().st_size; files += 1
    return dict(bytes=size, files=files)
def verify(label):
    assert sha(FREEZE) == FREEZE_SHA, 'freeze bytes changed'
    freeze = json.loads(FREEZE.read_text(encoding='utf-8-sig'))
    env = dict(os.environ, GIT_OPTIONAL_LOCKS='0')
    head = subprocess.check_output(['git','-C',str(WT),'rev-parse','HEAD'],env=env,text=True).strip()
    status = subprocess.check_output(['git','-C',str(WT),'status','--short'],env=env,text=True)
    checks = []
    for rel, expected in freeze['files'].items():
        p = WT/rel
        baseline=expected.copy()
        if rel==IO_REL: expected={'bytes':21980,'sha256':CORRECTED_IO_SHA}
        checks.append(dict(path=str(p), bytes=p.stat().st_size, sha256=sha(p),
                           baseline_sha256=baseline['sha256'],baseline_unchanged=sha(p)==baseline['sha256'],
                           matches=p.stat().st_size==expected['bytes'] and sha(p)==expected['sha256']))
    result = dict(head=head, git_status=status, freeze_path=str(FREEZE), freeze_sha256=sha(FREEZE),
                  files=checks, all_match=all(x['matches'] for x in checks), when_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
    save(label+'-source.json',result)
    changed=subprocess.check_output(['git','-C',str(WT),'diff','--name-only'],env=env,text=True).splitlines()
    index=subprocess.check_output(['git','-C',str(WT),'diff','--cached','--name-only'],env=env,text=True)
    original=(OUT/'io.rs.baseline').read_bytes()
    before=b'crate::store::Store::init(&root,"A","project",1,false,&mut setup).unwrap();'
    after=b'crate::store::Store::init(&root,"A","project",10,false,&mut setup).unwrap();'
    assert original.count(before)==1 and (WT/IO_REL).read_bytes()==original.replace(before,after,1)
    assert head == PIN and changed==[IO_REL] and not index and result['all_match'], 'source verification failed'
    assert (OUT/'before-index-entry.txt').read_bytes()==(OUT/'after-index-entry.txt').read_bytes()
    result['identity']='baseline0628322e plus telemetry fixture n1-to10 patch; NOT unchanged baseline'
    result['changed_paths']=changed;result['index_changes']=index;result['patch_sha256']=sha(OUT/'telemetry-fixture10.patch')
    save(label+'-source.json',result)
    return freeze

k = c.WinDLL('kernel32',use_last_error=True)
papi = c.WinDLL('psapi',use_last_error=True)
SIZE = c.c_size_t
class IO(c.Structure): _fields_=[(x,c.c_ulonglong) for x in ('ReadOperationCount','WriteOperationCount','OtherOperationCount','ReadTransferCount','WriteTransferCount','OtherTransferCount')]
class BASIC(c.Structure): _fields_=[('PerProcessUserTimeLimit',c.c_longlong),('PerJobUserTimeLimit',c.c_longlong),('LimitFlags',w.DWORD),('MinimumWorkingSetSize',SIZE),('MaximumWorkingSetSize',SIZE),('ActiveProcessLimit',w.DWORD),('Affinity',SIZE),('PriorityClass',w.DWORD),('SchedulingClass',w.DWORD)]
class LIMIT(c.Structure): _fields_=[('BasicLimitInformation',BASIC),('IoInfo',IO),('ProcessMemoryLimit',SIZE),('JobMemoryLimit',SIZE),('PeakProcessMemoryUsed',SIZE),('PeakJobMemoryUsed',SIZE)]
class SA(c.Structure): _fields_=[('nLength',w.DWORD),('lpSecurityDescriptor',w.LPVOID),('bInheritHandle',w.BOOL)]
class START(c.Structure): _fields_=[('cb',w.DWORD),('lpReserved',w.LPWSTR),('lpDesktop',w.LPWSTR),('lpTitle',w.LPWSTR),('dwX',w.DWORD),('dwY',w.DWORD),('dwXSize',w.DWORD),('dwYSize',w.DWORD),('dwXCountChars',w.DWORD),('dwYCountChars',w.DWORD),('dwFillAttribute',w.DWORD),('dwFlags',w.DWORD),('wShowWindow',w.WORD),('cbReserved2',w.WORD),('lpReserved2',w.LPVOID),('hStdInput',w.HANDLE),('hStdOutput',w.HANDLE),('hStdError',w.HANDLE)]
class PI(c.Structure): _fields_=[('hProcess',w.HANDLE),('hThread',w.HANDLE),('dwProcessId',w.DWORD),('dwThreadId',w.DWORD)]
class MEM(c.Structure): _fields_=[('cb',w.DWORD),('PageFaultCount',w.DWORD),('PeakWorkingSetSize',SIZE),('WorkingSetSize',SIZE),('QuotaPeakPagedPoolUsage',SIZE),('QuotaPagedPoolUsage',SIZE),('QuotaPeakNonPagedPoolUsage',SIZE),('QuotaNonPagedPoolUsage',SIZE),('PagefileUsage',SIZE),('PeakPagefileUsage',SIZE)]
def api(name, args, result=w.BOOL):
    f=getattr(k,name);f.argtypes=args;f.restype=result;return f
create_job=api('CreateJobObjectW',[w.LPVOID,w.LPCWSTR],w.HANDLE)
set_job=api('SetInformationJobObject',[w.HANDLE,c.c_int,w.LPVOID,w.DWORD])
query_job=api('QueryInformationJobObject',[w.HANDLE,c.c_int,w.LPVOID,w.DWORD,w.LPVOID])
create_file=api('CreateFileW',[w.LPCWSTR,w.DWORD,w.DWORD,c.POINTER(SA),w.DWORD,w.DWORD,w.HANDLE],w.HANDLE)
create_process=api('CreateProcessW',[w.LPCWSTR,w.LPWSTR,w.LPVOID,w.LPVOID,w.BOOL,w.DWORD,w.LPVOID,w.LPCWSTR,c.POINTER(START),c.POINTER(PI)])
assign=api('AssignProcessToJobObject',[w.HANDLE,w.HANDLE])
resume=api('ResumeThread',[w.HANDLE],w.DWORD)
terminate_job=api('TerminateJobObject',[w.HANDLE,w.UINT])
terminate_process=api('TerminateProcess',[w.HANDLE,w.UINT])
wait=api('WaitForSingleObject',[w.HANDLE,w.DWORD],w.DWORD)
exitcode=api('GetExitCodeProcess',[w.HANDLE,c.POINTER(w.DWORD)])
open_process=api('OpenProcess',[w.DWORD,w.BOOL,w.DWORD],w.HANDLE)
close=api('CloseHandle',[w.HANDLE])
image_name=api('QueryFullProcessImageNameW',[w.HANDLE,w.DWORD,w.LPWSTR,c.POINTER(w.DWORD)])
in_job=api('IsProcessInJob',[w.HANDLE,w.HANDLE,c.POINTER(w.BOOL)])
papi.GetProcessMemoryInfo.argtypes=[w.HANDLE,c.POINTER(MEM),w.DWORD]
papi.GetProcessMemoryInfo.restype=w.BOOL
def checked(value):
    if not value: raise c.WinError(c.get_last_error())
    return value
def members(job):
    buf=c.create_string_buffer(8+512*c.sizeof(SIZE))
    checked(query_job(job,3,buf,len(buf),None))
    assigned,count=(w.DWORD*2).from_buffer(buf)
    assert assigned<=512 and count<=512,'job PID table full'
    return list((SIZE*count).from_buffer(buf,8))
def run(stage):
    freeze=verify(stage+'-before')
    for name in ('target','fixtures','temp','logs'): (OUT/name).mkdir(exist_ok=True)
    args=[CARGO,'test','--manifest-path',str(SRC/'Cargo.toml'),'--locked','--workspace','--release','-j2','--target-dir',str(OUT/'target')]
    if stage=='compile': args+=['--no-run']
    elif stage=='list': args+=['--','--list']
    elif stage=='test':
        catalog=(OUT/'logs/list.stdout.log').read_text(encoding='utf-8',errors='replace')
        names=re.findall(r'^([^\r\n]+): test\s*$',catalog,re.M)
        expected=[n for ns in freeze['source_unit_catalog'].values() for n in ns]
        assert len(names)==40 and sorted(n.rsplit('::',1)[-1] for n in names)==sorted(expected), '40-test catalog mismatch'
        save('catalog-reconciliation.json',dict(actual_names=names,expected_count=40,actual_count=len(names),matches=True))
        args+=['--no-fail-fast','--','--test-threads=1','--nocapture']
    else: raise ValueError(stage)
    result_path=OUT/(stage+'-result.json')
    assert not result_path.exists() and not (OUT/('logs/'+stage+'.stdout.log')).exists(),'no reruns/overwrites'
    env=os.environ.copy()
    controlled={'EXP_PACK_TEST_ROOT':str(OUT/'fixtures'),'TEMP':str(OUT/'temp'),'TMP':str(OUT/'temp'),'TMPDIR':str(OUT/'temp'),'CARGO_INCREMENTAL':'0','CARGO_NET_OFFLINE':'true'}
    env.update(controlled)
    # Do not inherit experiment injections or alternate compiler/cache/target settings.
    removed=[]
    for key in list(env):
        if (key.startswith('EXP_') and key!='EXP_PACK_TEST_ROOT') or key in ('RUSTFLAGS','RUSTDOCFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','RUSTC','RUSTDOC','CARGO_HOME','CARGO_TARGET_DIR','RUST_TEST_THREADS','RUST_TEST_TIME_UNIT','RUST_TEST_TIME_INTEGRATION','RUST_TEST_TIME_DOCTEST'):
            removed.append(key);env.pop(key)
    save(stage+'-command.json',dict(argv=args,cwd=str(SRC),environment_overrides=controlled,removed_environment_names=removed,timeout_seconds=900 if stage!='list' else 120,job_commit_limit_bytes=4*GIB,test_process_commit_limit_bytes=2*GIB if stage=='test' else None))
    sa=SA(c.sizeof(SA),None,True);handles=[];job=None;pi=PI();started=False
    stop_reason=None;peak=0;max_single=0;samples=0;observed_pids=set();max_task_bytes=0;helper_closures=[]
    prior=inventory(OUT.parent/'final-engine-build-tests')
    remaining_task_room=676345051-prior['bytes']
    started_time=time.time();mono=time.monotonic()
    try:
        job=checked(create_job(None,None));limit=LIMIT();limit.BasicLimitInformation.LimitFlags=0x2000|0x200;limit.JobMemoryLimit=4*GIB
        if stage=='test': limit.BasicLimitInformation.LimitFlags|=0x100;limit.ProcessMemoryLimit=2*GIB
        checked(set_job(job,9,c.byref(limit),c.sizeof(limit)))
        for name in ('stdout','stderr'):
            h=checked(create_file(str(OUT/f'logs/{stage}.{name}.log'),0x40000000,3,c.byref(sa),1,0x80,None));handles.append(h)
        hin=checked(create_file('NUL',0x80000000,3,c.byref(sa),3,0x80,None));handles.append(hin)
        si=START();si.cb=c.sizeof(si);si.dwFlags=0x100;si.hStdInput=hin;si.hStdOutput=handles[0];si.hStdError=handles[1]
        block=c.create_unicode_buffer('\0'.join(f'{key}={value}' for key,value in sorted(env.items(),key=lambda x:x[0].upper()))+'\0\0')
        cmd=c.create_unicode_buffer(subprocess.list2cmdline(args))
        checked(create_process(CARGO,cmd,None,None,True,0x4|0x400|0x08000000,block,str(SRC),c.byref(si),c.byref(pi)));started=True
        if not assign(job,pi.hProcess):
            terminate_process(pi.hProcess,125);raise c.WinError(c.get_last_error())
        assert resume(pi.hThread)!=0xFFFFFFFF
        close(pi.hThread);pi.hThread=None
        for h in handles: close(h)
        handles=[]
        with (OUT/f'logs/{stage}.samples.jsonl').open('x',encoding='utf-8') as sample_file:
            last_disk=0
            while True:
                pids=members(job);observed_pids.update(pids)
                rss=0;individual=[]
                for pid in pids:
                    h=open_process(0x1000|0x10,False,pid)
                    if h:
                        mem=MEM();mem.cb=c.sizeof(mem)
                        if papi.GetProcessMemoryInfo(h,c.byref(mem),c.sizeof(mem)):
                            rss+=mem.WorkingSetSize;individual.append([pid,mem.WorkingSetSize])
                        close(h)
                own=open_process(0x1000|0x10,False,os.getpid());own_rss=0
                if own:
                    own_mem=MEM();own_mem.cb=c.sizeof(own_mem)
                    if papi.GetProcessMemoryInfo(own,c.byref(own_mem),c.sizeof(own_mem)): own_rss=own_mem.WorkingSetSize
                    close(own)
                rss+=own_rss
                peak=max(peak,rss);max_single=max([max_single]+[x[1] for x in individual]);samples+=1
                sample_file.write(json.dumps(dict(elapsed=time.monotonic()-mono,pids=pids,rss=rss,supervisor_rss=own_rss,process_rss=individual))+'\n');sample_file.flush()
                if rss>4*GIB: stop_reason='aggregate sampled RSS exceeds4GiB'
                if stage=='test' and any(x[1]>2*GIB for x in individual): stop_reason='test sampled RSS exceeds2GiB'
                if time.monotonic()-mono>(120 if stage=='list' else 900): stop_reason='finite timeout'
                if time.monotonic()-last_disk>1:
                    inv=inventory(OUT);max_task_bytes=max(max_task_bytes,inv['bytes']);last_disk=time.monotonic()
                    if inv['bytes']>remaining_task_room or inv['files']+prior['files']>8000: stop_reason='actual remaining held Windows output/file room exceeded'
                    if shutil.disk_usage(OUT).free<140*GIB: stop_reason='C free space below140GiB'
                if stop_reason: checked(terminate_job(job,124))
                if wait(pi.hProcess,0)==0 and pids and not stop_reason:
                    # MSVC can leave only its task-owned idle telemetry helper behind.
                    retained=[]
                    for pid in pids:
                        h=open_process(0x1000,False,pid)
                        if h:
                            buf=c.create_unicode_buffer(32768);length=w.DWORD(len(buf));inside=w.BOOL()
                            if image_name(h,0,buf,c.byref(length)) and in_job(h,job,c.byref(inside)) and inside.value:
                                retained.append(dict(pid=pid,image=buf.value))
                            close(h)
                    if len(retained)==len(pids) and all(x['image'].lower().endswith('\\vctip.exe') for x in retained):
                        helper_closures+=retained;checked(terminate_job(job,0))
                        save(stage+'-compiler-helper-closure.json',dict(reason='Original Cargo process signaled exited; only exact live Job-owned MSVC telemetry helpers remain',helpers=helper_closures))
                if wait(pi.hProcess,0)==0 and not members(job): break
                time.sleep(.25)
        checked(wait(pi.hProcess,10000)==0)
        code=w.DWORD();checked(exitcode(pi.hProcess,c.byref(code)))
        lim=LIMIT();checked(query_job(job,9,c.byref(lim),c.sizeof(lim),None))
        result=dict(stage=stage,exit=code.value,stop_reason=stop_reason,elapsed_seconds=time.monotonic()-mono,started_epoch=started_time,root_pid=pi.dwProcessId,observed_job_pids=sorted(observed_pids),job_empty=not members(job),sample_count=samples,sampled_peak_job_rss=peak,sampled_peak_process_rss=max_single,job_peak_commit=lim.PeakJobMemoryUsed,supervision='Windows Job kill-on-close; created suspended and assigned before resume; 250ms approximate polling; not40ms/hard-RSS qualification',max_task_bytes_observed=max_task_bytes,final_task_inventory=inventory(OUT),free_bytes_after=shutil.disk_usage(OUT).free)
        result['compiler_helper_closures']=helper_closures;result['retained_previous_work']=prior;result['remaining_task_room_bytes']=remaining_task_room
        save(stage+'-result.json',result);print(json.dumps(result),flush=True)
    except BaseException as error:
        if started and job: terminate_job(job,125);wait(pi.hProcess,10000)
        save(stage+'-supervisor-error.json',dict(error=repr(error),elapsed_seconds=time.monotonic()-mono));raise
    finally:
        for h in handles:close(h)
        if pi.hThread:close(pi.hThread)
        if pi.hProcess:close(pi.hProcess)
        if job:close(job)
        verify(stage+'-after')

if __name__=='__main__': run(sys.argv[1])

# Windows accepted checkpoint: full workspace PASS

Exact clean source HEAD `38e246500ff60e0d45821ec4de1ed11d886b3091`, tree/index `2ae2705545b8ab361466875379744638ba631bad`. All26 Cargo/Rust/consumer files match accepted manifest `43a298bb575b724187eea89de6d55176d67992c2ed3f025e78f8e46d90c981cb` before and after compile, catalog and test. This validates the accepted checkpoint repair on native Windows; no pilot or cleanup-drainage qualification ran.

The complete unfiltered release workspace ran once: **40passed,0failed,0ignored,0filtered** (original31 plus all nine accepted checkpoint regressions). Engine main, project consumer, research consumer and doctests also passed. Five successful result blocks and all40 actual names reconcile to the enumerated catalog.

Ordinary existing Cargo1.89.0/rustc1.89.0, locked/offline cache. Fresh output, target, fixtures and temp directories. Commands, controlled environment, toolchain details and complete raw stdout/stderr are retained. Common argv: `cargo test --manifest-path <canonical crate>/Cargo.toml --locked --workspace --release -j2 --target-dir <this output>/target`; compile added `--no-run`; catalog added `-- --list`; complete suite added `--no-fail-fast -- --test-threads=1 --nocapture`.

| Stage | Exit | Supervisor seconds |
| --- | --- | --- |
| Compile |0|45.891|
| Catalog |0|0.782|
| Full workspace once |0|3.969|

The actual boundary fixture contains six13,496,053-byte indexes and a zero-byte pack: **80,976,318bytes**, re-enumerated and hashed. `packing::tests::loading_indexes_evicts_before_transient_allocation` passed; exact emitted cache/allocation/refusal receipt is in [boundary-fixture.json](boundary-fixture.json). No constructor, count, timing or correctness assertion was changed.

All four executed test binaries are SHA-bound before and after execution and unchanged. Library test binary:4,140,032bytes, SHA256 `b84699e05bd38f6d7861513bba76b11bdbea9ca7c2d3d26ae1e7ce2a6926ca15`. Full bindings: [test-binaries-after.json](test-binaries-after.json). Source-to-binary association is the fresh compile command and six clean source snapshots, followed by exact executed-path matches in Cargo stderr.

Existing native Windows Job supervision was reused. Cargo was created suspended, assigned before resume, with unchanged4GiB job/2GiB test-process commit limits and finite timeout/free-space checks. All stages exited0 with empty Jobs and no resource stop. Compile ended with only positively identified Job-owned MSVC `vctip.exe` telemetry helper; existing supervisor closed it after original Cargo exit and recorded its image. Test/catalog needed no helper closure. Sampled test aggregate RSS163,864,576bytes; not40ms monitoring or hard all-instants qualification. Final free space190.52GiB. Raw file logs were read after all Job-owned processes and inherited file handles closed.

The task-only adapter copied the prior supervisor and rebound clean source/paths plus catalog literals31to40. Native process control/resource limits remained unchanged; bindings retained in [adapter-binding.json](adapter-binding.json). Original dirty CP2/CP3 checkout remains HEAD062 with the sole io.rs fixture edit and original hash. No engine edits, pilot, new commit, push, cleanup or deletion occurred. Holding for coordinator.

Full machine-readable result: [verification-receipt.json](verification-receipt.json).

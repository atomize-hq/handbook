"""Task-owned direct-child subprocess adapter; sampled facts, not qualification."""
import hashlib,json,os,signal,subprocess,threading,time,traceback
from pathlib import Path

def observation(pid=None):
    argv=['/bin/ps']+(['-p',str(pid)] if pid is not None else ['-A'])+['-o','pid=,ppid=,pgid=,rss=,lstart=,stat=']
    r=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=5,text=True)
    rows=[]
    for line in r.stdout.splitlines():
        p=line.split()
        if len(p)!=10:raise RuntimeError('unexpected-native-ps-row')
        rows.append(dict(pid=int(p[0]),ppid=int(p[1]),pgid=int(p[2]),rss_bytes=int(p[3])*1024,birth=' '.join(p[4:9]),state=p[9]))
    valid=r.returncode==0 or (pid is not None and r.returncode==1 and not rows and not r.stderr.strip())
    if not valid:raise RuntimeError('native-ps-unavailable:'+r.stderr)
    return rows

def identity(pid):
    rows=observation(pid)
    return rows[0] if rows else None

def same_birth(a,b):return bool(a and b and a['pid']==b['pid'] and a['birth']==b['birth'])

def group(pgid):return dict(valid=True,members=[r for r in observation() if r['pgid']==pgid])

class Processes:
    def __init__(self,out,sdk,deadline,emit,lock):
        self.out,self.sdk,self.deadline,self.emit,self.lock=out,sdk,deadline,emit,lock
        self.active={};self.all=[];self.failures=[];self.peak=0;self.missing=[]
    def kill(self,c,sig):
        p=c['p']
        if p.returncode is None:
            row=identity(p.pid)
            if same_birth(c['birth'],row) and row['pgid']==p.pid:
                try:os.killpg(p.pid,sig);self.emit(dict(kind='owned-signal',pid=p.pid,signal=sig))
                except ProcessLookupError:pass
    def sample(self,c):
        # Only native direct children launched by this adapter; no escaped-tree claim.
        total=0;facts=[]
        with self.lock:contexts=list(self.active.values())
        for item in contexts:
            row=identity(item['p'].pid)
            if same_birth(item['birth'],row):
                rss=row['rss_bytes'];item['peak']=max(item['peak'],rss);total+=rss
                facts.append(dict(pid=row['pid'],role=item['role'],rss=rss))
                if rss>item['limit']:raise RuntimeError('role-RSS-limit:'+item['role'])
            elif item['p'].poll() is None:self.missing.append(dict(pid=item['p'].pid,reason='native-observation-unavailable'))
        me=identity(os.getpid());total+=me['rss_bytes'] if me else 0
        self.peak=max(self.peak,total)
        self.emit(dict(kind='native-direct-child-sample',aggregate_rss=total,processes=facts,scope='direct children; sampled, not hard peak'))
        if total>3*1024**3:raise RuntimeError('aggregate-RSS-limit')
    def command(self,label,argv,input_bytes,*,role='checker',limit=2*1024**3,timeout=60,env=None,on_started=None,root=None):
        base=self.out/'logs'/label;started=time.monotonic();stop=min(self.deadline,started+timeout)
        if started>=stop:raise RuntimeError('pilot-workload-timeout')
        environment=os.environ.copy();environment.update(dict(TMPDIR=str(self.out/'tmp'),TMP=str(self.out/'tmp'),TEMP=str(self.out/'tmp'),PYTHONDONTWRITEBYTECODE='1',DYLD_LIBRARY_PATH='/opt/homebrew/lib',FILE_NATIVE_ORACLE_RESEARCH=str(self.sdk.parent/'research')));environment.update(env or {})
        base.with_suffix('.input').write_bytes(input_bytes)
        p=subprocess.Popen(argv,cwd=self.out,env=environment,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
        raw=dict(pid=p.pid,parent=os.getpid(),pgid=os.getpgid(p.pid),argv=argv,role=role,root=str(root) if root else None,env_overrides=env or {},start_ns=time.perf_counter_ns())
        c=None;stdout=b'';stderr=b'';failure=None;closures=[];communicated=False
        try:
            birth=identity(p.pid);raw['birth']=birth
            base.with_suffix('.child.json').write_text(json.dumps(raw,indent=2))
            if not birth or birth['ppid']!=os.getpid() or birth['pgid']!=p.pid:raise RuntimeError('original-child-binding')
            c=dict(p=p,birth=birth,role=role,limit=limit,peak=birth['rss_bytes'],root=root,done=False)
            with self.lock:self.active[p.pid]=c;self.all.append(c)
            if not 0<birth['rss_bytes']<=limit:raise RuntimeError('positive-role-RSS-before-input')
            actual=dict(pid=p.pid,positive_rss=birth['rss_bytes'],before_stdin_delivery=True,observed_ns=time.perf_counter_ns(),birth=birth);raw['before_input']=actual
            if on_started:on_started(actual)
            first=True
            while True:
                remaining=stop-time.monotonic()
                if remaining<=0:raise subprocess.TimeoutExpired(argv,timeout)
                try:
                    stdout,stderr=p.communicate(input=input_bytes if first else None,timeout=min(.1,remaining));communicated=True;break
                except subprocess.TimeoutExpired:
                    first=False;self.sample(c)
        except BaseException as exc:failure=dict(error=repr(exc),traceback=traceback.format_exc())
        finally:
            if p.returncode is None:
                if c:self.kill(c,signal.SIGTERM)
                else:p.terminate()
                try:stdout,stderr=p.communicate(timeout=3);communicated=True
                except subprocess.TimeoutExpired:
                    if c:self.kill(c,signal.SIGKILL)
                    else:p.kill()
                    stdout,stderr=p.communicate(timeout=5);communicated=True
            if c:
                c['done']=True
                with self.lock:self.active.pop(p.pid,None)
            for _ in range(2):closures.append(group(p.pid));time.sleep(.015)
            raw.update(exit=p.returncode,seconds=time.monotonic()-started,stdout_eof=communicated and p.stdout.closed,stderr_eof=communicated and p.stderr.closed,stdin_closed=p.stdin.closed,original_handle_waited=p.returncode is not None,stdout_bytes=len(stdout),stderr_bytes=len(stderr),stdout_sha256=hashlib.sha256(stdout).hexdigest(),stderr_sha256=hashlib.sha256(stderr).hexdigest(),exception=failure,closure=closures,sampled_peak_process_rss=c['peak'] if c else None,observation_scope='direct children and owned process group; no escaped-tree or hard-peak qualification')
            for suffix,b in [('.stdout',stdout),('.stderr',stderr)]:base.with_suffix(suffix).write_bytes(b)
            base.with_suffix('.result.json').write_text(json.dumps(raw,indent=2));self.emit(dict(kind='native-command-closed',label=label,**raw))
        if failure is not None:raise RuntimeError('native-command-exception:'+repr(failure))
        if not raw['stdout_eof'] or not raw['stderr_eof'] or not raw['stdin_closed'] or not raw['original_handle_waited']:raise RuntimeError('native-handle-closure-incomplete')
        if c:c['closed']=all(x['valid'] and not x['members'] for x in closures) and raw['stdout_eof'] and raw['stderr_eof'] and raw['stdin_closed'] and raw['original_handle_waited']
        if not all(x['valid'] and not x['members'] for x in closures):raise RuntimeError('native-group-not-closed')
        return raw,stdout,stderr
    def finish(self):
        with self.lock:contexts=list(self.active.values())
        for c in contexts:self.kill(c,signal.SIGTERM)
        if contexts:raise RuntimeError('native-processes-still-active')
        if any(not c.get('closed') for c in self.all):raise RuntimeError('native-command-closure-incomplete')
        return dict(processes_closed=True,handles_closed=True,native_commands=len(self.all),peak_sampled_aggregate_rss=self.peak,missing_rss=self.missing,monitor_failures=self.failures,observation_scope='direct native children and owned groups; no full monitoring qualification')

import sys
sys.dont_write_bytecode=True
import os,json,time,hashlib,subprocess,threading,shutil,tomllib,re,traceback
from pathlib import Path
OUT=Path(__file__).resolve().parent
W=Path('/Users/spensermcconnell/.codex/worktrees/file-native-accepted-checkpoint-20261026/handbook')
CRATE=W/'docs/research/file-native-incremental-engine-experiment-2026-10-18'
MANIFEST=W/'docs/research/file-native-accepted-checkpoint-2026-10-26/linux/accepted-source/manifests/reviewed26-manifest.json'
HOME_CACHE=Path('/private/tmp/file-native-macos-inventory-20261024/final062-fixture10-20261025/cargo-home')
PREP=OUT.parent/'step2-macos-launch-20261026'
sys.path.insert(0,str(PREP))
from native_launch import Processes
for name in ['logs','tmp','fixtures','target']:(OUT/name).mkdir(exist_ok=True)
H=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=W,text=True).strip()
def source():
    assert git('rev-parse','HEAD')=='38e246500ff60e0d45821ec4de1ed11d886b3091'
    assert not git('status','--porcelain')
    rows=json.loads(MANIFEST.read_text())
    for r in rows:
        p=CRATE/r['path'];b=p.read_bytes();assert H(b)==r['sha256'] and len(b)==r['bytes'];assert subprocess.check_output(['git','show','HEAD:'+str(p.relative_to(W))],cwd=W)==b
    return dict(head=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),manifest_sha256=H(MANIFEST.read_bytes()),files=rows)
def write(name,obj):(OUT/name).write_text(json.dumps(obj,indent=2,default=str)+'\n')
def emit(row):
    with LOCK:
        with (OUT/'logs/lifecycle-events.jsonl').open('a') as f:f.write(json.dumps(dict(monotonic_ns=time.monotonic_ns(),**row),default=str)+'\n')
LOCK=threading.RLock();start=time.monotonic();result={};pool=None
try:
    before=source();write('source-before.json',before)
    assert shutil.disk_usage(OUT).free>20*1024**3
    deps=[]
    for r in tomllib.loads((CRATE/'Cargo.lock').read_text())['package']:
        if 'checksum' not in r:continue
        paths=list((HOME_CACHE/'registry/cache').glob('*/'+r['name']+'-'+r['version']+'.crate'));assert len(paths)==1 and H(paths[0].read_bytes())==r['checksum']
        deps.append(dict(name=r['name'],version=r['version'],sha256=r['checksum'],archive=str(paths[0])))
    assert len(deps)==45;write('dependencies.json',deps)
    tools={}
    for name,args in {'cargo':['/Users/spensermcconnell/.cargo/bin/cargo','--version'],'rustc':['/Users/spensermcconnell/.cargo/bin/rustc','--version','--verbose'],'cc':['/usr/bin/cc','--version'],'macos':['/usr/bin/sw_vers'],'arch':['/usr/bin/uname','-m']}.items():
        r=subprocess.run(args,capture_output=True,text=True,check=True);tools[name]=dict(argv=args,stdout=r.stdout,stderr=r.stderr)
    write('toolchain.json',tools)
    env=dict(CARGO_HOME=str(HOME_CACHE),CARGO_NET_OFFLINE='true',CARGO_INCREMENTAL='0',EXP_PACK_TEST_ROOT=str(OUT/'fixtures'),TMPDIR=str(OUT/'tmp'),TMP=str(OUT/'tmp'),TEMP=str(OUT/'tmp'),PYTHONDONTWRITEBYTECODE='1')
    write('environment.json',dict(overrides=env,inherited_names_used=['PATH','HOME','RUSTUP_HOME','DEVELOPER_DIR','SDKROOT'],inherited_values={n:os.environ.get(n) for n in ['PATH','RUSTUP_HOME','DEVELOPER_DIR','SDKROOT']}))
    pool=Processes(OUT,PREP/'sdk-copy/sdk',start+1800,emit,LOCK)
    cargo='/Users/spensermcconnell/.cargo/bin/cargo';common=['--manifest-path',str(CRATE/'Cargo.toml'),'--locked','--offline','--release','--workspace','-j2','--target-dir',str(OUT/'target')]
    for mode,args in [('build',[cargo,'build',*common]),('test',[cargo,'test',*common,'--no-fail-fast','--','--test-threads=1','--nocapture'])]:
        write(mode+'-command.json',dict(argv=args,cwd=str(OUT),source=before['head'],env=env,timeout_seconds=1800,fixture_root=str(OUT/'fixtures'),filters=[],qualification='ordinary native correctness only; not pilot or monitoring qualification'))
        print('START',mode,flush=True)
        r,o,e=pool.command(mode,args,b'',role='cargo-'+mode,timeout=1800,env=env)
        write(mode+'-result.json',dict(**r,owned_tree_closed=all(v['valid'] and not v['members'] for v in r['closure']),scope='original native child wait/EOF and owned process group'))
        assert r['exit']==0,(mode,r['exit'],e.decode(errors='replace')[-2500:])
        result[mode]=dict(exit=r['exit'],seconds=r['seconds'],stdout_sha256=r['stdout_sha256'],stderr_sha256=r['stderr_sha256'])
        print('DONE',mode,r['seconds'],flush=True)
    stdout=(OUT/'logs/test.stdout').read_text();stderr=(OUT/'logs/test.stderr').read_text()
    counts=[tuple(map(int,m)) for m in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',stdout)]
    names=re.findall(r'^test ([A-Za-z0-9_:]+) \.\.\. ok$',stdout,re.M)
    assert sum(v[0] for v in counts)==40 and all(v[1:]==(0,0,0,0) for v in counts),(counts,len(names))
    assert len(names)==40 and len(set(names))==40
    write('actual-tests.json',dict(names=names,summary_rows=counts,passed=40,failed=0,ignored=0,filtered=0))
    boundary=list((OUT/'fixtures').glob('packing-cache-boundary-*'));assert len(boundary)==1
    files=[dict(path=str(f.relative_to(OUT)),bytes=f.stat().st_size,sha256=H(f.read_bytes())) for f in sorted(boundary[0].rglob('*')) if f.is_file()]
    assert sum(r['bytes'] for r in files)==80976318,sum(r['bytes'] for r in files)
    assert 'extra_fixture_bytes=0' in stderr and 'cache-boundary-receipt' in stderr
    write('boundary-evidence.json',dict(root=str(boundary[0]),actual_bytes=sum(r['bytes'] for r in files),files=files,receipt_lines=[l for l in stderr.splitlines() if 'cache-boundary-receipt' in l]))
    binaries=[]
    for f in sorted((OUT/'target/release').rglob('*')):
        if f.is_file() and os.access(f,os.X_OK):
            with f.open('rb') as stream:magic=stream.read(4)
            if magic in [b'\xcf\xfa\xed\xfe',b'\xfe\xed\xfa\xcf',b'\xca\xfe\xba\xbe']:
                binaries.append(dict(path=str(f),bytes=f.stat().st_size,sha256=H(f.read_bytes())))
    assert binaries;write('binary-bindings.json',dict(source_commit=before['head'],manifest_sha256=before['manifest_sha256'],cargo_lock_sha256=H((CRATE/'Cargo.lock').read_bytes()),fresh_target=True,binaries=binaries))
    after=source();assert after==before;write('source-after.json',after)
    result.update(status='PASS',source_head=before['head'],source_manifest_sha256=before['manifest_sha256'],passed=40,failed=0,ignored=0,filtered=0,real_boundary_bytes=80976318,free_bytes_after=shutil.disk_usage(OUT).free,native_closure=pool.finish(),elapsed_seconds=time.monotonic()-start,pilot_run=False)
except BaseException as exc:
    result.update(status='FAIL',error=repr(exc),traceback=traceback.format_exc(),elapsed_seconds=time.monotonic()-start)
    if pool:
        try:result['native_closure']=pool.finish()
        except BaseException as close:result['closure_error']=repr(close)
finally:
    write('result.json',result);print(json.dumps(result,indent=2,default=str),flush=True)
sys.exit(0 if result.get('status')=='PASS' else 1)

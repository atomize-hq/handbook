# Exact retained packet

Sources are in docs/. Ordered inputs, exact paths, hashes, omissions and recipe are in packet/provenance.json.

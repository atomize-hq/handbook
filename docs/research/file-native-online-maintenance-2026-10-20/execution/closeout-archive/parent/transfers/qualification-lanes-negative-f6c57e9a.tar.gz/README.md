# Private qualification lane source packet

SOURCE ONLY. Neither import, compile, this README nor claim022 is a RUN GO.
No Rust, corpus, engine, restore, native process, control execution or Git work is
authorized by this packet. Parent alone owns staging and ledger expiry.

Exactly eight flat files share 131072 bytes: long 49152/2, history 49152/1,
controls 32768/5. Per-file caps are in the registered 022-024 source budget.
No cache/temp ninth file. Check flat names, no links and all source caps before
writes; reserve other groups in full. Compile in memory only. History is separately owned.

Entrypoints run_long(host,config), legacy_restore(host,config) and
run_history(host,config) use one LaneHost. Pure validation hooks are in source.

LaneHost contract
-----------------

authorize(config,lane) returns positive same-final-pin bound GO. poll() is a FAST
deadline/cancel/RSS/identity check returning live:true and receipt_sha256; it must
not do a full-root census per 64KiB. checkpoint(label,reserves) performs fresh
whole phase admission and returns go:true, receipt_sha256 and for long
no_other_semantic_writer:true. record(label,value,category,max_bytes) accepts raw
bytes from long/legacy and the history owner's documented dict calls; the
reviewed host encodes dicts once, enforces exclusive admitted paths and all byte/
file/category caps BEFORE writing, and returns absolute path/bytes/sha256.
drain(label) proves owned children/IO/handles gone with receipt_sha256. The outer
QPC harness must separately prove two empty Job polls after the host exits.

invoke(spec) accepts ONLY reviewed pinned engine JSON or Python executable/
script/argv plus transitive source closure. long's lane-invoke-v1 proposal
requires authentic raw stdout/output references, separate engine_ns and
spawn_total_ns, same final pin/binary/oracle SHA, budget and closure receipt SHAs.
Engine stdin is withheld until contained. Argument-only Python requires a
reviewed owned startup gate BEFORE SELECTED reads or corpus writes.
Exact invoke/v5-R1/cleanup fields and real ceiling enforcement remain parent
review gates before runtime.

host.harness is the exact shared Harness; history requires released
history-native-v1 bindings/preflight/adopt/lookup/phase/release_definitive_conflicts.
No private Driver fork or h.verify shortcut for the long source.

Long ordering and retention
---------------------------

One F09 quarantine from the authenticated old archive. Old inventory is DFS:
view/navigation/groups/root.yaml precedes view/navigation.yaml. The adapter
preserves authenticated stream order; f8d StrictGzipReader/path/hash utilities
are reused unchanged. Only postrestore inventory is globally sorted. No claim
of old empty directories. Root lock exclusions are finite; physical-pins/*.lock
are durable data. No giant compressed pre-copy or archive mutation.

Same final candidate: 50 fresh +500 warm per six exact IDs in legacy first,
convert force/cleanup:false with explicit 320MiB reserve, full independent v5-R1
oracle, then matched paged samples before cleanup. Cleanup has an explicit
batch bound, never generic default160. Full postcleanup oracle+census; unchanged
f8d pipe/restore with M/stream 2MiB/12 inside M 8MiB/40; full restored oracle;
one frozen accepted successor on D only; resolve; full post-successor oracle
against top-level selected/permanent_digest/publications baseline; S rehashed.

F11 676345051/8000 stays through successor+oracle. Parent alone may expire F14
after reaping/full oracle/census. F12 evidence allocation is pending; all output
needs source bounds. Optional forecast releases remain parent decisions.

Pure controls never auto-run or qualify native behavior. Runtime needs finite
RUN GO and separate archive-writer fixtures. Example stays false/null.
Manifest excludes itself. Structured standard grants no migration authority.
Incident: README briefly4310B exceeded4096B; group/whole caps stayed within.


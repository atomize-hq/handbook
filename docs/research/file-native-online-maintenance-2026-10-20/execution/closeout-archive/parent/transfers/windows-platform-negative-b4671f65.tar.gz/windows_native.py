"""Windows HANDLE and overlapped-pipe provider. Constructor alone loads Win32.

No Jobs are created here. Each Popen child starts suspended inside the inherited
accepted QPC Job. Membership is checked against the caller's actual current Job
PID list AND retained creation-time-bound native handles; any-Job alone is unused.
"""
import ctypes as c
from ctypes import wintypes as w
import os
from pathlib import Path
import threading
import time
import uuid
from windows_deadlines import need, strict
from windows_growth import file_hash, regular_read

PIPE_BYTES = 65536


class Overlapped(c.Structure):
    _fields_ = [("Internal",c.c_size_t),("InternalHigh",c.c_size_t),
                ("Offset",w.DWORD),("OffsetHigh",w.DWORD),("hEvent",w.HANDLE)]


class Security(c.Structure):
    _fields_ = [("nLength",w.DWORD),("lpSecurityDescriptor",c.c_void_p),
                ("bInheritHandle",w.BOOL)]


class Memory(c.Structure):
    _fields_ = [("cb",w.DWORD),("faults",w.DWORD)]+[
        (name,c.c_size_t) for name in ("peak","rss","peakpage","page","peaknon","non","pagefile","peakfile")]


class Native:
    def __init__(self, owner):
        need(os.name == "nt" and __debug__, "native-windows-unoptimized-required")
        self.K = c.WinDLL("kernel32",use_last_error=True)
        self.PS = c.WinDLL("psapi",use_last_error=True)
        self.NT = c.WinDLL("ntdll",use_last_error=True)
        K=self.K
        declarations = {
          "CloseHandle":([w.HANDLE],w.BOOL),
          "GetCurrentProcess":([],w.HANDLE),
          "GetProcessId":([w.HANDLE],w.DWORD),
          "OpenProcess":([w.DWORD,w.BOOL,w.DWORD],w.HANDLE),
          "GetProcessTimes":([w.HANDLE]+[c.POINTER(w.FILETIME)]*4,w.BOOL),
          "QueryFullProcessImageNameW":([w.HANDLE,w.DWORD,w.LPWSTR,c.POINTER(w.DWORD)],w.BOOL),
          "DuplicateHandle":([w.HANDLE,w.HANDLE,w.HANDLE,c.POINTER(w.HANDLE),w.DWORD,w.BOOL,w.DWORD],w.BOOL),
          "QueryInformationJobObject":([w.HANDLE,c.c_int,c.c_void_p,w.DWORD,c.POINTER(w.DWORD)],w.BOOL),
          "TerminateProcess":([w.HANDLE,w.UINT],w.BOOL),
          "WaitForSingleObject":([w.HANDLE,w.DWORD],w.DWORD),
          "GetExitCodeProcess":([w.HANDLE,c.POINTER(w.DWORD)],w.BOOL),
          "CreateNamedPipeW":([w.LPCWSTR,w.DWORD,w.DWORD,w.DWORD,w.DWORD,w.DWORD,w.DWORD,c.c_void_p],w.HANDLE),
          "CreateFileW":([w.LPCWSTR,w.DWORD,w.DWORD,c.POINTER(Security),w.DWORD,w.DWORD,w.HANDLE],w.HANDLE),
          "ConnectNamedPipe":([w.HANDLE,c.POINTER(Overlapped)],w.BOOL),
          "CreateEventW":([c.c_void_p,w.BOOL,w.BOOL,w.LPCWSTR],w.HANDLE),
          "ResetEvent":([w.HANDLE],w.BOOL),
          "ReadFile":([w.HANDLE,c.c_void_p,w.DWORD,c.POINTER(w.DWORD),c.POINTER(Overlapped)],w.BOOL),
          "WriteFile":([w.HANDLE,c.c_void_p,w.DWORD,c.POINTER(w.DWORD),c.POINTER(Overlapped)],w.BOOL),
          "GetOverlappedResult":([w.HANDLE,c.POINTER(Overlapped),c.POINTER(w.DWORD),w.BOOL],w.BOOL),
          "CancelIoEx":([w.HANDLE,c.POINTER(Overlapped)],w.BOOL),
        }
        for name,(args,result) in declarations.items():
            fn=getattr(K,name);fn.argtypes=args;fn.restype=result
        self.PS.GetProcessMemoryInfo.argtypes=[w.HANDLE,c.POINTER(Memory),w.DWORD]
        self.PS.GetProcessMemoryInfo.restype=w.BOOL
        self.NT.NtResumeProcess.argtypes=[w.HANDLE]
        self.NT.NtResumeProcess.restype=c.c_long
        self.owner = dict(owner)
        self.lock = threading.RLock()
        self.kept_pipes = []
        self.stage = K.OpenProcess(0x100000|0x1000,False,owner["job_root_pid"])
        need(self.stage and self.creation(self.stage) == owner["job_root_creation_time"],
             "retained-exact-stage-native-handle")
        need(self.stage_live(), "live-owned-current-Job-stage")

    def error(self):
        return c.WinError(c.get_last_error())

    def creation(self, handle):
        values=[w.FILETIME() for _ in range(4)]
        if not self.K.GetProcessTimes(handle,*(c.byref(x) for x in values)):
            raise self.error()
        return values[0].dwHighDateTime*2**32+values[0].dwLowDateTime

    def members(self):
        # Bounded allocation, failure/truncation never becomes an empty list.
        count=4096
        raw=c.create_string_buffer(8+count*c.sizeof(c.c_size_t))
        returned=w.DWORD()
        need(self.K.QueryInformationJobObject(None,3,raw,len(raw),c.byref(returned)),
             "current-Job-native-query")
        assigned,listed=c.cast(raw,c.POINTER(w.DWORD))[:2]
        need(0 < assigned <= listed <= count, "complete-current-Job-members")
        values=(c.c_size_t*listed).from_buffer(raw,8)
        return set(values)

    def stage_live(self):
        return (self.K.WaitForSingleObject(self.stage,0) == 258
                and self.creation(self.stage) == self.owner["job_root_creation_time"]
                and {os.getpid(),self.owner["job_root_pid"]} <= self.members())

    def capture(self, process, executable, expected_sha):
        handle=w.HANDLE()
        current=self.K.GetCurrentProcess()
        need(self.K.DuplicateHandle(current,w.HANDLE(process._handle),current,
             c.byref(handle),0,False,2), "duplicate-owned-child-handle")
        try:
            pid=self.K.GetProcessId(handle)
            need(pid == process.pid and self.stage_live(), "Popen-child-native-identity")
            state=dict(handle=handle,pid=pid,creation_time=self.creation(handle),
                       image=str(Path(executable).resolve()), executable_sha256=expected_sha,closed=False)
            self.identity(state)
            need(file_hash(executable) == expected_sha, "native-image-source-hash")
            return state
        except BaseException:
            self.K.CloseHandle(handle)
            raise

    def identity(self, state, live=True):
        need(not state["closed"] and self.K.GetProcessId(state["handle"]) == state["pid"]
             and self.creation(state["handle"]) == state["creation_time"],
             "stable-native-HANDLE-creation-identity")
        if live:
            need(self.K.WaitForSingleObject(state["handle"],0) == 258, "owned-child-not-live")
            need(self.stage_live() and state["pid"] in self.members(), "same-current-Job-required")
            size=w.DWORD(32768);text=c.create_unicode_buffer(size.value)
            need(self.K.QueryFullProcessImageNameW(state["handle"],0,text,c.byref(size)),
                 "native-image-path-query")
            need(os.path.normcase(text.value) == os.path.normcase(state["image"]),
                 "actual-native-image-path")
        return dict(pid=state["pid"],creation_time=state["creation_time"],
                    same_job=True if live else None,handle_identity_verified=True)

    def memory(self, state):
        self.identity(state)
        row=Memory();row.cb=c.sizeof(row)
        need(self.PS.GetProcessMemoryInfo(state["handle"],c.byref(row),row.cb)
             and row.rss > 0 and row.peak > 0, "positive-owned-native-RSS")
        return row.rss,row.peak

    def resume(self, state):
        self.identity(state)
        need(self.NT.NtResumeProcess(state["handle"]) == 0, "native-resume-failed")

    def terminate(self, state, code=137):
        with self.lock:
            self.identity(state,live=False)
            if self.K.WaitForSingleObject(state["handle"],0) == 0:
                return False
            self.identity(state)
            need(self.K.TerminateProcess(state["handle"],code), "owned-HANDLE-terminate")
            return True

    def close_identity(self,state):
        self.identity(state,live=False)
        need(self.K.WaitForSingleObject(state["handle"],0) == 0, "native-child-not-signaled")
        need(self.K.CloseHandle(state["handle"]), "native-child-handle-close")
        state["closed"]=True

    def close(self):
        need(not self.kept_pipes, "pending-overlapped-resources-retained")
        if self.stage:
            need(self.K.CloseHandle(self.stage), "stage-handle-close")
            self.stage=None

    def pipe(self, output_from_child):
        return Pipe(self,output_from_child)


class Pipe:
    """One call owner submits/completes/cancels every overlapped I/O."""
    def __init__(self, native, output_from_child):
        import msvcrt
        self.native=native;K=native.K
        self.output=output_from_child
        self.pending=False;self.closed=False;self.eof=False;self.buffer=None
        self.client_fd=None;self.handle=None;self.event=None
        name=r"\\.\pipe\fn-online-"+uuid.uuid4().hex
        access=1 if output_from_child else 2
        self.handle=K.CreateNamedPipeW(name,access|0x40000000|0x80000,
            0x8,1,PIPE_BYTES,PIPE_BYTES,0,None)
        need(self.handle and self.handle != c.c_void_p(-1).value, "overlapped-server-pipe")
        try:
            self.event=K.CreateEventW(None,True,False,None)
            need(self.event, "overlapped-event")
            sa=Security(c.sizeof(Security),None,True)
            client=K.CreateFileW(name,0x40000000 if output_from_child else 0x80000000,
                                 0,c.byref(sa),3,0,None)
            need(client and client != c.c_void_p(-1).value, "owned-client-pipe")
            try:
                self.client_fd=msvcrt.open_osfhandle(client,os.O_BINARY|
                     (os.O_WRONLY if output_from_child else os.O_RDONLY))
            except BaseException:
                K.CloseHandle(client)
                raise
            self.ov=Overlapped();self.ov.hEvent=self.event
            connected=K.ConnectNamedPipe(self.handle,c.byref(self.ov))
            need(connected or c.get_last_error()==535, "connected-owned-pipe")
        except BaseException:
            self.close()
            raise

    def close_client(self):
        if self.client_fd is not None:
            os.close(self.client_fd);self.client_fd=None

    def begin(self, block=None):
        need(not self.closed and not self.pending and not self.eof, "pipe-operation-state")
        K=self.native.K
        need(K.ResetEvent(self.event), "reset-overlapped-event")
        self.ov=Overlapped();self.ov.hEvent=self.event
        size=16384 if self.output else len(block)
        need(0 < size <= PIPE_BYTES and (self.output or type(block) is bytes), "bounded-pipe-block")
        self.buffer=c.create_string_buffer(size) if self.output else c.create_string_buffer(block,size)
        count=w.DWORD()
        call=K.ReadFile if self.output else K.WriteFile
        ok=call(self.handle,self.buffer,size,c.byref(count),c.byref(self.ov))
        if not ok and c.get_last_error() in (109,232):
            self.eof=True
            return b"" if self.output else 0
        need(ok or c.get_last_error()==997, "overlapped-submit")
        self.pending=True
        return self.complete()

    def complete(self):
        if not self.pending:
            return None
        count=w.DWORD()
        ok=self.native.K.GetOverlappedResult(self.handle,c.byref(self.ov),c.byref(count),False)
        if not ok:
            error=c.get_last_error()
            if error==996:
                return None
            if error in (109,232,995):
                self.pending=False;self.eof=True
                return b"" if self.output else 0
            raise self.native.error()
        self.pending=False
        return bytes(self.buffer[:count.value]) if self.output else count.value

    def close(self):
        if self.closed:
            return
        self.close_client()
        if self.pending:
            self.native.K.CancelIoEx(self.handle,c.byref(self.ov))
            if self.native.K.WaitForSingleObject(self.event,1000) != 0:
                self.native.kept_pipes.append(self)
                raise RuntimeError("overlapped-cancel-not-complete-buffer-retained")
            self.complete()
        if self.handle:
            need(self.native.K.CloseHandle(self.handle), "pipe-handle-close")
            self.handle=None
        if self.event:
            need(self.native.K.CloseHandle(self.event), "pipe-event-close")
            self.event=None
        self.closed=True


class DriverSupport:
    @staticmethod
    def head(root):
        return strict(regular_read(Path(root)/"SELECTED.json",65536),65536)

    def publish(self,root,name,ops=None,**fields):
        return self.call(root,"publish",request=dict(request=name,base=self.head(root),
                         ops=ops or [],packet=False),**fields)

    def verify_binary(self,poll=None):
        need(file_hash(self.executable,poll=poll)==self.binary_sha256,"exact-executable-hash")

    def _state(self,token):
        need(type(token) is str and token in self.registry,"foreign-native-token")
        return self.registry[token]


    def _terminate(self,state,reason,code=137):
        with self.lock:
            if state["resources_closed"]:
                return
            if reason in state.setdefault("termination_reasons",set()):
                return
            state["termination_reasons"].add(reason)
            state["termination_requests"].append(dict(reason=reason,code=code,
                                                       observed_ns=time.perf_counter_ns()))
            identity=state.get("native")
            if identity is not None:
                self.native.terminate(identity,code)
            elif state.get("process") is not None:
                p=state["process"]
                need(self.native.K.TerminateProcess(int(p._handle),code),"Popen-owned-setup-terminate")


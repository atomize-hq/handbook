"""UNQUALIFIED new transport; one Popen/overlapped-I/O/reap owner. Old files immutable."""
import copy
import os
from pathlib import Path
import subprocess
import threading
import time
import uuid
from windows_deadlines import (CHECKER_BYTES, READER_BYTES, READERS, Deadline,
                               Refusal, canonical, digest, integer, need, strict)
from windows_growth import file_hash, regular_read, native_call_bound
from windows_native import PIPE_BYTES, DriverSupport


class WindowsDriver(DriverSupport):
    def __init__(self, native, executable, expected_sha256, final_pin, evidence,
                 admit, absolute_deadline, *, observer=None, historical_policy=None):
        self.native,self.executable=native,Path(executable)
        need(self.executable.is_absolute() and self.executable.resolve()==self.executable,
             "canonical-owned-executable")
        self.binary_sha256,self.final_pin=expected_sha256,final_pin
        self.evidence,self.admit,self.absolute_deadline=evidence,admit,absolute_deadline
        self.observer,self.historical_policy=observer,historical_policy
        self.lock,self.registry=threading.RLock(),{}
        self.context=threading.local()
        self.verify_binary()

    def interrupt(self,token,kind):
        need(kind in ("cancel","death"),"closed-transport-interrupt-kind")
        with self.lock:
            state=self._state(token)
            need(not state["resources_closed"] and state["action"] in READERS,
                 "owned-live-reader-only")
            self.native.identity(state["native"])
            need(state["intentional_interrupt"] in (None,kind),"conflicting-transport-interrupt")
            state["intentional_interrupt"]=kind
            self._terminate(state,"registered-"+kind,138 if kind=="cancel" else 137)
        return dict(call_token=token,kind=kind,termination_requested=True,
                    semantic_noncommit=False)

    def wait_control(self,token,timeout):
        with self.lock:
            state=self._state(token)
        need(state["done"].wait(min(max(0,timeout),5)),"call-owner-not-completed")
        need(state["row"] is not None,"missing-control-raw-row")
        return copy.deepcopy(state["row"])

    def live(self,token):
        with self.lock:
            state=self._state(token)
            if state["resources_closed"] or "native" not in state:
                return False
            try:
                self.native.identity(state["native"])
                return True
            except Refusal:
                return False

    def controls(self):
        with self.lock:
            return {key:dict(action=s["action"],root=s["root"],
                closed=s["resources_closed"],callback_joined=s["callback_joined"],
                done=s["done"].is_set(),native_identity=copy.deepcopy(s.get("public_identity")),
                context=copy.deepcopy(s["context"])) for key,s in self.registry.items()}

    def close_owned(self,reason,root=None):
        with self.lock:
            rows=[s for s in self.registry.values() if (root is None or s["root"]==str(root))
                  and not s["resources_closed"]]
        for state in rows:
            try:
                self._terminate(state,reason)
            except BaseException as error:
                state["violations"].append("close-owned:"+repr(error))
        for state in rows:
            need(state["done"].wait(5),"owned-call-not-joined")

    def call(self,root,action,*,timeout=120,code=0,env=None,on_started=None,**fields):
        began=time.perf_counter_ns()
        deadline=Deadline(self.absolute_deadline-12,timeout)
        self.verify_binary(deadline.poll)
        need(on_started is None or callable(on_started),"explicit-start-callback")
        payload=dict(root=str(root),action=action,**copy.deepcopy(fields))
        encoded=canonical(payload)
        need(len(encoded)<=4*1024**2,"engine-input-4MiB-bound")
        historical=self.historical_policy(payload,env,code) if self.historical_policy else None
        profile=self.admit(payload,env,code);deadline.poll()
        profile["_transport_started_ns"]=began
        return self._execute([str(self.executable)],payload,encoded,env,code,deadline.remaining(),
            on_started,profile,historical=historical)

    def script(self,spec,profile):
        """Already parent-pinned argv/closure; bootstrap holds an owned gate."""
        need(spec["kind"]=="python" and spec.get("startup_gate"),"script-preaccess-gate-required")
        return self._execute(spec["argv"],dict(script_spec=copy.deepcopy(spec)),b"",
            spec.get("env"),spec["expected_exit"],spec["timeout"],None,profile,
            script_gate=spec["startup_gate"],output_mode=spec["output_mode"],
            executable_sha256=spec["executable_sha256"])

    def _execute(self,argv,payload,encoded,env,code,timeout,on_started,profile,
                 *,historical=None,script_gate=None,output_mode="json",executable_sha256=None):
        need(set(profile)>={"stdout_bytes","stderr_bytes","rss_samples","callback_seconds"},
             "closed-invocation-ceilings")
        need(all(integer(profile[k],1) for k in ("stdout_bytes","stderr_bytes","rss_samples")),
             "positive-invocation-ceilings")
        need(profile["stdout_bytes"]+profile["stderr_bytes"]<=16*1024**2,"bounded-call-RAM")
        need(0 < profile["callback_seconds"] <= .5,"bounded-start-callback")
        environment={k:v for k,v in os.environ.items() if not k.startswith("EXP_")}
        environment["EXP_NAVIGATION"]="4"
        if env is not None:
            need(type(env) is dict and all(type(k) is str and type(v) is str
                 and k.startswith("EXP_") and "\0" not in k+v for k,v in env.items()),
                 "engine-options-outside-INPUT")
            environment.update(env)
        action=payload.get("action","script")
        root=payload.get("root",script_gate.get("root") if script_gate else None)
        limit=READER_BYTES if action in READERS or script_gate and profile.get("role")=="reader" else CHECKER_BYTES
        deadline=Deadline(self.absolute_deadline-12,timeout)
        token=uuid.uuid4().hex
        need(len(canonical(env))<=8192,"env-evidence-bound")
        bound=native_call_bound(profile,payload,env)
        self.evidence.reserve_call(token,bound["native_bytes"])
        state=dict(token=token,root=str(root),action=action,violations=[],process=None,
            resources_closed=False,callback_joined=True,done=threading.Event(),row=None,
            intentional_interrupt=None,termination_requests=[],input_bytes_sent=0,
            stdin_closed=False,input_fully_delivered=False,input_transfer_accounting_complete=True,
            stdout_eof=False,stderr_eof=False,context=copy.deepcopy(getattr(self.context,"value",{})))
        with self.lock:
            self.registry[token]=state
        out,err=bytearray(),bytearray()
        offsets={"stdout":0,"stderr":0}
        pipes=[];timer=None;callback=None;response=None;parse_error=None
        started=profile.get("_transport_started_ns",time.perf_counter_ns());peak=0;samples=0;rss_next=0;input_offset=0
        actual_sha=executable_sha256 or self.binary_sha256
        need(file_hash(Path(argv[0]))==actual_sha,"actual-invoked-image-hash")

        def terminate(reason):
            try:
                self._terminate(state,reason)
            except BaseException as error:
                state["violations"].append("native-terminate:"+repr(error))

        def expire():
            state["violations"].append("time-censor")
            terminate("absolute-total-deadline")

        def sample(force=False):
            nonlocal peak,samples,rss_next
            now=time.perf_counter_ns()
            if force or now>=rss_next:
                identity=state.get("native")
                if identity is not None and state["process"].poll() is None:
                    rss,hwm=self.native.memory(identity)
                    peak=max(peak,hwm);samples+=1
                    need(samples<=profile["rss_samples"],"RSS-sample-evidence-ceiling")
                    self.evidence.append(dict(kind="native-RSS",call_token=token,
                        observed_ns=now,rss=rss,peak=hwm,pid=identity["pid"],
                        creation_time=identity["creation_time"],rss_limit=limit))
                    need(0<rss<=limit and hwm<=limit,"reader-or-checker-RSS-censor")
                rss_next=now+10_000_000

        def save_raw(name,block):
            target=out if name=="stdout" else err
            if name=="stdout" and block and not state["input_fully_delivered"] and not script_gate:
                if "response-before-complete-input" not in state["violations"]:
                    state["violations"].append("response-before-complete-input")
            target.extend(block)
            self.evidence.raw(token,name,offsets[name],block)
            offsets[name]+=len(block)
            need(len(target)<=profile[name+"_bytes"]+PIPE_BYTES,"bounded-final-pipe-tail")
            if len(target)>profile[name+"_bytes"]:
                if "output-bound:"+name not in state["violations"]:
                    state["violations"].append("output-bound:"+name)
                terminate("output-ceiling")

        try:
            timer=threading.Timer(deadline.remaining(),expire);timer.daemon=False;timer.start()
            pipes=[self.native.pipe(False),self.native.pipe(True),self.native.pipe(True)]
            pin,pout,perr=pipes
            deadline.poll()
            p=subprocess.Popen(argv,stdin=pin.client_fd,stdout=pout.client_fd,stderr=perr.client_fd,
                env=environment,close_fds=True,creationflags=0x4)
            state["process"]=p
            for pipe in pipes:
                pipe.close_client()
            state["native"]=self.native.capture(p,Path(argv[0]),actual_sha)
            state["public_identity"]=self.native.identity(state["native"])
            sample(True);deadline.poll()
            self.native.resume(state["native"])
            resumed=time.perf_counter_ns();state["resumed_ns"]=resumed
            sample(True)
            if script_gate:
                gate=Path(script_gate["ready"])
                while not gate.exists():
                    deadline.poll();sample()
                    need(p.poll() is None,"script-ended-before-startup-gate")
                    time.sleep(min(.005,deadline.remaining()))
                ready=strict(regular_read(gate,8192),8192)
                need(ready.get("pid")==p.pid and ready.get("nonce")==script_gate["nonce"]
                     and ready.get("manifest_sha256")==script_gate["manifest_sha256"],
                     "authentic-arg-script-preaccess-gate")
            rss,_=self.native.memory(state["native"])
            event=dict(call_token=token,pid=p.pid,creation_time=state["native"]["creation_time"],
                same_job=True,native_handle_identity=True,guard_nonce=self.native.owner["nonce"],
                resumed_ns=resumed,observed_ns=time.perf_counter_ns(),positive_rss=rss,
                before_stdin_delivery=True,executable_sha256=actual_sha,final_pin=self.final_pin,
                context=copy.deepcopy(state["context"]))
            state["positive_start_event"]=event
            self.evidence.append(dict(kind="positive-native-start",**event))
            callbacks=[x for x in (self.observer,on_started) if x is not None]
            if callbacks:
                errors=[]
                def notify():
                    try:
                        for fn in callbacks:
                            fn(copy.deepcopy(event))
                    except BaseException as error:
                        errors.append(repr(error))
                callback=threading.Thread(target=notify,name="native-start-"+token,daemon=False)
                state["callback_joined"]=False
                callback.start();callback.join(min(profile["callback_seconds"],deadline.remaining()))
                state["callback_joined"]=not callback.is_alive()
                need(state["callback_joined"] and not errors,"start-callback-timeout-or-error:"+repr(errors))
            deadline.poll();sample()
            if script_gate:
                release=Path(script_gate["release"])
                need(not release.exists(),"fresh-script-gate-release")
                with release.open("xb") as stream:
                    stream.write(canonical(dict(nonce=script_gate["nonce"],pid=p.pid))+b"\n")
                    stream.flush()
            if not encoded:
                pin.close();state["stdin_closed"]=True;state["input_fully_delivered"]=True
            transfer=None;tail_end=None
            while True:
                if deadline.remaining()<=0 and "time-censor" not in state["violations"]:
                    expire()
                sample()
                if state["violations"] or state["intentional_interrupt"]:
                    terminate("failure-or-registered-interrupt")
                    tail_end=tail_end or time.perf_counter()+5
                need(tail_end is None or time.perf_counter()<tail_end,
                     "post-termination-pipe-tail-deadline")
                for name,pipe in (("stdout",pout),("stderr",perr)):
                    if pipe.eof:
                        state[name+"_eof"]=True;continue
                    value=pipe.complete() if pipe.pending else pipe.begin()
                    if value is not None:
                        if value:
                            save_raw(name,value)
                        if pipe.eof or value==b"":
                            pipe.eof=True;state[name+"_eof"]=True
                if not pin.closed:
                    if state["violations"] or state["intentional_interrupt"]:
                        if pin.pending:
                            state["input_transfer_accounting_complete"]=False
                        pin.close();state["stdin_closed"]=True
                    else:
                        if not pin.pending and transfer is None:
                            transfer=encoded[input_offset:input_offset+16384]
                            value=pin.begin(transfer)
                        else:
                            value=pin.complete()
                        if value is not None:
                            if value==0 and input_offset<len(encoded):
                                state["input_broken_pipe"]=True
                                pin.close();state["stdin_closed"]=True
                            else:
                                input_offset+=value
                                state["input_bytes_sent"]=input_offset
                                state.setdefault("stdin_started_ns",time.perf_counter_ns())
                                transfer=None
                                if input_offset==len(encoded):
                                    pin.close();state["stdin_closed"]=True
                                    state["input_fully_delivered"]=True
                                    state["input_complete_ns"]=time.perf_counter_ns()
                if state["stdout_eof"] and state["stderr_eof"] and p.poll() is not None:
                    break
                time.sleep(.001)
            p.wait(timeout=1)
        except BaseException as error:
            state["violations"].append("transport:"+repr(error))
            terminate("transport-error")
        finally:
            p=state["process"]
            if p is not None:
                if p.poll() is None:
                    terminate("final-owner-closure")
                try:
                    p.wait(timeout=5)
                except BaseException as error:
                    state["violations"].append("root-not-reaped:"+repr(error))
                    until=time.perf_counter()+2
                while len(pipes)==3 and not all(x.eof or x.closed for x in pipes[1:]) and time.perf_counter()<until:
                    for name,pipe in zip(("stdout","stderr"),pipes[1:]):
                        if pipe.eof or pipe.closed:
                            continue
                        try:
                            value=pipe.complete() if pipe.pending else pipe.begin()
                            if value:
                                save_raw(name,value)
                            elif value==b"":
                                pipe.eof=True;state[name+"_eof"]=True
                        except BaseException as error:
                            state["violations"].append("raw-tail:"+repr(error));pipe.eof=True
                    time.sleep(.001)
            if pipes and pipes[0].pending:
                state["input_transfer_accounting_complete"]=False
            for pipe in pipes:
                try:
                    pipe.close()
                except BaseException as error:
                    state["violations"].append("pipe-closure:"+repr(error))
            if pipes:
                state["stdin_closed"]=pipes[0].closed
            if timer is not None:
                timer.cancel()
                if timer.ident is not None:
                    timer.join(1)
                if timer.is_alive():
                    state["violations"].append("deadline-callback-not-joined")
            if callback is not None:
                if callback.ident is not None:
                    callback.join(.1)
                state["callback_joined"]=not callback.is_alive()
            if not state["callback_joined"]:
                state["violations"].append("python-start-callback-not-joined")
            if not state["input_fully_delivered"] and state["intentional_interrupt"] is None and code!=86:
                state["violations"].append("incomplete-input-delivery")
            for name in ("stdout","stderr"):
                if not state[name+"_eof"]:
                    state["violations"].append("raw-pipe-EOF-not-observed:"+name)
            identity=state.get("native")
            if identity is not None:
                try:
                    self.native.close_identity(identity)
                except BaseException as error:
                    state["violations"].append("native-handle-closure:"+repr(error))
            if p is not None and p.returncode is not None:
                try:
                    p._handle.Close()
                except BaseException as error:
                    state["violations"].append("Popen-handle-close:"+repr(error))
            state["resources_closed"]=(p is not None and p.returncode is not None
                and identity is not None and identity["closed"]
                and all(x.closed for x in pipes) and len(pipes)==3
                and state["callback_joined"] and (timer is None or not timer.is_alive()))
            try:
                self.evidence.append(dict(kind="raw-complete",call_token=token,
                stdout_bytes=len(out),stdout_sha256=digest(out),stderr_bytes=len(err),
                stderr_sha256=digest(err),stdout_eof=state["stdout_eof"],stderr_eof=state["stderr_eof"],
                process_reaped=p is not None and p.returncode is not None,
                input_bytes_expected=len(encoded),input_bytes_sent=state["input_bytes_sent"],
                stdin_closed=state["stdin_closed"],input_fully_delivered=state["input_fully_delivered"]))
            except BaseException:
                state["done"].set();raise
            try:
                out_text=bytes(out).decode("utf-8");err_text=bytes(err).decode("utf-8")
                if output_mode=="json" and out and not state["intentional_interrupt"]:
                    response=strict(bytes(out),profile["stdout_bytes"])
                elif output_mode=="raw":
                    response=dict(raw_stdout_sha256=digest(out),raw_stderr_sha256=digest(err))
                elif (not out and code!=86 and not state["intentional_interrupt"]
                      and not(p is not None and p.returncode==86 and profile.get("observed_exit_codes")==[86])):
                    raise Refusal("missing-complete-JSON-response")
            except BaseException as error:
                out_text=bytes(out).decode("utf-8",errors="replace")
                err_text=bytes(err).decode("utf-8",errors="replace")
                parse_error=repr(error);state["violations"].append("strict-output:"+parse_error)
            if deadline.remaining()<=0 and "time-censor" not in state["violations"]:
                state["violations"].append("time-censor")
            if historical and historical["expected_error"] is not None:
                if not(type(response) is dict and response.get("status")=="error" and response.get("error")==historical["expected_error"]):
                    state["violations"].append("historical-exact-refusal-mismatch")
            if type(response) is dict and response.get("peak_memory_bytes") is not None:
                if not integer(response["peak_memory_bytes"]) or response["peak_memory_bytes"]>limit:
                    state["violations"].append("reported-process-peak-RSS-censor")
            row=dict(input=payload,env=copy.deepcopy(env),executable=argv[0],
                executable_sha256=actual_sha,source_pin=self.final_pin,suite_pin=self.final_pin,
                binary_source_pin=historical["binary_source_pin"] if historical else (None if script_gate else self.final_pin),
                binary_role="historical" if historical else "python-argv" if script_gate else "candidate",call_token=token,
                exit=None if p is None else p.returncode,stdout=out_text,stderr=err_text,
                stdout_sha256=digest(out),stderr_sha256=digest(err),violations=list(state["violations"]),
                positive_start_event=state.get("positive_start_event"),rss_limit=limit,
                observed_peak_rss=peak,memory_sample_count=samples,
                input_bytes_expected=len(encoded),input_bytes_sent=state["input_bytes_sent"],
                input_wire_sha256=digest(encoded),input_written_prefix_sha256=digest(encoded[:state["input_bytes_sent"]]),
                input_transfer_accounting_complete=state["input_transfer_accounting_complete"],
                stdin_started_ns=state.get("stdin_started_ns"),input_complete_ns=state.get("input_complete_ns"),
                stdin_closed=state["stdin_closed"],input_fully_delivered=state["input_fully_delivered"],
                input_delivery_scope="completed native writes plus stdin closure; no child-consumption inference",
                process_started_ns=started,process_resumed_ns=state.get("resumed_ns"),
                process_done_ns=time.perf_counter_ns(),spawn_total_ns=time.perf_counter_ns()-started,
                intentional_interrupt=state["intentional_interrupt"],termination_requests=state["termination_requests"],
                native_identity=state.get("public_identity"),resources_closed=state["resources_closed"],
                python_callback_joined=state["callback_joined"],historical_invocation=historical,
                raw_before_strict_parse=True,context=state["context"],
                outer_Job_closure="separate-accepted-QPC-final-receipt-required")
            try:
                state["raw_reference"]=self.evidence.append(dict(kind="native-call",**row))
                self.evidence.finish_call(token)
                self.context.completed_token=token
                self.context.completed_row=row
                state["row"]=(row if state["intentional_interrupt"] else
                    {k:v for k,v in row.items() if k not in ("stdout","stderr","input")})
                state["row"]["input_sha256"]=digest(canonical(payload))
            finally:
                state["done"].set()
        need(state["row"] is not None,"missing-native-call-raw-receipt")
        if row["exit"]!=code or row["violations"] or state["intentional_interrupt"]:
            raise AssertionError(row)
        return response


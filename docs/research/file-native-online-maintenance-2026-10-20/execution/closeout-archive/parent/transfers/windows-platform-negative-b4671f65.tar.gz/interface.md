# Private platform interfaces

All methods below are SOURCE ONLY. Source hash/method bindings are necessary but
do not create runtime GO. A final parent-pinned manifest/release, transport review,
all case/source maps and complete resource admission must exist first.

## LaneHost v1

- authorize(config,lane): exact parent config hash and lane scope. Returns go,
  final_pin, source/budget/claim refs and a persisted receipt hash.
- poll(): FAST real stage HANDLE/creation/current-Job/RSS/deadline check.
  Returns live observation, content hash and source/budget refs; no whole-root
  census or file hashing per64KiB helper block. It is not a final QPC verdict.
- checkpoint(label,reserves): only with owned I/O quiescent; source-bound
  forecast-reserves normalizer maps helper forecasts to incremental
  {category:{bytes,files,directories}}. Complete actual census validates the
  original root anchor plus retained increments; no in-body reclaim credit.
  Returns go/no_other_semantic_writer and raw budget receipt.
- invoke(spec): only lane-invoke-v1 engine-json or python-argv. Exact executable,
  source closure, argv/JSON schema, root/action/role/env, expected exit,
  input/output/time and incremental growth all come from reviewed parent policy.
  No arbitrary command/Popen interface is exposed to helpers.
- record(label,value,category,max_bytes): bytes are written exactly; a dict is
  canonical private JSON plus LF. Absolute paths create an exclusive file under
  the admitted category; symbolic labels create unique numbered JSON records.
  Returns actual path/bytes/SHA. Counts all retained files; never overwrites.
- drain(label): closes ALL registered owned call processes/I/O/native handles
  and Python callbacks, retains errors and returns raw closure refs.
  children_empty has scope owned-children-IO-handles. It is NOT empty-Job proof.

Properties: harness is the exact reviewed shared Harness; harness.a is the native
Adapter. history is the history-native-v1 runner. Other implementation methods are
internal and are not additional helper dependencies.

The outer QPC final two empty Job observations, final gzip/JSON closures and
post-close actual census are required after host exit. Platform finalize closes
its own evidence, computes a last actual census without further file writes, and
reports pending outer authority. Python-script engine_ns is null; candidate
engine_ns must be the actual wall_ns and <= actual spawned-call clock.

## lane-invoke-v1

Common closed fields:
kind,api,label,executable,role,timeout_seconds,max_stdout_bytes,max_stderr_bytes,
growth,allowed_exit_codes. Exactly one expected exit is admitted.

engine-json adds:
final_pin,root,action,fields,stdin_release,max_input_bytes.
stdin_release is after-owned-containment-and-budget-gate.
env/on_started are transport-only keyword arguments, never engine JSON.

python-argv adds:
script,argv,transitive_bindings,startup_gate,required_gate,max_stdin_bytes,output.
No stdin is needed. output declares exact owned path/max_bytes/category.
The parent-pinned policy constructs only the verified bootstrap argv from the
closed script/argv and current manifest hash. The child verifies that same
manifest, emits ready at its unique reserved gate, waits for its exact nonce/PID
release, then enters the script. The actual manifest hash is supplied at launch,
not embedded recursively inside its own hash preimage.

invoke returns source/binary/budget/raw/closure refs, exact raw stdout, real clocks
and own-call closure. Python output is independently length/hash checked. Before
return it rejects any live unregistered member of the current Job.

## history-native-v1

bindings(), preflight(plan,forecast,release), adopt(h,donor),
lookup(h,donor,lookup_plan), phase(h,phase), and
release_definitive_conflicts(h,root,requests,outcomes,candidates).

The runner full source hash plus exact AST method hashes are bound. The phase
context yields tick(progress) and finish(). Helpers own pub/pack/accepted ledgers
and sequence; runner owns four actual reader load slots, held old reader,
authentic native ready/intervals/raw observations and joins. No loop sleeps merely
to pretend native reader work. Exhaustion fails; the40-call proposal is not
prejudged adequate. The old reader must overlap real progress beyond15s and
two real successor mappings and release before the declared protected-generation
cap. Final phase normalization and source-specific reader specs remain hooks.

Lookup order: legacy50fresh/500warm for each of six categories at exactH1002/H10002,
physical convert, paged same-H50/500, then actual cleanup and v2 enable.
Semantic publications happen only afterward. No old baseline response is
relabeled final. Pending terminal-v2 refuses before any phase write.

## NativeAdapter and reviewed hooks

Implements every core-required method: clocks, preflight/before_call, confined
read/exists/hash/inventory, control/release/signal/end_signal, spawn/alive/wait/
await_ready, begin_phase/overlap, mapping/backlog/quiesce/close_case,
removal_proof/crash_source_binding, interrupt/finish_interrupted and extend.
prepared_candidates is also exposed for HISTORY.

spawn creates a non-daemon Python callback with an opaque handle. Thread-local
context associates each actual native token to root/phase/handle. A live thread
alone is never a native reader. ready file bytes are retained; the reviewed
checkpoint proof must validate actual process/readiness correspondence.

Hooks are registered only with path,SHA,function,AST-function-SHA,schema_pin,
final_pin,review_sha256,kind and result_max_bytes. Actual path belongs to the full
verified source closure. Python hook signature is (host,request). Its
source_sha256 wrapper is checked and removed before returning the closed payload;
request/result hashes and source refs remain in evidence. A hook cannot qualify a
case merely by existing. Missing/source-mismatched hooks raise Unsupported.

The full oracle always runs in a separate guarded checker process. It requires
complete accepted authority/reverse mapped-role closure, request-intents,
graph/source/navigation/provenance, retirement/B controls and all file/directory
before/after hashes. Engine audit and a private parser fork cannot substitute.
Durable physical-pins/*.lock stay included; exclusions are finite source-mapped
ephemeral gates, never a wildcard.

Historical binary grants bind distinct actual old source/SHA, exact case, action,
input hash, env, role, expected exit/refusal and finite call count on an admitted
owned derivative. Protected old operational roots are refused. Historical
Drivers share the owner registry/context/guard, never a new Job, and raw rows
retain binary_role=historical and binary_source_pin distinct from suite_pin.

The complete actual final unit catalog extends the five legacy identity slots.
All real case/source/checkpoint/corruption/donor/oracle maps remain NULL/PENDING
until exact final source review; no guessed offsets, old busy assertions or
old267/282 event totals qualify new runs.

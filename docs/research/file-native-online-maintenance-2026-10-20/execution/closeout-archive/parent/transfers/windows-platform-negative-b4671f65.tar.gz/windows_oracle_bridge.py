"""Independent checker process bridge; never import the decoder or engine."""
import copy
import threading
from pathlib import Path
from windows_deadlines import Unsupported, canonical, digest, need, strict
from windows_growth import inventory, regular_read

CHECKS=frozenset(("complete_physical","all_accepted_outcomes","exact_request_intents",
    "selected_membership","graph","source_bytes","navigation","provenance",
    "retired_refusals","b_loose_controls","ordinary_selected_once_b","read_only_inventory"))


class OracleBridge:
    def __init__(self,host):
        self.host=host
        self.lock=threading.RLock()

    def _invoke(self,mode,root,kwargs):
        spec=self.host.manifest["hooks"].get("oracle-process")
        if spec is None or spec.get("reviewed") is not True:
            raise Unsupported("PENDING-reviewed-R1-plus-terminal-v2-full-verifier")
        need(spec["final_pin"]==self.host.final_pin and spec.get("reverse_cohort_closed") is True
             and spec.get("per_root_process") is True,"exact-final-independent-oracle-binding")
        # No in-process legacy global callback monkeypatching across roots.
        with self.lock:
            before=inventory(root,self.host.poll)
            invocation=self.host.hooks.call("oracle-invocation",self.host,
                dict(mode=mode,root=str(root),kwargs=copy.deepcopy(kwargs),
                     inventory=before,process_binding=copy.deepcopy(spec)))
            result=self.host.invoke(invocation)
            proof=strict(regular_read(result["output"]["path"],result["output"]["bytes"]),
                         result["output"]["bytes"])
            after=inventory(root,self.host.poll)
            need(before==after,"oracle-must-preserve-all-files-and-directories")
            need(proof.get("final_pin")==self.host.final_pin
                 and proof.get("engine_code_imported") is False
                 and proof.get("engine_audit_used") is False
                 and proof.get("source_unchanged") is True,"independent-source-unchanged-proof")
            proof["native_raw"]=result
            return proof

    def __call__(self,*,root,checkpoint,final_pin,known_requests,required_mapped_keys):
        need(final_pin==self.host.final_pin,"oracle-final-pin")
        self.host.adapter.quiesce(root)
        proof=self._invoke("full",root,dict(checkpoint=checkpoint,quiescent=True,
            known_requests=known_requests,required_mapped_keys=required_mapped_keys))
        need(proof.get("status")=="passed" and CHECKS<=set(proof.get("checks",[]))
             and proof.get("reverse_selected_cohort") is True
             and proof.get("all_files_directories_hashed") is True,"full-complete-oracle-only")
        need(proof.get("actual_H")==len(known_requests),"all-accepted-exact-H")
        need(set(required_mapped_keys)<=set(proof.get("mapped_keys",[])),"oracle-required-mapped-keys")
        ref=self.host.events.append(dict(kind="independent-oracle",proof=proof))
        proof["receipt_sha256"]=ref["sha256"]
        return proof

    def query(self,mode,root,**kwargs):
        need(mode in ("mapping","backlog"),"closed-independent-query-mode")
        proof=self._invoke(mode,root,kwargs)
        need(proof.get("independent") is True,"independent-mapping-or-backlog")
        return proof

"""PREPARED, NOT EXECUTED. Separate parent memory-control GO is mandatory.

No Win32 provider, Popen, Job, engine, file write or real fixture in memory tests.
Native transport/pipe/identity behavior needs a separate reviewed benign run.
"""
import copy
import inspect
import json
import threading
import tracemalloc
from windows_deadlines import Refusal, Unsupported, canonical, digest, integer, need, strict
from windows_growth import GrowthLedger, native_call_bound, per_call_envelope
from windows_driver import WindowsDriver
from windows_hooks import BoundHooks

CONTROL_PLAN=dict(status="PREPARED_NOT_EXECUTED_PARENT_GO_REQUIRED",native_processes=0,
    engine_calls=0,filesystem_writes=0,max_checks=64,max_raw_bytes=65536,
    max_traced_python_bytes=8388608,real_case_qualification=False,
    optional_native_proposal=dict(status="UNALLOCATED_NOT_GO",bytes=2097152,files=128))


def components():
    return dict(input_bytes=1024,env_bytes=64,stdout_bytes=4096,stderr_bytes=1024,
        rss_samples=8,harness_bytes=65536,lane_record_bytes=8192,oracle_metadata_bytes=4096,
        outer_guard_bytes=4096,finalization_bytes=8192)


def ledger():
    value=GrowthLedger.__new__(GrowthLedger)
    value.lock=threading.RLock()
    value.poll=lambda:None
    value.roots={"body":dict(root="C:/owned",bytes=2000,files=100,directories=10)}
    value.anchors={"body":dict(bytes=1000,file_count=10,directory_count=2)}
    value.leases={}
    return value


class FakeNative:
    def __init__(self):
        self.terminated=[]

    def identity(self,state,live=True):
        need(not state["closed"] and state["creation_time"]==9 and state["same_job"],
             "fake-exact-identity")
        return dict(pid=12,creation_time=9,same_job=True)

    def terminate(self,state,code):
        self.identity(state)
        self.terminated.append((state["pid"],state["creation_time"],code))
        return True


def control_driver():
    d=WindowsDriver.__new__(WindowsDriver)
    d.lock=threading.RLock();d.native=FakeNative();d.registry={}
    state=dict(root="C:/owned/body",action="resolve",resources_closed=False,
        native=dict(pid=12,creation_time=9,same_job=True,closed=False),
        intentional_interrupt=None,termination_requests=[],done=threading.Event())
    d.registry["owned"]=state
    return d,state


def memory_controls():
    """Pure memory only. Caller must retain result as unqualified control evidence."""
    checks=[]
    def yes(name,fn):
        need(fn() is True,"control-positive:"+name);checks.append(name)
    def no(name,fn):
        try:
            fn()
        except (Refusal,Unsupported,ValueError,TypeError,KeyError):
            checks.append(name);return
        raise RuntimeError("control-negative-did-not-refuse:"+name)

    tracemalloc.start()
    yes("strict-complete",lambda:strict(b'{"a":1}',20)=={"a":1})
    no("strict-duplicate",lambda:strict(b'{"a":1,"a":2}',30))
    no("strict-tail",lambda:strict(b'{}{}',30))
    no("strict-nonfinite",lambda:strict(b'{"a":NaN}',30))
    no("strict-invalid-UTF8",lambda:strict(b'"\xff"',30))
    no("strict-byte-bound",lambda:strict(b'{}',1))
    yes("bool-not-integer",lambda:not integer(True))
    yes("canonical-exact-bytes",lambda:canonical({"z":1,"a":2})==b'{"a":2,"z":1}')

    a=ledger()
    a.reserve("one",{"body":dict(bytes=200,files=2,directories=1)})
    a.reserve("two",{"body":dict(bytes=300,files=2,directories=1)})
    yes("root-counted-once",lambda:sum(x["growth"]["body"]["bytes"] for x in a.leases.values())==500)
    no("concurrent-growth-overcap",lambda:a.reserve("three",{"body":dict(bytes=501,files=1,directories=0)}))
    yes("refused-lease-not-charged",lambda:"three" not in a.leases)
    no("duplicate-lease",lambda:a.reserve("one",{"body":dict(bytes=0,files=0,directories=0)}))
    no("unknown-root",lambda:a.reserve("unknown",{"other":dict(bytes=0,files=0,directories=0)}))
    no("bool-growth",lambda:a.reserve("bool",{"body":dict(bytes=True,files=0,directories=0)}))
    no("negative-growth",lambda:a.reserve("negative",{"body":dict(bytes=-1,files=0,directories=0)}))
    no("whole-root-twice",lambda:a.reserve("clone",{"body":dict(bytes=1001,files=0,directories=0)}))
    a.settle("one")
    yes("settled-failed-prefix-stays-charged",lambda:a.leases["one"]["settled"] and
        a.leases["one"]["growth"]["body"]["bytes"]==200)

    parts=components();envelope=per_call_envelope(parts)
    yes("all-sinks-positive",lambda:envelope["total_bytes"]>envelope["native_bytes"]>0)
    yes("no-gzip-credit",lambda:envelope["gzip_credit"]==0)
    missing=dict(parts);missing.pop("finalization_bytes")
    no("missing-finalization-component",lambda:per_call_envelope(missing))
    null=dict(parts,rss_samples=None)
    no("null-RSS-component",lambda:per_call_envelope(null))
    no("boolean-sink",lambda:per_call_envelope(dict(parts,outer_guard_bytes=True)))
    no("nonfinite-sink",lambda:per_call_envelope(dict(parts,harness_bytes=float("nan"))))
    no("negative-sink",lambda:per_call_envelope(dict(parts,lane_record_bytes=-1)))
    no("extra-sink",lambda:per_call_envelope(dict(parts,credit=-1)))
    no("oversize-output-RAM",lambda:per_call_envelope(dict(parts,stdout_bytes=16*1024**2+1)))
    profile=dict(stdout_bytes=4096,stderr_bytes=1024,rss_samples=8,
                 all_sink_components=parts)
    no("understated-input",lambda:native_call_bound(profile,{"body":"x"*1025},None))
    no("understated-RSS",lambda:native_call_bound(dict(profile,rss_samples=9),{},None))
    no("understated-output",lambda:native_call_bound(dict(profile,stdout_bytes=5000),{},None))

    d,s=control_driver()
    no("foreign-token",lambda:d.interrupt("foreign","death"))
    no("unknown-interrupt-kind",lambda:d.interrupt("owned","kill-by-name"))
    result=d.interrupt("owned","death")
    yes("owned-token-terminate",lambda:result["semantic_noncommit"] is False and len(d.native.terminated)==1)
    no("conflicting-interrupt",lambda:d.interrupt("owned","cancel"))
    d,s=control_driver();s["native"]["creation_time"]=8
    no("creation-mismatch",lambda:d.interrupt("owned","death"))
    d,s=control_driver();s["native"]["same_job"]=False
    no("foreign-Job",lambda:d.interrupt("owned","death"))
    d,s=control_driver();s["resources_closed"]=True
    no("closed-token",lambda:d.interrupt("owned","death"))
    d,s=control_driver();s["action"]="publish"
    no("writer-is-not-reader-death-control",lambda:d.interrupt("owned","death"))
    signature=inspect.signature(WindowsDriver.call)
    yes("env-explicit-keyword",lambda:signature.parameters["env"].kind==inspect.Parameter.KEYWORD_ONLY)
    yes("on-started-explicit-keyword",lambda:signature.parameters["on_started"].kind==inspect.Parameter.KEYWORD_ONLY)
    yes("no-shared-last",lambda:not hasattr(WindowsDriver,"last"))

    hooks=BoundHooks(dict(hooks={},final_pin="a"*40),lambda:None)
    no("unreleased-terminal-v2",lambda:hooks.binding("terminal-v2","a"*40))
    no("unreleased-ctor",lambda:hooks.binding("constructor:pack-old-delete","a"*40))
    no("unreleased-oracle",lambda:hooks.binding("oracle-process","a"*40))
    current,peak=tracemalloc.get_traced_memory();tracemalloc.stop()
    need(peak<=CONTROL_PLAN["max_traced_python_bytes"] and len(checks)<=CONTROL_PLAN["max_checks"],
         "bounded-memory-controls")
    return dict(status="MEMORY_CONTROLS_ONLY_NOT_NATIVE_QUALIFICATION",checks=checks,
        count=len(checks),traced_peak_bytes=peak,native_processes=0,engine_calls=0,
        filesystem_writes=0,bytecode_writes=0,all_engine_case_status="PENDING")


if __name__=="__main__":
    raise SystemExit("Prepared only: execute memory_controls through a separately approved source-bound runner.")

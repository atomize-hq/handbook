# Platform source review boundary

This packet is SOURCE ONLY; no control function was executed. Parent should read
all11 modules and27 files before selecting any finite control run. Static
compilation is not a driver, native API, engine or qualification result.

## Causal change and ownership

Frozen Driver924fea5a parsed JSON and decoded UTF8 before appending its raw row.
Partial JSON/death/nonUTF8 could therefore lose stdout/stderr evidence. Its call
also did not bound setup/callback time inside communicate's timeout. A wrapper
cannot obtain already-private pipe buffers after those failures. The approved
new transport owns its own Popen and all overlapped I/O/reaping; old Driver,
guard1e4 and QPC50ecc are byte-preserved.

Intended native proof is suspended child + positive RSS + retained exact
HANDLE/creation/image + current-Job membership including retained stage. No
basename, process name, bare PID or any-Job-only termination is used. Native
primitives, overlapped cancellation, real Job semantics, handle inheritance and
closure must be independently reviewed and tested under a separately sealed
benign control release. They are not qualified by in-memory fake ownership tests.

Source flags distinguish complete input delivery from partial/cancelled writes;
child consumption is not inferred. Cancellation is transport control, not proof
of semantic noncommit. Per-call stdout/stderr are lossless chunks; UTF8/JSON
errors occur after durable raw output. RSS/clock/output/closure censors cannot be
recovered as a semantic exit2. Intentional death rows require exact source/call/
identity and separate proof. A raw-sink overrun remains an incomplete prefix,
never a fake EOF or passed cell.

Every native process and Python callback is closed/joined independently. Driver
retains compact closed-call metadata and persisted raw references, rather than
every warm response in RAM; thread-local completed rows serve synchronous
consumers. Twelve seconds of the fixed outer stage deadline are withheld for
bounded pipe/reap/callback closure. Native/kernel blocking is additionally
bounded by the accepted outer Job watchdog, without a new Job or clock reset.

## Explicit pending integration

- Final engine/build/schema/terminal-v2 and independent quota-owner oracle remain
  unknown. a3 is historical engineering, not the final candidate.
- Shared corev3.1 and v5 R1 source acceptance were relayed and exact Git blobs
  matched. They do not authorize imports without the whole actual transitive
  closure, source review documents and runtime manifest. Parent owns unchanged
  paged_index closure materialization.
- Every166 Windows case map stays pending. Old assertion offsets/event counts,
  busy expectations and five workspace identities are not new qualification.
  Actual final19+ tests must be enumerated from the final source catalog.
- Constructor/ready/mapping/backlog/overlap/quiescence/oracle and native extension
  hooks are closed missing capabilities until exact source/function/schema/
  review/final-pin bindings exist. They cannot return an unreviewed fake pass.
- HISTORY's40-call load may exhaust before its100 offered slots end. No higher
  call cap, pace change, sleeping idle reader or false active-process count is
  selected here. Source-reviewed adequate finite load is required before phase
  writes; exhaustion remains failure.
- HISTORY currently expects a phase guard summary inside a live host. The final
  outer QPC receipt and two empty Job observations cannot exist until host exit.
  Parent/helper review must select authentic phase observations plus a pending
  postexit linkage, rather than manufacture final success. This adapter does not
  relax that validator.
- Standalone old-source compatibility uses distinct source/SHA and finite exact
  grants only on owned derivatives. Protected old operational roots are refused.
  No mixed-version lifetime guarantee is inferred.
- Full Windows body/file/evidence topology is unclosed. No512MiB/60k claim exists.

## Resource evidence

Every write projected the registered individual, group and total source caps.
Syntax failures were corrected before writing that replacement file; no failed
candidate was executed. No temporary file, pycache or extra28th name was used.

Growth anchors nonoverlapping existing roots once; all concurrent incremental
leases stay conservatively charged, including failed B generations. Checkpoints
compare actual complete measurements to that floor. Forecast-only admission is
separate from actual growth. No root-sized lease is multiplied per small action;
a real clone instead reserves its full own incremental image.

per_call_envelope includes raw chunks/tail, native100Hz RSS, native row metadata,
explicit shared-Harness events, helper records, oracle metadata, outer guard and
finalization. Missing components refuse. Native rows and bindings have explicit
size ceilings. No gzip ratio or4KiB estimate is assumed. Retained source+gzip
copies charge both. Final actual census follows all own output closure, and
parent must additionally check after outer gzip/JSON close.

## Impact and authority

Cached GitNexus1.6.12 upstream impact WindowsDriver targeted this exact Landing
path and returned repository not found. No alternate registered checkout was
selected and no bootstrap/index/cache installation ran. Indexed risk UNKNOWN is
treated manually HIGH. New direct consumers are NativeAdapter, LaneHost,
HistoryNative/HistoryLease, source-bound hooks and shared Harness/helper entry
points. Affected processes are input delivery, concurrent readers/publishers,
physical maintenance, independent verification and closeout; existing Engine,
Matrix, shared core, parser, HISTORY and LONG source were not edited.

No commits/staging occurred. Parent alone must run exact-worktree detect_changes
and inspect the diff before landing. The standard remains proposed; no product
format/default/migration or public API is adopted. All global protections,
44GiB/5m files/internal reserve, free/RSS limits and original deadlines remain.

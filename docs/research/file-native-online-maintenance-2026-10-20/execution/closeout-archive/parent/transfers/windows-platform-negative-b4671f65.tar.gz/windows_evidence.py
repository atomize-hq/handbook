"""Bounded append-only lossless records. No runtime files on import."""
import base64
import copy
import gzip
import threading
from pathlib import Path
from windows_deadlines import canonical, digest, integer, need
from windows_growth import confined, file_hash, inventory


class Evidence:
    def __init__(self, path, ledger, category, *, max_bytes, max_files=1, binding=None):
        self.path = confined(Path(ledger.roots[category]["root"]), Path(path))
        need(self.path.parent.is_dir() and not self.path.exists(), "fresh-evidence-path")
        need(integer(max_bytes, 1) and max_files == 1, "bounded-one-evidence-file")
        self.ledger, self.category = ledger, category
        self.max_bytes, self.written, self.count = max_bytes, 0, 0
        self.lock, self.binding = threading.RLock(), copy.deepcopy(binding or {})
        need(len(canonical(self.binding))<=512,"bounded-evidence-binding")
        self.pending={}
        self.closed=False
        self.key = "evidence:"+str(self.path)
        ledger.reserve(self.key, {category:dict(bytes=max_bytes, files=1, directories=0)})
        with self.path.open("xb"):
            pass

    def append(self, value):
        raw = canonical(dict(binding=self.binding, observation=value))+b"\n"
        with self.lock:
            need(not self.closed,"closed-evidence-stream")
            token=value.get("call_token") if type(value) is dict else None
            if token in self.pending:
                need(len(raw)<=self.pending[token],"per-call-raw-reservation")
            held=sum(self.pending.values())-(len(raw) if token in self.pending else 0)
            need(self.written+len(raw)+held<=self.max_bytes,
                 "raw-evidence-plus-pending-before-write")
            if type(value) is dict and value.get("kind")=="native-RSS":
                need(len(raw)<=1024,"exact-RSS-row-envelope")
            if type(value) is dict and value.get("kind")=="raw-chunk":
                need(len(raw)<=len(value["bytes_b64"])+1024,"exact-raw-chunk-envelope")
            with self.path.open("ab") as output:
                output.write(raw)
                output.flush()
            if token in self.pending:
                self.pending[token]-=len(raw)
            self.written += len(raw)
            self.count += 1
        return dict(path=str(self.path), offset=self.written-len(raw), bytes=len(raw),
                    rows=self.count, stream_bytes=self.written, sha256=digest(raw))

    def reserve_call(self,token,maximum):
        with self.lock:
            need(integer(maximum,1) and token not in self.pending
                 and self.written+sum(self.pending.values())+maximum<=self.max_bytes,
                 "whole-call-raw-envelope-before-pipes")
            self.pending[token]=maximum

    def finish_call(self,token):
        with self.lock:
            need(token in self.pending,"known-call-evidence-envelope")
            del self.pending[token]  # Unwritten reservation only, never deletion credit.

    def raw(self, call, stream, offset, block):
        need(type(block) is bytes and len(block) <= 65536, "bounded-raw-chunk")
        return self.append(dict(kind="raw-chunk", call_token=call, stream=stream,
            offset=offset, bytes=len(block), sha256=digest(block),
            bytes_b64=base64.b64encode(block).decode("ascii")))

    def reference(self):
        return dict(path=str(self.path), bytes=self.written, rows=self.count,
                    sha256=file_hash(self.path, self.max_bytes), lossless=True)

    def close(self):
        need(not self.pending,"all-call-evidence-reservations-closed")
        self.closed=True
        self.ledger.settle(self.key)
        return self.reference()


def gzip_copy(source, destination, ledger, category, max_bytes, poll):
    """Retain source; reserve worst case gzip+trailer BEFORE opening output."""
    source, destination = Path(source), Path(destination)
    confined(Path(ledger.roots[category]["root"]), destination)
    need(destination.parent.is_dir() and not destination.exists(), "fresh-gzip-output")
    size = source.stat().st_size
    need(max_bytes >= size+(size//16384+1)*32+4096, "gzip-incompressible-and-footer-bound")
    token = "gzip:"+str(destination)
    ledger.reserve(token, {category:dict(bytes=max_bytes, files=1, directories=0)})
    with source.open("rb") as inp, destination.open("xb") as raw:
        with gzip.GzipFile(filename="", fileobj=raw, mode="wb", compresslevel=1, mtime=0) as out:
            while True:
                poll()
                block = inp.read(65536)
                if not block:
                    break
                out.write(block)
                need(raw.tell() <= max_bytes-4096, "gzip-runtime-bound")
        raw.flush()
    need(destination.stat().st_size <= max_bytes, "closed-gzip-final-bound")
    ledger.settle(token)
    # Caller must checkpoint after its final JSON as well; this is not that census.
    return dict(source_sha256=file_hash(source), gzip_sha256=file_hash(destination),
                bytes=destination.stat().st_size, source_retained=True)

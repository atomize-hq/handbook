"""Reviewed source-bound hooks and history-native-v1. Pending maps refuse."""
import ast
import copy
from contextlib import contextmanager
import importlib.util
import inspect
from pathlib import Path
import threading
import time
from windows_deadlines import Unsupported, canonical, digest, need
from windows_growth import file_hash, regular_read


class BoundHooks:
    def __init__(self,manifest,closure):
        self.specs=manifest["hooks"];self.final_pin=manifest["final_pin"]
        self.closure=closure;self.loaded={}
        self.paths={Path(p) for p in manifest.get("source_files",{})}

    def binding(self,name,final_pin):
        spec=self.specs.get(name)
        if not spec or spec.get("reviewed") is not True:
            raise Unsupported("PENDING-exact-reviewed-hook:"+name)
        need(final_pin==self.final_pin==spec["final_pin"]
             and spec.get("schema_pin") and spec.get("review_sha256"),
             "hook-source-schema-review-final-binding")
        path=Path(spec["path"]);self.closure()
        need(path in self.paths,"hook-in-full-transitive-source-closure")
        need(file_hash(path)==spec["sha256"],"hook-source-bytes")
        source=regular_read(path,2*1024**2).decode("utf-8")
        tree=ast.parse(source)
        found=[node for node in tree.body if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef))
               and node.name==spec["function"]]
        need(len(found)==1 and not isinstance(found[0],ast.AsyncFunctionDef),"one-ordinary-reviewed-hook")
        need(digest(ast.get_source_segment(source,found[0]).encode())==spec["function_sha256"],
             "exact-hook-function-method-hash")
        return dict(status="reviewed-source-map",final_pin=final_pin,
            checkpoint=spec.get("checkpoint"),source_sha256=spec["sha256"],
            schema_pin=spec["schema_pin"],review_sha256=spec["review_sha256"],
            function_sha256=spec["function_sha256"])

    def historical(self,host,grant_id):
        from windows_driver import WindowsDriver
        key=("historical",grant_id)
        if key not in self.loaded:
            grant=host.manifest["historical_grants"].get(grant_id)
            if not grant:
                raise Unsupported("PENDING-closed-historical-binary-grant:"+grant_id)
            policy=HistoricalGrant(host,grant)
            d=WindowsDriver(host.native,grant["path"],grant["binary_sha256"],
                host.final_pin,host.events,policy.admit,host.deadline.end,
                observer=host.adapter.observe_start,historical_policy=policy)
            d.registry=host.driver.registry
            d.context=host.driver.context
            self.loaded[key]=d
        return self.loaded[key]

    def capabilities(self):
        return [name for name,s in self.specs.items() if s and s.get("reviewed") is True
                and s.get("final_pin")==self.final_pin]

    def call(self,name,host,request):
        self.binding(name,host.final_pin)
        spec=self.specs[name]
        need(spec.get("kind")=="in-process-source","closed-source-hook-kind")
        key=(spec["path"],spec["sha256"])
        if key not in self.loaded:
            module_spec=importlib.util.spec_from_file_location("bound_hook_"+spec["sha256"],spec["path"])
            module=importlib.util.module_from_spec(module_spec)
            module_spec.loader.exec_module(module)
            self.loaded[key]=module
        function=getattr(self.loaded[key],spec["function"])
        need(list(inspect.signature(function).parameters)==["host","request"],"reviewed-hook-call-signature")
        result=function(host,copy.deepcopy(request))
        need(type(result) is dict and result.get("source_sha256")==spec["sha256"],
             "source-bound-hook-receipt")
        result=dict(result);result.pop("source_sha256")
        raw=canonical(result)
        need(type(spec.get("result_max_bytes")) is int and 0<=len(raw)<=spec["result_max_bytes"],
             "source-bound-hook-result-ceiling")
        host.events.append(dict(kind="bound-hook-result",name=name,
            source_sha256=spec["sha256"],request_sha256=digest(canonical(request)),
            result_sha256=digest(raw),result_bytes=len(raw),
            receipt_reference=result.get("receipt_sha256")))
        return result


class HistoryNative:
    api="history-native-v1"

    def __init__(self,host):
        self.host=host;self.session=None

    def bindings(self):
        release=self.host.manifest.get("history_release")
        if not release:
            raise Unsupported("PENDING-history-native-v1-final-source-and-terminal-v2")
        need(release["api"]==self.api and release["runner_sha256"]==self.host.source_hash(__file__),
             "exact-versioned-history-runner-source")
        source=regular_read(Path(__file__),24576).decode("utf-8")
        cls=next(n for n in ast.parse(source).body if isinstance(n,ast.ClassDef) and n.name=="HistoryNative")
        names={"bindings","preflight","adopt","lookup","phase","release_definitive_conflicts"}
        actual={n.name:digest(ast.get_source_segment(source,n).encode()) for n in cls.body
                if isinstance(n,ast.FunctionDef) and n.name in names}
        need(actual==self.host.manifest["release"]["runner_method_hashes"],
             "history-runner-exact-method-source-hashes")
        return copy.deepcopy(release)

    def preflight(self,plan,forecast,release):
        need(release==self.bindings(),"same-history-release")
        for name in ("terminal-v2","history-load-plan","history-adopt","history-lookup",
                     "history-phase-evidence","history-phase-GO","history-tick","history-conflicts"):
            self.host.hooks.binding(name,self.host.final_pin)
        # No phase writes until terminal API and finite adequate load are reviewed.
        proof=self.host.hooks.call("history-phase-GO",self.host,
            dict(plan=plan,forecast=forecast,release=release))
        need(proof.get("go") is True and proof.get("finite_reader_load_reviewed") is True
             and proof.get("reader_exhaustion_is_failure") is True,
             "prospective-finite-reader-load-admission")
        return proof

    def adopt(self,h,donor):
        need(h is self.host.harness,"one-Harness-history")
        proof=self.host.hooks.call("history-adopt",self.host,dict(donor=donor))
        records=proof.pop("accepted_records",None)
        need(type(records) is list and len(records)==donor["actual_H"],
             "complete-authenticated-donor-inputs")
        h.adopt_inputs(donor["root"],records,seed_receipt_sha256=donor["seed_receipt_sha256"])
        return proof

    def lookup(self,h,donor,lookup_plan):
        need(h is self.host.harness,"one-Harness-lookup")
        proof=self.host.hooks.call("history-lookup",self.host,dict(donor=donor,lookup_plan=lookup_plan))
        need(proof.get("semantic_writes")==0 and proof.get("order")==
             ["final-candidate-legacy","convert-paged","final-candidate-paged"],
             "same-H-lookup-before-semantic-mutation")
        return proof

    @contextmanager
    def phase(self,h,phase):
        need(h is self.host.harness and self.session is None,"one-native-history-phase")
        lease=HistoryLease(self.host,h,phase)
        self.session=lease
        try:
            lease.start()
            yield lease
        finally:
            try:
                lease.close()
            finally:
                self.session=None

    def release_definitive_conflicts(self,h,root,requests,outcomes,candidates):
        need(h is self.host.harness,"one-Harness-terminal-release")
        self.host.hooks.binding("terminal-v2",self.host.final_pin)
        proof=self.host.hooks.call("history-conflicts",self.host,dict(root=str(root),
            requests=requests,outcomes=outcomes,candidates=candidates))
        need(proof.get("reclaimed_bytes")==0 and proof.get("semantic_collect_called") is False
             and proof.get("global_history_scan") is False,"point-terminalization-only-zero-reclaim")
        return proof


class HistoryLease:
    """Four native load slots; slot0 initially holds the real old reader.

    The helper owns publication/maintenance sequencing and accepted ledgers.
    This lease only owns native reader load, identities, intervals and joins.
    All finite load fields are source-reviewed in the release before start().
    """
    def __init__(self,host,h,phase):
        self.host,self.h,self.phase=host,h,copy.deepcopy(phase)
        self.stop=threading.Event();self.handles=[];self.progress=[]
        self.old=None;self.old_control=None;self.finished=False
        self.reader_rows=[];self.reader_lock=threading.RLock()

    def start(self):
        self.host.history.bindings()
        load=self.host.hooks.call("history-load-plan",self.host,dict(phase=self.phase))
        need(load.get("slots")==4 and load.get("finite") is True
             and load.get("phase_id")==self.phase["id"]
             and load.get("calls")==self.phase["reader_calls"],
             "source-bound-four-slot-load-plan")
        self.load=load
        self.host.adapter.begin_phase(self.phase["root"],self.phase["id"])
        self.old_control=self.host.adapter.control(self.phase["root"],"history-old-"+self.phase["id"])
        for slot in range(4):
            self.handles.append(self.host.adapter.spawn(lambda slot=slot:self.reader(slot)))
        self.host.adapter.await_ready(self.old_control,self.handles[0],10)
        self.old=dict(captured_ns=time.perf_counter_ns(),released_ns=None)
        # Every slot requires an actual positive native call, not a live thread.
        end=time.perf_counter()+10
        while not all(self.host.adapter.alive(x) for x in self.handles):
            self.host.poll()
            need(time.perf_counter()<end,"four-independent-native-reader-starts")
            time.sleep(.005)

    def reader(self,slot):
        total=self.load["calls"]
        allowed=self.load["slot_calls"][str(slot)]
        need(type(allowed) is int and allowed>0 and sum(self.load["slot_calls"].values())==total,
             "finite-per-slot-reader-call-accounting")
        for number in range(allowed):
            if self.stop.is_set():
                break
            self.host.poll()
            spec=copy.deepcopy(self.load["callspecs"][str(slot)])
            env=None
            if slot==0 and number==0:
                need(spec["action"] in ("resolve","point","inspect"),"real-held-reader-action")
                env=dict(EXP_BARRIER=self.load["old_reader_checkpoint"],
                         EXP_READY=self.old_control["ready"],EXP_RELEASE=self.old_control["release"])
            before=time.perf_counter_ns()
            value=self.h.call(self.phase["root"],spec["action"],env=env,
                              timeout=self.load["call_timeout_seconds"],**spec["fields"])
            after=time.perf_counter_ns()
            need(value.get("result")==spec["expected_result"],"all-reader-exact-response")
            with self.reader_lock:
                self.reader_rows.append(dict(slot=slot,number=number,start_ns=before,
                                              end_ns=after,response=value))
        if not self.stop.is_set():
            raise RuntimeError("finite-reader-load-exhausted-before-publishers-finished")
        return dict(slot=slot,calls=number+1 if allowed else 0)

    def tick(self,progress):
        self.host.poll()
        # A thread between calls is not counted as an active native reader.
        for handle in self.handles:
            if not handle["thread"].is_alive():
                if handle["error"] is not None:
                    raise handle["error"]
                raise RuntimeError("reader-slot-ended-during-phase")
        row=self.host.hooks.call("history-tick",self.host,dict(phase=self.phase,
            progress=progress,reader_rows=copy.deepcopy(self.reader_rows),old=copy.deepcopy(self.old)))
        self.progress.append(copy.deepcopy(progress))
        if self.old and self.old["released_ns"] is None:
            need(row.get("held_generation_peak",61)<=60,"release-old-reader-before-protected-generation-cap")
            elapsed=time.perf_counter_ns()-self.old["captured_ns"]
            if (elapsed>15_000_000_000 and row.get("publishers_progress") is True
                and row.get("new_readers_progress") is True
                and (not self.phase["online"] or row.get("successor_mapping_count",0)>=2)):
                self.host.adapter.release(self.old_control)
                self.old["released_ns"]=time.perf_counter_ns()

    def finish(self):
        need(not self.finished,"one-phase-finish")
        need(self.old and self.old["released_ns"] is not None,"held-old-reader-progress-not-established")
        self.stop.set()
        self.close()
        proof=self.host.hooks.call("history-phase-evidence",self.host,dict(phase=self.phase,
            progress=self.progress,reader_rows=self.reader_rows,old=self.old,
            handles=[dict(id=h["id"],tokens=h["native_tokens"],joined=h["joined"]) for h in self.handles]))
        need(proof.get("readers",{}).get("exhausted") is False
             and proof.get("readers",{}).get("positive_native_overlap") is True,
             "actual-reader-load-native-overlap")
        self.finished=True
        return proof

    def close(self):
        self.stop.set();failures=[]
        if self.old_control is not None:
            try:
                self.host.adapter.release(self.old_control)
            except BaseException as error:
                failures.append(repr(error))
        for handle in self.handles:
            try:
                self.host.adapter.wait(handle,min(15,self.host.deadline.remaining()))
            except BaseException as error:
                failures.append(repr(error))
        need(all(h["joined"] for h in self.handles),"all-history-reader-callbacks-joined")
        if failures:
            self.host.events.append(dict(kind="history-reader-close-failures",failures=failures))
            raise RuntimeError("history-reader-errors:"+repr(failures))


class HistoricalGrant:
    """Old source remains old; closed case/action/input/env/role/count permission."""
    def __init__(self,host,grant):
        self.host,self.grant=host,copy.deepcopy(grant)
        need(set(grant)=={"path","binary_sha256","binary_source_pin","review_sha256",
             "case_id","fresh_or_owned_derivative","calls"}
             and grant["fresh_or_owned_derivative"] is True
             and grant["binary_source_pin"]!=host.final_pin and grant["review_sha256"],
             "closed-distinct-historical-source-grant")
        need(file_hash(grant["path"])==grant["binary_sha256"],"actual-old-executable-bytes")
        self.lock=threading.RLock();self.remaining=[r["count"] for r in grant["calls"]]
        need(all(type(n) is int and n>0 for n in self.remaining),"finite-historical-call-counts")

    def admit(self,payload,env,code):
        actual=digest(canonical(payload))
        rows=[r for r in self.grant["calls"] if r["input_sha256"]==actual and r["env"]==env
              and r["expected_exit"]==code]
        need(len(rows)==1,"historical-exact-growth-profile")
        row=rows[0];token="historical-growth:"+actual+":"+str(time.perf_counter_ns())
        self.host.ledger.reserve(token,row["growth"]);self.host.ledger.settle(token)
        return row["profile"]

    def __call__(self,payload,env,code):
        root=Path(payload["root"]);self.host.ledger.root_name(root)
        need("disposable" in root.parts,"historical-owned-derivative-only")
        banned=[Path(p) for p in self.host.grant["protected_roots"]]
        need(not any(root==p or root.is_relative_to(p) for p in banned),
             "never-open-protected-old-operational-root")
        case_id,_=self.host.adapter.case_for(root)
        need(case_id==self.grant["case_id"],"historical-exact-case")
        actual=dict(root=str(root),action=payload["action"],input_sha256=digest(canonical(payload)),
                    env=env,expected_exit=code,role="reader" if payload["action"] in
                    ("resolve","point","inspect","lookup-bench") else "checker")
        with self.lock:
            found=[i for i,row in enumerate(self.grant["calls"])
                   if all(row.get(k)==v for k,v in actual.items()) and self.remaining[i]>0]
            need(len(found)==1,"historical-action-input-env-role-count-grant")
            i=found[0];self.remaining[i]-=1
            return dict(binary_source_pin=self.grant["binary_source_pin"],binary_role="historical",
                case_id=case_id,grant_sha256=digest(canonical(self.grant)),call_index=i,
                remaining=self.remaining[i],expected_error=self.grant["calls"][i]["expected_error"])

"""One reviewed LaneHost for LONG, legacy restore and HISTORY."""
import copy
import importlib
import os
from pathlib import Path
import threading
import time
import uuid
from windows_adapter import NativeAdapter
from windows_deadlines import (CHECKER_BYTES, FUNCTIONAL, GUARD_SHA, Deadline,
                               Unsupported, canonical, digest, integer, need, strict)
from windows_driver import WindowsDriver
from windows_evidence import Evidence
from windows_growth import confined, file_hash, GrowthLedger, inventory, regular_read
from windows_hooks import BoundHooks, HistoryNative
from windows_native import Memory, Native
from windows_oracle_bridge import OracleBridge

OWNER=Path("C:/file-native-online-control-20261020/current-owner.json")


class LaneHost:
    """Construction is allowed only behind the verified bootstrap startup gate."""
    def __init__(self,manifest,manifest_sha256,grant,gate_receipt):
        self.manifest=copy.deepcopy(manifest);self.manifest_sha256=manifest_sha256
        self.grant=copy.deepcopy(grant);self.final_pin=manifest["final_pin"]
        need(gate_receipt["pid"]==os.getpid() and grant["runtime_go"] is True
             and grant["transport_reviewed"] is True,"verified-bootstrap-gate-and-runtime-release")
        self.deadline=Deadline(manifest["absolute_deadline"],FUNCTIONAL-time.time())
        self.source_manifest_sha256=digest(canonical(manifest["source_files"]))
        self.verify_closure()
        need(os.environ.get("FILE_NATIVE_STAGE_JOB")=="1","accepted-outer-QPC-required")
        self.owner=strict(regular_read(OWNER,8192),8192)
        budget=os.environ.get("FILE_NATIVE_BUDGET")
        need(budget and file_hash(budget)==self.owner["budget_sha256"]==grant["budget_sha256"]
             and self.owner["state"]=="running","exact-current-stage-budget-owner")
        self.native=Native(self.owner)
        self.events=None
        self._poll_last_ns=0;self._poll_receipt=None
        self.ledger=GrowthLedger(manifest["roots"],self.poll)
        self.events=Evidence(grant["events_path"],self.ledger,grant["events_category"],
            max_bytes=grant["events_max_bytes"],binding=dict(final_pin=self.final_pin,
            guard_sha256=GUARD_SHA,manifest_sha256=manifest_sha256,claim_id=grant["claim_id"]))
        self.hooks=BoundHooks(manifest,self.verify_closure)
        engine=manifest["engine"]
        need(engine.get("reviewed") is True and engine["source_pin"]==self.final_pin
             and engine.get("core_reviewed") is True,"final-engine-core-reviewed")
        build=self.hooks.call("build-binding-proof",self,dict(engine=engine))
        need(build.get("binary_sha256")==engine["sha256"] and build.get("final_pin")==self.final_pin,
             "exact-final-build-source-manifest-proof")
        self.driver=WindowsDriver(self.native,engine["path"],engine["sha256"],self.final_pin,
            self.events,self.admit_engine,manifest["absolute_deadline"])
        self.oracle=OracleBridge(self);self.adapter=NativeAdapter(self)
        core=importlib.import_module("focused_protocol")
        need(self.source_hash(core.__file__)==engine["core_sha256"],"exact-shared-Harness-source")
        self.harness=core.Harness(self.driver,self.adapter,self.oracle,self.events.append,
                                  final_pin=self.final_pin)
        self.history=HistoryNative(self)
        self.record_counts={};self.record_lock=threading.RLock()
        self.events.append(dict(kind="LaneHost-start",gate_receipt=gate_receipt,
            source_manifest_sha256=self.source_manifest_sha256,owner=self.owner))

    def source_hash(self,path):
        key=str(Path(path).resolve())
        rows=[r for p,r in self.manifest["source_files"].items() if Path(p)==Path(key)]
        row=rows[0] if len(rows)==1 else None
        need(row is not None,"source-in-transitive-manifest:"+key)
        need(file_hash(key,row["bytes"])==row["sha256"],"source-bytes-unchanged")
        return row["sha256"]

    def verify_closure(self):
        for path,row in self.manifest["source_files"].items():
            need(file_hash(path,row["bytes"])==row["sha256"],"transitive-source-changed:"+path)
        return self.source_manifest_sha256

    def poll(self):
        """FAST native identity/deadline/RSS only; no directory walk/full hash."""
        self.deadline.poll()
        need(self.native.stage_live(),"live-creation-bound-owned-stage")
        row=Memory();row.cb=__import__("ctypes").sizeof(row)
        need(self.native.PS.GetProcessMemoryInfo(self.native.stage,__import__("ctypes").byref(row),row.cb)
             and 0<row.rss<=CHECKER_BYTES,"positive-stage-RSS")
        now=time.perf_counter_ns()
        receipt=dict(live=True,observed_ns=now,pid=self.owner["job_root_pid"],
            creation_time=self.owner["job_root_creation_time"],rss=row.rss,
            guard_nonce=self.owner["nonce"],guard_sha256=GUARD_SHA,
            budget_sha256=self.owner["budget_sha256"],source_manifest_sha256=self.source_manifest_sha256)
        receipt["receipt_sha256"]=digest(canonical(receipt))
        # This content-addressed fast observation is not a final guard verdict.
        if self.events is not None and now-self._poll_last_ns>=250_000_000:
            self.events.append(dict(kind="fast-native-poll",**receipt))
            self._poll_last_ns=now
        return receipt

    def authorize(self,config,lane):
        self.poll();self.verify_closure()
        spec=self.grant["lanes"].get(lane)
        need(spec is not None and spec["config_sha256"]==digest(canonical(config))
             and spec["go"] is True,"parent-exact-lane-config-GO")
        proof=dict(go=True,lane=lane,final_pin=self.final_pin,
            config_sha256=spec["config_sha256"],claim_id=self.grant["claim_id"],
            budget_sha256=self.owner["budget_sha256"],source_manifest_sha256=self.source_manifest_sha256)
        proof["receipt_sha256"]=self.events.append(dict(kind="lane-authorization",**proof))["sha256"]
        return proof

    def _reserves(self,label,value):
        proof=self.hooks.call("forecast-reserves",self,dict(label=label,reserves=value))
        need(proof.get("incremental") is True and proof.get("planned_deletion_credit")==0
             and proof.get("existing_root_counted_once") is True,"closed-incremental-reserves")
        return proof["growth"]

    def checkpoint(self,label,reserves):
        self.poll()
        active=[s for s in self.driver.registry.values() if not s["resources_closed"]]
        need(not active,"checkpoint-no-active-owned-I/O")
        growth=self._reserves(label,reserves)
        proof=self.ledger.checkpoint(label,growth,quiescent=True)
        need(self.grant.get("no_other_semantic_writer") is True,"parent-exclusive-root-writer-release")
        proof.update(go=True,no_other_semantic_writer=True,claim_id=self.grant["claim_id"])
        proof["receipt_sha256"]=self.events.append(dict(kind="budget-checkpoint",**proof))["sha256"]
        return proof

    def admit_engine(self,payload,env,code):
        self.poll()
        spec=self.hooks.call("engine-input-policy",self,dict(input=payload,env=env,expected_exit=code))
        need(spec.get("admitted") is True and spec.get("source_pin")==self.final_pin,
             "parent-pinned-engine-JSON-schema")
        self.ledger.root_name(payload["root"])
        token="engine-growth:"+uuid.uuid4().hex
        self.ledger.reserve(token,spec["growth"])
        # Retained increment remains charged after settle, including failure output.
        self.ledger.settle(token)
        return spec["profile"]

    def record(self,label,value,category,max_bytes):
        raw=value if type(value) is bytes else canonical(value)+b"\n"
        need(integer(max_bytes,1) and len(raw)<=max_bytes,"record-prewrite-byte-bound")
        with self.record_lock:
            candidate=Path(label)
            if candidate.is_absolute():
                path=confined(Path(self.ledger.roots[category]["root"]),candidate)
            else:
                need(label and all(c.isalnum() or c in "-_:" for c in label),"closed-record-label")
                number=self.record_counts.get(label,0);self.record_counts[label]=number+1
                base=Path(self.ledger.roots[category]["root"])
                path=base/(label.replace(":","-")+"-"+str(number)+".json")
            need(path.parent.is_dir() and not path.exists(),"exclusive-retained-record")
            token="record:"+str(path)
            self.ledger.reserve(token,{category:dict(bytes=max_bytes,files=1,directories=0)})
            with path.open("xb") as stream:
                stream.write(raw);stream.flush()
            self.ledger.settle(token)
        return dict(path=str(path),bytes=len(raw),sha256=digest(raw),source_pin=self.final_pin)

    def invoke(self,spec):
        """Closed lane-invoke-v1; helpers never receive an arbitrary process API."""
        need(type(spec) is dict,"invocation-object")
        clock=Deadline(self.deadline.end-12,spec["timeout_seconds"])
        self.poll();self.verify_closure()
        need(spec.get("api")=="lane-invoke-v1"
             and spec.get("kind") in ("engine-json","python-argv"),"closed-lane-invoke-v1")
        common={"kind","api","label","executable","role","timeout_seconds","max_stdout_bytes",
                "max_stderr_bytes","growth","allowed_exit_codes"}
        extra=({"final_pin","root","action","fields","stdin_release","max_input_bytes"}
               if spec["kind"]=="engine-json" else
               {"script","argv","transitive_bindings","startup_gate","required_gate",
                "max_stdin_bytes","output"})
        need(set(spec)==common|extra,"closed-invocation-fields")
        need(type(spec["allowed_exit_codes"]) is list and len(spec["allowed_exit_codes"])==1,
             "one-explicit-expected-exit")
        policy=self.hooks.call("lane-invoke-policy",self,dict(spec=spec))
        need(policy.get("admitted") is True and policy.get("exact_argv_and_transitive_closure") is True,
             "reviewed-parent-invocation-policy")
        reserve="lane-invoke:"+uuid.uuid4().hex
        self.ledger.reserve(reserve,policy["incremental_growth"])
        self.ledger.settle(reserve)
        if spec["kind"]=="engine-json":
            need(spec["final_pin"]==self.final_pin and spec["executable"]["path"]==str(self.driver.executable)
                 and spec["executable"]["sha256"]==self.driver.binary_sha256
                 and spec["stdin_release"]=="after-owned-containment-and-budget-gate",
                 "candidate-final-engine-invocation")
            need(len(canonical(dict(root=spec["root"],action=spec["action"],**spec["fields"])))
                 <=spec["max_input_bytes"],"invocation-input-ceiling")
            response=self.driver.call(spec["root"],spec["action"],timeout=clock.remaining(),
                                      code=spec["allowed_exit_codes"][0],**spec["fields"])
        else:
            need(spec["max_stdin_bytes"]==0 and policy.get("startup_gate_before_corpus_IO") is True,
                 "arg-only-script-owned-preaccess-gate")
            transport=copy.deepcopy(policy["transport"])
            need(transport["kind"]=="python" and transport["executable_sha256"]==spec["executable"]["sha256"],
                 "exact-parent-python-image")
            transport["startup_gate"]["manifest_sha256"]=self.manifest_sha256
            transport["timeout"]=clock.remaining()
            response=self.driver.script(transport,policy["profile"])
        token=getattr(self.driver.context,"completed_token",None)
        need(token in self.driver.registry,"thread-local-invocation-row-association")
        row=getattr(self.driver.context,"completed_row",None)
        need(row is not None and row["resources_closed"] and not row["violations"],
             "complete-raw-native-invocation")
        raw=self.record(policy["stdout_path"],row["stdout"].encode("utf-8"),
                        policy["stdout_category"],spec["max_stdout_bytes"])
        closure=dict(call_token=token,resources_closed=True,
            python_callbacks_joined=row["python_callback_joined"],
            native_identity=row["native_identity"],raw_call=self.driver.registry[token]["raw_reference"])
        known={self.owner["job_root_pid"],os.getpid()}|{s["public_identity"]["pid"]
            for s in self.driver.registry.values() if not s["resources_closed"] and s.get("public_identity")}
        need(self.native.members()<=known,"unregistered-Job-descendant-not-closed")
        closure_ref=self.events.append(dict(kind="invocation-closure",**closure))
        engine_ns=response.get("wall_ns") if spec["kind"]=="engine-json" else None
        need(engine_ns is None and spec["kind"]=="python-argv" or type(engine_ns) is int
             and 0<=engine_ns<=row["spawn_total_ns"],"actual-engine-and-spawn-clocks")
        result=dict(exit_code=row["exit"],source_pin=self.final_pin,
            binary_sha256=row["executable_sha256"],contained_before_input=True,
            children_empty=True,closure_scope="owned-call-process-IO-handles",
            budget_receipt_sha256=policy["budget_receipt_sha256"],
            closure_receipt_sha256=closure_ref["sha256"],raw=raw,
            engine_ns=engine_ns,
            spawn_total_ns=row["spawn_total_ns"],observed_peak_rss=row["observed_peak_rss"])
        if spec["kind"]=="python-argv":
            output=spec["output"];path=Path(output["path"])
            need(path.exists() and path.stat().st_size<=output["max_bytes"],"bound-script-output-file")
            result.update(startup_gate_before_corpus_IO=True,oracle_sha256=policy["oracle_sha256"],
                output=dict(path=str(path),bytes=path.stat().st_size,sha256=file_hash(path)))
        return result

    def drain(self,label):
        failures=[]
        try:
            self.driver.close_owned("LaneHost-drain:"+label)
        except BaseException as error:
            failures.append(repr(error))
        for control in self.adapter.controls.values():
            try:
                self.adapter._write_signal(control["paths"],"release")
            except BaseException as error:
                failures.append(repr(error))
        for handle in self.adapter.handles.values():
            handle["thread"].join(min(5,self.deadline.remaining()))
            handle["joined"]=not handle["thread"].is_alive()
            if not handle["joined"]:
                failures.append("callback:"+handle["id"])
        rows=list(self.driver.registry.values())
        empty=all(s["done"].is_set() and s["resources_closed"] for s in rows)
        callbacks=all(h["joined"] for h in self.adapter.handles.values())
        proof=dict(label=label,children_empty=empty and callbacks,processes_closed=empty,
            handles_closed=empty,callbacks_joined=callbacks,scope="owned-children-IO-handles",
            failures=failures,outer_QPC_two_empty_Job_polls="required-after-host-exit")
        proof["receipt_sha256"]=self.events.append(dict(kind="LaneHost-drain",**proof))["sha256"]
        return proof

    def finalize(self):
        closure=self.drain("post-final-JSON")
        need(closure["children_empty"],"final-owned-resource-closure")
        stream=self.events;self.events=None
        raw=stream.close()
        # No further file write after this observation. Outer QPC still closes
        # stdout/gzip/final JSON and performs its own actual post-close census.
        actual={name:inventory(spec["root"],self.poll) for name,spec in self.ledger.roots.items()}
        for name,row in actual.items():
            spec=self.ledger.roots[name]
            need(row["bytes"]<=spec["bytes"] and row["file_count"]<=spec["files"]
                 and row["directory_count"]<=spec["directories"],"post-final-file-census")
        self.native.close()
        actual={k:dict(bytes=v["bytes"],files=v["file_count"],directories=v["directory_count"],
                       inventory_sha256=digest(canonical(v))) for k,v in actual.items()}
        return dict(raw=raw,actual=actual,owned_closure=closure,
                    outer_final_QPC_receipt_pending=True)

# Windows final platform — SOURCE ONLY

Owner: 01a15bd5-7694-7981-a619-9a23d4774b60. Claim025 seal:
29aeb8e27edbc42f603ccac8024a1833abf04a7aa49db6ca9c8649940997397a.
The registered source budget is
C:/file-native-online-matrix-20261020/receipts/windows-final-platform-source-budget-025.json,
SHA256 f40b10e707661f3d1523883265431ec380ccf39f5d283c28d1b0e90033ea9e0b.

This is a reviewable private platform source packet. Syntax was compiled in
memory; prepared memory controls were NOT EXECUTED. No native API/provider,
process, engine, build, Job, target, corpus, runtime control, dependency, Git write
or subagent was launched by this source task. Every real case remains PENDING.
The new transport needs independent full source review and separately admitted
benign native controls before any engine qualification.

The 27 approved flat names have individual caps. Source11 <=196608 bytes,
case-data8 <=262144, bindings8 <=65536; total <=524288 bytes. No additional file,
subdirectory, temporary file or bytecode is permitted by this source claim.
Every source write projected all individual/group/whole counts and bytes first.
Parent alone owns staging, commits, integration, resource rebudgeting and RUNGO.

The original Driver 924fea5a..., original guard1e4a9651... and accepted QPC
50ecc7c4... remain immutable. The old Driver parsed/decode stdout before retaining
its row, so an outer wrapper could not recover partial output after termination.
windows_driver.py is an explicit new transport version; windows_native.py supplies
its native primitives and small inherited request/control helpers. One call
owner creates Popen, drives all three overlapped pipes, collects output and reaps.
Other threads only signal through an opaque registered token, retained native
HANDLE, creation time and same-current-Job identity. No Job is created here.

The accepted outer QPC creates/assigns its suspended root before resume. Engine
children use CREATE_SUSPENDED without breakaway, inherit that Job, and require
positive native identity/image/RSS before resume and before stdin. Native
membership queries include the retained stage identity and child. These are
source mechanisms, not native qualification claims. Missing RSS or membership
proof refuses. Reader256MiB/checker2GiB roles follow actions rather than basename.

Raw stdout/stderr are retained in bounded lossless chunks before strict UTF8/JSON
parsing. Completed native writes and actual stdin closure are counted; partial
or cancelled writes are never claimed consumed by the child. Expected intentional
transport interruption has its own raw identity row; it does not establish
semantic noncommit. Callback, timeout, RSS, output and closure errors remain
technical failures. Per-call assertions carry that call's row; no shared last
lookup is used. Pipe EOF and all Python/native resource joins are separate facts.
A twelve-second margin inside the fixed outer deadline reserves bounded closure.

LaneHost is shared by run_long(host,config), legacy_restore(host,config) and
run_history(host,config). Its helpers use authorize/poll/checkpoint/invoke/record/
drain. HISTORY accesses host.harness and host.history (history-native-v1).
The shared Harness and independent parser are imported only from an actual
transitive, parent-pinned file closure. There is no parser, Rust or protocol fork.

Runtime bootstrap uses python -I -S -B, verifies source bytes and the parent
release before owned imports, and waits at a separately reserved unique startup
gate before any corpus/SELECTED access. A Python argv invocation cannot start its
script body merely because Python was resumed. Data and source fingerprints have
their explicit byte domains; no receipt contains its own hash preimage.

All source/constructor/donor/schema/terminal-v2/API/full-suite budgets are
unreleased where final source is unknown. Bound hooks need exact source,
function, schema, review and final-pin bindings; absent hooks raise Unsupported
before mutation. The maps preserve all166 Windows IDs. Five old workspace
identity slots never cap the actual final source test catalog.

Required pending work includes final CP4/terminal-v2 source and full independent
quota-owner oracle, all final test units, all166 real cases, ordinary shell
routes, Windows1000 real mapping activations, HISTORY/LONG/document matrices and
full restore/successor qualification. R1 and corev3.1 source acceptance do not
qualify these runtime cases.

The all-sink formula and unclosed Windows topology are in growth_actions.json.
Current roots are counted once; concurrent retained increments, failed B outputs,
temporary stages and actual clones are charged separately. There is no planned
deletion, link/clone or compression credit. All raw samples/failed prefixes stay.
No forecast expiry is performed by this platform.

Two HISTORY issues are explicitly pending with the helper owner: finite40-call
load may exhaust before the100 offered slots finish, and an inside-host phase
cannot pretend to possess the outer guard's final postexit receipt. No adapter
relaxation or idle-process substitute resolves either issue.

The structured data standard remains PROPOSED. These new JSON maps/receipts are
private machine-controlled interfaces; Markdown explains them. This task changes
no product format, public API, migration or approved default.

GitNexus exact-checkout impact is UNKNOWN/unregistered, manually treated HIGH
across Driver, NativeAdapter, LaneHost, reader sessions and helper boundaries.
No package-manager bootstrap/index was run. Parent must run detect_changes before
committing. Functional cutoff2026-10-21T11:10:14Z and protected closeout13:10:14Z
remain fixed; source freeze target04:10:14Z is unchanged.

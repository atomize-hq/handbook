"""Windows cooperating-writer Context. SOURCE ONLY until reviewed finite RUN GO.

CLI: exactPython -I -S -B -u windows_context.py MANIFEST_PATH MANIFEST_SHA256.
The unlocked outer capture owns the Job/RSS/IO watchdog; THIS process owns the
heavy-token byte lock. No IPC, owner-JSON authority, hostile-user isolation,
implicit extraction, retry, deletion permission, or missing-case PASS exists.
Archive037's native DELETE handle remains its content/disposition endpoint.
"""
import ast
import ctypes as c
from ctypes import wintypes as w
import hashlib
import json
import math
import ntpath
import os
from pathlib import Path
import struct
import sys
import threading
import time

ENGINE = "0628322e4b48e0efad19cdc32238a622d4aaa7a8"
FUNCTIONAL = 1792581014
TOKEN = "C:\\file-native-online-control-20261020\\windows-heavy.lock"
CHUNK = 65536
KEEP = []                         # Uncertain native ownership is never retried.
ENVELOPE = {"version", "runtime_go", "action", "parent_capture_sha256",
            "context_source_sha256", "deadline_perf_ns", "deadline_epoch",
            "real_retire_go", "authority", "parent"}
AUTHORITY = {"version", "engine_commit", "archive_source", "controls_source",
             "plan", "token", "protected_scope", "writer_catalog", "prior_jobs",
             "qualification", "budget", "limits", "native_controls"}
LIMITS = {"max_refs", "max_ref_bytes", "max_aliases", "max_members",
          "archive_bytes", "artifact_files", "body_bytes", "body_files",
          "evidence_bytes", "evidence_files", "control_root", "evidence_root"}
NATIVE_CASES = {"C18-native-reparse-fork", "C22-linked-ancestor",
                "C23-inflight-mutation", "C27-active-io", "C30-midway-stop",
                "C31-crash-journal", "C32-sharing", "C33-protected-bind",
                "C34-special-hardlinks", "C35-negative-admission",
                "C36-review-substitution"}


class Refusal(RuntimeError):
    pass


def need(value, code):
    if not value:
        raise Refusal(code)


def closed(value, keys, code):
    need(type(value) is dict and set(value) == set(keys), code)


def integer(value, low, high):
    return type(value) is int and low <= value <= high


def is_sha(value):
    return type(value) is str and len(value) == 64 and all(x in "0123456789abcdef" for x in value)


def encode(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=True,
                      separators=(",", ":"), allow_nan=False).encode("ascii")


def decode(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            need(key not in result, "duplicate-key")
            result[key] = value
        return result
    def invalid(value):
        raise Refusal("nonfinite-json:" + value)
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=invalid)


def absolute(value):
    need(type(value) is str and len(value) <= 2048, "bounded-native-path")
    drive, tail = ntpath.splitdrive(value)
    need(len(drive) == 2 and drive[1] == ":" and drive[0].isalpha()
         and tail.startswith("\\") and ntpath.abspath(value) == value,
         "canonical-drive-path-required")
    need(":" not in tail and "\x00" not in tail, "ADS-or-device-path")
    need(all(x not in [".", ".."] and not x.endswith((".", " "))
             for x in tail.split("\\") if x), "ambiguous-component")
    return value


class Overlapped(c.Structure):
    _fields_ = [("Internal", c.c_size_t), ("InternalHigh", c.c_size_t),
                ("Offset", w.DWORD), ("OffsetHigh", w.DWORD), ("event", w.HANDLE)]


class BasicProcess(c.Structure):
    _fields_ = [("status", c.c_long), ("peb", c.c_void_p),
                ("affinity", c.c_size_t), ("priority", c.c_long),
                ("pid", c.c_size_t), ("parent", c.c_size_t)]


class UnicodeString(c.Structure):
    _fields_ = [("length", w.USHORT), ("maximum", w.USHORT), ("buffer", c.c_void_p)]


class Native:
    """Lazy actual Win32 boundary. Unknown/truncated queries always refuse."""
    def __init__(self):
        need(os.name == "nt" and c.sizeof(c.c_void_p) == 8, "Windows64-only")
        self.k = c.WinDLL("kernel32", use_last_error=True)
        self.nt = c.WinDLL("ntdll", use_last_error=True)
        self.shell = c.WinDLL("shell32", use_last_error=True)
        self.uncertain = []
        declarations = {
            "CreateFileW": ([w.LPCWSTR, w.DWORD, w.DWORD, c.c_void_p,
                              w.DWORD, w.DWORD, w.HANDLE], w.HANDLE),
            "CloseHandle": ([w.HANDLE], w.BOOL),
            "GetFileInformationByHandleEx": ([w.HANDLE, c.c_int, c.c_void_p, w.DWORD], w.BOOL),
            "GetFinalPathNameByHandleW": ([w.HANDLE, w.LPWSTR, w.DWORD, w.DWORD], w.DWORD),
            "GetVolumeInformationByHandleW": ([w.HANDLE, w.LPWSTR, w.DWORD,
                c.POINTER(w.DWORD), c.POINTER(w.DWORD), c.POINTER(w.DWORD), w.LPWSTR, w.DWORD], w.BOOL),
            "ReadFile": ([w.HANDLE, c.c_void_p, w.DWORD, c.POINTER(w.DWORD), c.c_void_p], w.BOOL),
            "LockFileEx": ([w.HANDLE, w.DWORD, w.DWORD, w.DWORD, w.DWORD,
                             c.POINTER(Overlapped)], w.BOOL),
            "UnlockFileEx": ([w.HANDLE, w.DWORD, w.DWORD, w.DWORD,
                               c.POINTER(Overlapped)], w.BOOL),
            "GetCurrentProcess": ([], w.HANDLE),
            "GetProcessId": ([w.HANDLE], w.DWORD),
            "OpenProcess": ([w.DWORD, w.BOOL, w.DWORD], w.HANDLE),
            "GetProcessTimes": ([w.HANDLE] + [c.POINTER(w.FILETIME)] * 4, w.BOOL),
            "QueryFullProcessImageNameW": ([w.HANDLE, w.DWORD, w.LPWSTR, c.POINTER(w.DWORD)], w.BOOL),
            "WaitForSingleObject": ([w.HANDLE, w.DWORD], w.DWORD),
            "QueryInformationJobObject": ([w.HANDLE, c.c_int, c.c_void_p,
                                            w.DWORD, c.POINTER(w.DWORD)], w.BOOL),
            "GetProcessHandleCount": ([w.HANDLE, c.POINTER(w.DWORD)], w.BOOL),
            "FindFirstFileNameW": ([w.LPCWSTR, w.DWORD, c.POINTER(w.DWORD), w.LPWSTR], w.HANDLE),
            "FindNextFileNameW": ([w.HANDLE, c.POINTER(w.DWORD), w.LPWSTR], w.BOOL),
            "FindClose": ([w.HANDLE], w.BOOL),
        }
        for name, (args, result) in declarations.items():
            fn = getattr(self.k, name)
            fn.argtypes, fn.restype = args, result
        self.nt.NtQueryInformationProcess.argtypes = [w.HANDLE, c.c_int,
            c.c_void_p, w.ULONG, c.POINTER(w.ULONG)]
        self.nt.NtQueryInformationProcess.restype = c.c_long
        self.shell.CommandLineToArgvW.argtypes = [w.LPCWSTR, c.POINTER(c.c_int)]
        self.shell.CommandLineToArgvW.restype = c.POINTER(w.LPWSTR)
        self.k.LocalFree.argtypes, self.k.LocalFree.restype = [c.c_void_p], c.c_void_p

    def query(self, handle, kind, size):
        raw = c.create_string_buffer(size)
        need(self.k.GetFileInformationByHandleEx(handle, kind, raw, size), "native-file-query:" + str(kind))
        return raw.raw

    def open(self, path, access=0x80000080, share=1):
        handle = self.k.CreateFileW(absolute(str(path)), access, share, None, 3, 0x02200000, None)
        need(handle not in (None, c.c_void_p(-1).value), "native-open:" + str(c.get_last_error()))
        return handle

    def close(self, handle):
        if not self.k.CloseHandle(handle):
            self.uncertain.append(handle)
            raise Refusal("native-close-uncertain")

    def meta(self, handle):
        identity = self.query(handle, 18, 24)
        basic, standard = self.query(handle, 0, 40), self.query(handle, 1, 24)
        need(not standard[20], "delete-pending-object")
        text = c.create_unicode_buffer(32768)
        length = self.k.GetFinalPathNameByHandleW(handle, text, len(text), 1)
        need(0 < length < len(text), "native-normalized-volume-path")
        path = text.value
        end = path.find("}\\")
        need(path.startswith("\\\\?\\Volume{") and end > 10, "local-volume-GUID-required")
        volume = path[:end + 2].lower()
        serial, maximum, flags = w.DWORD(), w.DWORD(), w.DWORD()
        filesystem = c.create_unicode_buffer(32)
        need(self.k.GetVolumeInformationByHandleW(handle, None, 0, c.byref(serial),
             c.byref(maximum), c.byref(flags), filesystem, len(filesystem)), "native-volume-query")
        need(filesystem.value == "NTFS", "unqualified-filesystem")
        return dict(identity="win:" + identity.hex(), mount=volume + identity[:8].hex(),
                    path=path, attrs=struct.unpack_from("<I", basic, 32)[0],
                    directory=bool(standard[21]), links=struct.unpack_from("<I", standard, 16)[0],
                    size=struct.unpack_from("<q", standard, 8)[0],
                    stamp=basic[16:32].hex())

    def streams(self, handle):
        raw, offset = self.query(handle, 7, CHUNK), 0
        for unused in range(2048):
            need(offset + 24 <= len(raw), "stream-overflow")
            nxt, length = struct.unpack_from("<II", raw, offset)
            need(length % 2 == 0 and offset + 24 + length <= len(raw), "stream-shape")
            name = raw[offset + 24:offset + 24 + length].decode("utf-16-le", "strict")
            need(name in ("", "::$DATA"), "nondefault-ADS")
            if not nxt:
                return
            need(nxt >= 24 + length, "stream-offset")
            offset += nxt
        raise Refusal("stream-count")

    def read(self, handle, count):
        raw, used = c.create_string_buffer(count), w.DWORD()
        need(self.k.ReadFile(handle, raw, count, c.byref(used), None), "native-read")
        need(used.value <= count, "native-read-count")
        return raw.raw[:used.value]

    def creation(self, handle):
        values = [w.FILETIME() for unused in range(4)]
        need(self.k.GetProcessTimes(handle, *(c.byref(x) for x in values)), "native-process-times")
        return values[0].dwLowDateTime | (values[0].dwHighDateTime << 32)

    def handle_count(self):
        count = w.DWORD()
        need(self.k.GetProcessHandleCount(self.k.GetCurrentProcess(), c.byref(count)), "native-handle-count")
        return count.value

    def members(self, maximum):
        raw = c.create_string_buffer(8 + maximum * c.sizeof(c.c_size_t))
        returned = w.DWORD()
        need(self.k.QueryInformationJobObject(None, 3, raw, len(raw), c.byref(returned)), "current-Job-query")
        assigned, listed = struct.unpack_from("<II", raw)
        need(0 < assigned == listed <= maximum, "current-Job-list-incomplete")
        ids = set((c.c_size_t * listed).from_buffer(raw, 8))
        need(len(ids) == listed and os.getpid() in ids, "current-Job-native-members")
        return ids

    def parent(self):
        value, used = BasicProcess(), w.ULONG()
        need(self.nt.NtQueryInformationProcess(self.k.GetCurrentProcess(), 0,
            c.byref(value), c.sizeof(value), c.byref(used)) == 0, "native-parent-query")
        need(value.pid == os.getpid() and value.parent > 0, "native-parent-identity")
        return value.parent

    def argv(self, handle):
        used = w.ULONG()
        self.nt.NtQueryInformationProcess(handle, 60, None, 0, c.byref(used))
        need(c.sizeof(UnicodeString) <= used.value <= 65536, "native-commandline-bound")
        raw = c.create_string_buffer(used.value)
        need(self.nt.NtQueryInformationProcess(handle, 60, raw, len(raw), c.byref(used)) == 0,
             "native-commandline-unavailable")
        string = UnicodeString.from_buffer(raw)
        start, end = c.addressof(raw), c.addressof(raw) + len(raw)
        need(string.length % 2 == 0 and start <= string.buffer <= end
             and string.buffer + string.length <= end, "native-commandline-pointer")
        text = c.string_at(string.buffer, string.length).decode("utf-16-le", "strict")
        count = c.c_int()
        pointer = self.shell.CommandLineToArgvW(text, c.byref(count))
        need(pointer and 1 <= count.value <= 64, "native-argv-count")
        try:
            return [pointer[i] for i in range(count.value)]
        finally:
            need(not self.k.LocalFree(pointer), "native-argv-free")


class Pin:
    """Own no-follow ancestry and leaf handles until explicitly retired."""
    def __init__(self, native, path, access=0x80000080, share=1):
        self.n, self.path, self.handles = native, absolute(str(path)), []
        self.closed = False
        try:
            item = Path(self.path)
            for ancestor in reversed(item.parents):
                handle = native.open(str(ancestor))
                self.handles.append(handle)
                meta = native.meta(handle)
                need(meta["directory"] and not meta["attrs"] & 0x400, "reparse-ancestor")
            self.handle = native.open(self.path, access, share)
            self.handles.append(self.handle)
            self.meta = native.meta(self.handle)
            need(not self.meta["attrs"] & 0x400, "reparse-reference")
        except BaseException:
            self.close()
            raise

    def close(self):
        if self.closed:
            return
        errors = []
        while self.handles:
            handle = self.handles.pop()   # Retire before attempting a close.
            try:
                self.n.close(handle)
            except BaseException as error:
                errors.append(error)
        self.closed = True
        need(not errors, "pinned-handle-close-uncertain")


class GuardianLease:
    """Actual local byte-lock acquisition; never a caller-provided held flag."""
    def __init__(self, native, token, poll):
        closed(token, {"path", "identity"}, "token-binding")
        need(token["path"] == TOKEN, "wrong-global-token")
        self.n, self.poll, self.locked = native, poll, False
        self.pin = Pin(native, TOKEN, 0xC0000080, 3)
        self.overlapped = Overlapped()
        need(self.pin.meta["identity"] == token["identity"] and not self.pin.meta["directory"]
             and self.pin.meta["links"] == 1 and self.pin.meta["size"] >= 1, "token-native-identity")
        try:
            while True:
                poll()
                if native.k.LockFileEx(self.pin.handle, 3, 0, 1, 0, c.byref(self.overlapped)):
                    self.locked = True
                    self.acquired_perf_ns = time.perf_counter_ns()
                    break
                need(c.get_last_error() == 33, "native-token-lock-error")
                time.sleep(0.02)
        except BaseException:
            self.pin.close()
            raise

    def check(self):
        self.poll()
        need(self.locked and not self.pin.closed and not self.n.uncertain, "local-lease-revoked")
        need(self.n.meta(self.pin.handle) == self.pin.meta, "token-object-mutated")
        return self.acquired_perf_ns

    def release(self):
        self.check()
        self.locked = False               # Never retry uncertain unlock/close.
        if not self.n.k.UnlockFileEx(self.pin.handle, 0, 1, 0, c.byref(self.overlapped)):
            KEEP.append(self)
            raise Refusal("native-token-unlock-uncertain")
        self.pin.close()


class Context:
    """Closed parent admission plus local native proof, scoped to one process."""
    def __init__(self, manifest_path, manifest_sha):
        self.n = Native()
        self.baseline_handles = self.n.handle_count()
        self.baseline_threads = {x.ident for x in threading.enumerate()}
        self.refs, self.plans, self.actors = {}, {}, []
        self.lease, self.parent_handle = None, None
        self.archive_module = None
        self.completed = False
        self.max_refs, self.max_ref_bytes = 512, 64 * 1024**2
        manifest = self.read_ref({"path": manifest_path, "sha256": manifest_sha,
                                  "bytes": Path(manifest_path).stat().st_size})
        self.m = decode(manifest)
        closed(self.m, ENVELOPE, "context-envelope")
        need(self.m["version"] == 1 and type(self.m["version"]) is int
             and self.m["runtime_go"] is True, "no-context-runtime-admission")
        need(self.m["action"] in {"CONTROL", "ARCHIVE_VERIFY", "RETIRE"}
             and type(self.m["real_retire_go"]) is bool, "closed-action")
        need(self.m["action"] == "RETIRE" or self.m["real_retire_go"] is False,
             "retire-grant-on-wrong-action")
        for key in ("parent_capture_sha256", "context_source_sha256"):
            need(is_sha(self.m[key]), "source-SHA")
        need(integer(self.m["deadline_perf_ns"], 1, 2**63 - 1), "perf-deadline")
        need(type(self.m["deadline_epoch"]) in (int, float)
             and math.isfinite(self.m["deadline_epoch"])
             and time.time() < self.m["deadline_epoch"] <= FUNCTIONAL, "functional-deadline")
        self.poll()
        own = Path(__file__).absolute()
        need(hashlib.sha256(self.read_ref({"path": str(own), "bytes": own.stat().st_size,
             "sha256": self.m["context_source_sha256"]})).hexdigest() == self.m["context_source_sha256"],
             "executed-Context-source")
        self.a = decode(self.read_ref(self.m["authority"]))
        closed(self.a, AUTHORITY, "Context-authority")
        need(self.a["version"] == 1 and type(self.a["version"]) is int
             and self.a["engine_commit"] == ENGINE, "fixed-engine-authority")
        closed(self.a["limits"], LIMITS, "Context-limits")
        self.limits = self.a["limits"]
        for key in LIMITS - {"control_root", "evidence_root"}:
            need(integer(self.limits[key], 1, 2**34), "positive-limit:" + key)
        need(self.limits["max_refs"] <= 4096 and self.limits["max_ref_bytes"] <= 64 * 1024**2
             and self.limits["max_aliases"] <= 4096 and self.limits["max_members"] <= 4096,
             "native-collection-limit")
        self.max_refs, self.max_ref_bytes = self.limits["max_refs"], self.limits["max_ref_bytes"]
        need(len(self.refs) <= self.max_refs, "initial-reference-count")
        self.verify_parent()
        self.lease = GuardianLease(self.n, self.a["token"], self.poll)
        self.protected = decode(self.read_ref(self.a["protected_scope"]))
        self.validate_protected()
        self.verify_writers()
        self.archive_raw = self.read_ref(self.a["archive_source"])
        need(len(self.archive_raw) <= 55296, "archive-source-cap")
        self.budget = decode(self.read_ref(self.a["budget"]))
        self.charged_archive = 0
        self.artifact_anchor = None
        self.check_budget(0, 0)

    def poll(self):
        need(time.time() < self.m["deadline_epoch"]
             and time.perf_counter_ns() < self.m["deadline_perf_ns"], "Context-deadline")

    def read_ref(self, ref, load=True):
        closed(ref, {"path", "bytes", "sha256"}, "reference-shape")
        need(is_sha(ref["sha256"]) and integer(ref["bytes"], 0, self.max_ref_bytes), "reference-bound")
        if load:
            need(ref["bytes"] <= 2 * 1024**2, "decoded-reference-bound")
        path = absolute(ref["path"])
        key = (path, ref["bytes"], ref["sha256"])
        if key in self.refs:
            pin, previous = self.refs[key]
            need(self.n.meta(pin.handle) == pin.meta, "reference-lease-mutated")
            need(not load or previous is not None, "reference-not-buffered")
            return previous
        need(len(self.refs) < self.max_refs, "reference-count")
        need(not any(k[0] == path for k in self.refs), "reference-rebinding")
        pin = Pin(self.n, path)
        try:
            need(not pin.meta["directory"] and pin.meta["links"] == 1
                 and pin.meta["size"] == ref["bytes"], "reference-native-shape")
            self.n.streams(pin.handle)
            digest, blocks, size = hashlib.sha256(), [], 0
            while True:
                if hasattr(self, "m"):
                    self.poll()
                block = self.n.read(pin.handle, CHUNK)
                if not block:
                    break
                size += len(block)
                need(size <= ref["bytes"], "reference-growth")
                digest.update(block)
                if load:
                    blocks.append(block)
            need(size == ref["bytes"] and digest.hexdigest() == ref["sha256"]
                 and self.n.meta(pin.handle) == pin.meta, "same-handle-reference-SHA")
            raw = b"".join(blocks) if load else None
            self.refs[key] = (pin, raw)
            return raw
        except BaseException:
            pin.close()
            raise

    def verify_parent(self):
        parent = self.m["parent"]
        closed(parent, {"pid", "creation", "image", "source", "argv"}, "outer-parent-shape")
        need(integer(parent["pid"], 1, 2**32 - 1) and self.n.parent() == parent["pid"],
             "actual-direct-parent")
        self.parent_handle = self.n.k.OpenProcess(0x101000, False, parent["pid"])
        need(self.parent_handle and self.n.k.GetProcessId(self.parent_handle) == parent["pid"]
             and self.n.creation(self.parent_handle) == parent["creation"]
             and self.n.k.WaitForSingleObject(self.parent_handle, 0) == 258, "live-native-parent")
        text, length = c.create_unicode_buffer(32768), w.DWORD(32768)
        need(self.n.k.QueryFullProcessImageNameW(self.parent_handle, 0, text, c.byref(length)),
             "native-parent-image")
        need(ntpath.normcase(text.value) == ntpath.normcase(parent["image"]["path"]), "parent-image-binding")
        self.read_ref(parent["image"], False)
        self.read_ref(parent["source"])
        need(parent["source"]["sha256"] == self.m["parent_capture_sha256"], "capture-source-binding")
        need(type(parent["argv"]) is list and self.n.argv(self.parent_handle) == parent["argv"]
             and parent["source"]["path"] in parent["argv"], "native-parent-source-argv")
        members = self.n.members(self.limits["max_members"])
        need(parent["pid"] not in members, "guardian-must-be-outside-current-Job")

    def verify_writers(self):
        catalog = decode(self.read_ref(self.a["writer_catalog"]))
        closed(catalog, {"version", "root", "freeze_nonce", "engine_commit", "ports", "review"}, "writer-catalog")
        need(catalog["version"] == 1 and catalog["engine_commit"] == ENGINE
             and type(catalog["ports"]) is list and 0 < len(catalog["ports"]) <= 256,
             "source-closed-writer-universe")
        self.read_ref(catalog["review"])
        runs = set()
        for prior in self.a["prior_jobs"]:
            closed(prior, {"raw", "completion", "raw_files"}, "prior-job-shape")
            raw_bytes = self.read_ref(prior["raw"])
            raw, completion = decode(raw_bytes), decode(self.read_ref(prior["completion"]))
            need(completion["receipt_sha256"] == hashlib.sha256(raw_bytes).hexdigest()
                 and completion["qualified"] is True and completion["exit"] == 0
                 and completion["censor"] is None and completion["process_closure_verified"] is True
                 and completion["postwrite_census_complete"] is True, "prior-guard-returned-completion")
            need(raw["errors"] == [] and raw["remaining_job_pids"] == []
                 and raw["rss_evidence"]["gzip_complete"] is True, "prior-raw-native-closure")
            creator, job_close = raw["creator_lifetime"], raw["job_close"]
            need(creator["exact_job_query_succeeded"] is True and creator["in_exact_job"] is False
                 and not creator["handle_flags"] & 1 and creator["source_known_duplicate_handles"] == 0
                 and creator["source_known_inherited_handles"] == 0 and job_close["checked"] is True,
                 "prior-exact-Job-lifetime")
            checks = raw["closure_checks"]
            need(len(checks) == 2 and checks[0]["perf_counter_ns"] < checks[1]["perf_counter_ns"]
                 and all(x["members"] == [] and x["run_nonce"] == raw["run_nonce"] for x in checks),
                 "prior-two-positive-empty-queries")
            need(raw["stdio"] and all(x["complete"] and x["eof"] for x in raw["stdio"].values()),
                 "prior-stdio-complete")
            for ref in prior["raw_files"]:
                self.read_ref(ref, False)
            runs.add(raw["run_nonce"])
        need(type(self.a["prior_jobs"]) is list and len(self.a["prior_jobs"]) <= 64, "prior-job-count")
        for port in catalog["ports"]:
            closed(port, {"name", "source", "function", "ast_sha256", "last_run", "closed_grant"}, "writer-port")
            source = self.read_ref(port["source"])
            tree = ast.parse(source)
            nodes = [n for n in ast.walk(tree) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))
                     and n.name == port["function"]]
            need(len(nodes) == 1 and hashlib.sha256(ast.dump(nodes[0], include_attributes=False).encode()).hexdigest()
                 == port["ast_sha256"] and port["last_run"] in runs, "writer-source-run-binding")
            grant = decode(self.read_ref(port["closed_grant"]))
            need(grant["root"] == catalog["root"] and grant["run_nonce"] == port["last_run"]
                 and grant["freeze_nonce"] == catalog["freeze_nonce"] and grant["state"] == "revoked",
                 "writer-grant-not-revoked")
        self.writers = catalog

    def validate_protected(self):
        closed(self.protected, {"version", "namespace", "roots", "review"}, "protected-scope")
        need(self.protected["version"] == 1 and type(self.protected["roots"]) is list
             and 0 < len(self.protected["roots"]) <= 256, "protected-root-count")
        self.read_ref(self.protected["review"])
        self.protected_pins = []
        for row in self.protected["roots"]:
            closed(row, {"path", "identity", "mount"}, "protected-root")
            pin = Pin(self.n, row["path"])
            need(pin.meta["identity"] == row["identity"] and pin.meta["mount"] == row["mount"],
                 "protected-native-identity")
            self.protected_pins.append(pin)

    def native_scope(self, *, path, handle, identity, parent_path, parent_handle,
                     root, protected_roots, plan_sha256):
        self.check(phase="capture", plan_sha256=plan_sha256, prospective_bytes=0, roots=[root])
        node = self.n.meta(handle)
        need(node["identity"] == identity and not node["attrs"] & 0x400, "node-ID-or-reparse")
        self.n.streams(handle)
        owned_parent = None
        if parent_handle is None:
            owned_parent = Pin(self.n, parent_path)
            parent_handle = owned_parent.handle
        try:
            parent = self.n.meta(parent_handle)
            top = self.root_pin(root)
            need(parent["directory"] and not parent["attrs"] & 0x400
                 and node["mount"] == parent["mount"] == top.meta["mount"], "mounted-node-or-parent")
            canonical = node["path"].casefold()
            base = top.meta["path"].rstrip("\\").casefold()
            need(canonical == base or canonical.startswith(base + "\\"), "outside-root")
            for pin in self.protected_pins:
                protected = pin.meta["path"].rstrip("\\").casefold()
                need(not (canonical == protected or canonical.startswith(protected + "\\")
                     or protected.startswith(canonical.rstrip("\\") + "\\")), "protected-alias")
                need(node["identity"] != pin.meta["identity"], "protected-native-ID")
            if not node["directory"] and node["links"] > 1:
                self.aliases(path, node, base)
            return dict(go=True, epoch=time.time(), backend="win32-pinned-volume-reparse",
                namespace=self.protected["namespace"], mount=node["mount"], parent_mount=parent["mount"],
                root_mount=top.meta["mount"], root_identity=root["identity"], node_identity=identity,
                parent_identity=parent["identity"], protected_roots_sha256=hashlib.sha256(encode(protected_roots)).hexdigest(),
                protected_scope_sha256=self.a["protected_scope"]["sha256"], source_pin=ENGINE,
                guard_sha256=self.m["parent_capture_sha256"], freeze_nonce=self.writers["freeze_nonce"],
                no_protected_alias=True, provider_sha256=self.m["context_source_sha256"])
        finally:
            if owned_parent:
                owned_parent.close()

    def aliases(self, path, node, base):
        size, text = w.DWORD(32768), c.create_unicode_buffer(32768)
        search = self.n.k.FindFirstFileNameW(str(path), 0, c.byref(size), text)
        need(search not in (None, c.c_void_p(-1).value), "native-alias-enumeration")
        seen = set()
        try:
            while True:
                self.poll()
                need(len(seen) < self.limits["max_aliases"], "alias-count")
                alias = node["path"][:node["path"].find("}\\") + 1] + text.value
                need(alias.casefold() not in seen and alias.casefold().startswith(base + "\\"), "external-alias")
                seen.add(alias.casefold())
                # Open via the admitted DOS root, not an unchecked volume/device path.
                root = self.writers["root"]
                suffix = alias[len(base):].lstrip("\\")
                pin = Pin(self.n, ntpath.join(root, suffix))
                try:
                    need(pin.meta["identity"] == node["identity"] and pin.meta["mount"] == node["mount"], "alias-ID")
                finally:
                    pin.close()
                size.value = len(text)
                if not self.n.k.FindNextFileNameW(search, c.byref(size), text):
                    need(c.get_last_error() == 38, "incomplete-alias-enumeration")
                    break
            need(len(seen) == node["links"], "unresolved-alias-closure")
        finally:
            need(self.n.k.FindClose(search), "alias-search-close")

    def root_pin(self, root):
        key = (root["path"], root["identity"])
        if not hasattr(self, "root_pins"):
            self.root_pins = {}
        if key not in self.root_pins:
            pin = Pin(self.n, root["path"])
            need(pin.meta["directory"] and pin.meta["identity"] == root["identity"], "root-native-ID")
            self.root_pins[key] = pin
        pin = self.root_pins[key]
        need(self.n.meta(pin.handle) == pin.meta, "root-mutation")
        return pin

    def plan(self, digest):
        if digest not in self.plans:
            ref = self.a["plan"]
            need(ref["sha256"] == digest, "unregistered-plan")
            self.plans[digest] = decode(self.read_ref(ref))
        return self.plans[digest]

    def check(self, *, phase, plan_sha256, prospective_bytes, roots):
        self.lease.check()
        need(self.n.k.WaitForSingleObject(self.parent_handle, 0) == 258, "outer-guardian-dead")
        members = self.n.members(self.limits["max_members"])
        need(members == {os.getpid()}, "other-live-Job-member")
        plan = self.plan(plan_sha256)
        need(plan["source_pin"] == ENGINE and plan["guard_sha256"] == self.m["parent_capture_sha256"]
             and plan["namespace_freeze_nonce"] == self.writers["freeze_nonce"]
             and roots == plan["roots"] and len(roots) == 1
             and roots[0]["path"] == self.writers["root"], "exact-plan-writer-scope")
        need(plan["native_scope_sha256"] == self.m["context_source_sha256"], "scope-source-binding")
        if self.m["action"] != "CONTROL":
            need(plan["control_only"] is False, "toy-review-cannot-qualify-REAL")
            self.qualification()
        else:
            need(plan["control_only"] is True, "CONTROL-only-plan")
        need(integer(prospective_bytes, 0, self.limits["archive_bytes"]), "prospective-bound")
        self.check_budget(prospective_bytes, 0)
        retiring = phase == "retire"
        if retiring:
            need(self.m["action"] == "RETIRE" and self.m["real_retire_go"] is True,
                 "no-separate-retirement-GO")
            self.archive_proof(plan)
        return dict(go=True, epoch=time.time(), phase=phase, source_pin=ENGINE, host="win32",
            freeze_nonce=self.writers["freeze_nonce"], guard_sha256=self.m["parent_capture_sha256"],
            prior_groups_empty=True, io_closed=True, handles_closed=True, namespace_frozen=True,
            references_frozen=True, archive_protected=retiring, native_delete_reviewed=retiring)

    def qualification(self):
        need(self.a["qualification"] is not None, "missing-complete-Windows-qualification")
        proof = decode(self.read_ref(self.a["qualification"]))
        closed(proof, {"engine_commit", "required", "completed", "case_refs", "unit_refs", "review"}, "qualification-shape")
        need(proof["engine_commit"] == ENGINE and type(proof["required"]) is list
             and len(proof["required"]) >= 166 and proof["required"] == sorted(set(proof["required"]))
             and proof["completed"] == proof["required"] and proof["unit_refs"], "incomplete-Windows-catalog")
        self.read_ref(proof["review"])
        need(len(proof["case_refs"]) == len(proof["required"]), "case-proof-count")
        for case_id, ref in zip(proof["required"], proof["case_refs"]):
            row = decode(self.read_ref(ref))
            need(row["case_id"] == case_id and row["engine_commit"] == ENGINE
                 and row["status"] == "PASS" and row["oracle_refs"] and row["native_refs"], "case-not-qualified")
            for raw in row["oracle_refs"] + row["native_refs"]:
                self.read_ref(raw, False)
        for ref in proof["unit_refs"]:
            self.read_ref(ref, False)

    def archive_proof(self, plan):
        need(plan["operation"] == "RETIRE" and is_sha(plan["archive_sha256"]), "retire-permit-binding")
        path = ntpath.join(plan["artifact_root"], "archive.gz")
        info = os.stat(path, follow_symlinks=False)
        self.read_ref({"path": path, "bytes": info.st_size, "sha256": plan["archive_sha256"]}, False)
        need(info.st_size <= self.limits["archive_bytes"], "archive-owner-cap")
        # The helper itself strictly re-reads the full stream and source before any unlink.

    def census(self, root):
        root = absolute(root)
        total = files = 0
        if not os.path.exists(root):
            parent = Pin(self.n, str(Path(root).parent))
            parent.close()
            return 0, 0
        for directory, dirs, names in os.walk(root, followlinks=False):
            self.poll()
            for name in dirs + names:
                path = ntpath.join(directory, name)
                info = os.lstat(path)
                need(not getattr(info, "st_file_attributes", 0) & 0x400, "budget-reparse")
                if name in names:
                    total += info.st_size
                    files += 1
        return total, files

    def check_budget(self, prospective_bytes, prospective_files):
        closed(self.budget, {"version", "root_caps", "review"}, "Context-budget")
        need(self.budget["version"] == 1, "Context-budget-version")
        self.read_ref(self.budget["review"])
        for rule in self.budget["root_caps"]:
            closed(rule, {"root", "bytes", "files", "reserve_bytes", "reserve_files"}, "root-budget")
            actual, files = self.census(rule["root"])
            need(actual + rule["reserve_bytes"] <= rule["bytes"]
                 and files + rule["reserve_files"] <= rule["files"], "whole-coexistence-budget")
        # Full archive reservation is registered once, not re-added per 64KiB write.
        if prospective_bytes:
            need(prospective_bytes <= self.limits["archive_bytes"]
                 and self.limits["artifact_files"] >= 5, "full-archive-ticket")
            self.charged_archive = max(self.charged_archive, prospective_bytes)
        free = w.ULARGE_INTEGER() if hasattr(w, "ULARGE_INTEGER") else c.c_ulonglong()
        self.n.k.GetDiskFreeSpaceExW.argtypes = [w.LPCWSTR, c.c_void_p, c.c_void_p, c.c_void_p]
        self.n.k.GetDiskFreeSpaceExW.restype = w.BOOL
        need(self.n.k.GetDiskFreeSpaceExW("C:\\", c.byref(free), None, None)
             and free.value >= 140 * 1024**3, "Windows-free-floor")

    def archive(self):
        if self.archive_module is None:
            import types
            module = types.ModuleType("owned_archive_" + self.a["archive_source"]["sha256"][:12])
            module.__file__ = self.a["archive_source"]["path"]
            exec(compile(self.archive_raw, module.__file__, "exec"), module.__dict__)
            self.archive_module = module
        return self.archive_module

    def prepare_control_plan(self, prepared):
        raise Refusal("PENDING:R3-control-plan-native-scope-constructor-binding")

    def admit_controls(self, *, expected, forecast):
        need(self.m["action"] == "CONTROL", "no-CONTROL-authority")
        self.lease.check()
        need(expected["control_only"] is True and expected["source_pin"] == ENGINE
             and expected["scope_sha256"] == self.m["context_source_sha256"]
             and expected["archive_sha256"] == self.a["archive_source"]["sha256"]
             and absolute(expected["root"]) == self.limits["control_root"], "control-batch-binding")
        need(forecast["cells"] == 38 and forecast["engine_qualification"] is False, "control-catalog")
        self.check_budget(forecast["fixture_archive_restore_partial_bytes"],
                          forecast["fixture_archive_restore_partial_files"])
        return dict(expected, go=True, epoch=time.time())

    def before_control_write(self, *, expected):
        self.lease.check()
        need(self.m["action"] == "CONTROL" and expected["phase"] == "case"
             and ntpath.dirname(expected["root"]) == self.limits["control_root"], "control-case-root")
        self.check_budget(expected["prospective_bytes"], expected["prospective_files"])
        return dict(expected, go=True, epoch=time.time())

    def exercise_native_control(self, **request):
        raise Refusal("PENDING:eleven-source-bound-native-fault-schedules")

    def after_control(self, *, case_id, root, deadline_epoch):
        self.lease.check()
        need(not self.n.uncertain and threading.active_count() == len(self.baseline_threads), "control-IO-uncertain")

    def finalize_controls(self, *, result, root, deadline_epoch):
        need(result["control_only"] is True and result["engine_qualification"] is False,
             "control-result-scope")
        self.check_budget(0, 0)

    def finish(self):
        """Release only after reviewed synchronous helper and actual handle closure."""
        need(not self.completed, "Context-finish-twice")
        pins = [pin for pin, raw in self.refs.values()]
        pins += getattr(self, "protected_pins", []) + list(getattr(self, "root_pins", {}).values())
        for pin in reversed(pins):
            pin.close()
        if self.parent_handle:
            handle, self.parent_handle = self.parent_handle, None
            self.n.close(handle)
        need(not self.n.uncertain and not self.actors
             and {x.ident for x in threading.enumerate()} <= self.baseline_threads, "owned-IO-callbacks-unclosed")
        expected = self.baseline_handles + len(self.lease.pin.handles)
        need(self.n.handle_count() == expected, "archive-or-other-native-handle-leak")
        self.lease.release()
        self.completed = True


def main(argv):
    need(len(argv) == 3 and is_sha(argv[2]), "closed-Context-CLI")
    context = None
    try:
        context = Context(absolute(argv[1]), argv[2])
        archive = context.archive()
        plan = context.a["plan"]
        if context.m["action"] == "CONTROL":
            need(context.a["controls_source"] is not None, "missing-R3-controls-source")
            raise Refusal("PENDING:R3-constructor-and-native-control-dispatch")
        elif context.m["action"] == "ARCHIVE_VERIFY":
            result = archive.archive(plan["path"], plan["sha256"], context)
            archive.verify(plan["path"], plan["sha256"], result["compressed_sha256"], context)
        else:
            need(context.m["real_retire_go"] is True, "no-real-retire-GO")
            result = archive.retire(plan["path"], plan["sha256"], context)
        context.finish()
        sys.stdout.buffer.write(encode(dict(status="CONTEXT_COMPLETE", action=context.m["action"],
                                           result=result, engine_qualification=False)) + b"\n")
        return 0
    except BaseException as error:
        if context is not None and not context.completed:
            try:
                context.finish()
            except BaseException:
                KEEP.append(context)  # Actual token capability stays owned until process exit.
        sys.stderr.buffer.write(encode(dict(status="CONTEXT_REFUSED", error=type(error).__name__,
                                           reason=str(error)[:512], expiry_credit=0)) + b"\n")
        return 2


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))

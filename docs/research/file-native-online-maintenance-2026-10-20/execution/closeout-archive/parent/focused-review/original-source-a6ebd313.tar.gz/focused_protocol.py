"""Shared, source-only focused schedules. No native process/guard policy here.

The injected Driver preserves raw native events. Adapter owns forecasts, paths,
barriers, process identity/RSS/closure and evidence persistence. Oracle is an
independent complete decoder, never engine audit. See README for exact boundary.
"""
import copy
import hashlib
import json
import math
import threading
from contextlib import contextmanager, ExitStack

MIB = 1024**2
READERS = frozenset({'resolve', 'point', 'inspect', 'lookup-bench'})
FUNCTIONAL_CUTOFF = 1792581014  # 2026-10-21T11:10:14Z; never reset per worker
ORACLE_CHECKS = frozenset({
    'complete_physical', 'all_accepted_outcomes', 'exact_request_intents',
    'selected_membership', 'graph', 'source_bytes', 'navigation', 'provenance',
    'retired_refusals', 'b_loose_controls', 'ordinary_selected_once_b',
    'read_only_inventory',
})


class Unsupported(RuntimeError):
    pass


def require(condition, message):
    # Assertions are deliberately not used for qualification checks: python -O
    # cannot silently remove them.
    if not condition:
        raise RuntimeError(message)


def strict(raw, limit):
    require(type(raw) is bytes and len(raw) <= limit, 'bounded-bytes-required')
    def unique(items):
        result = {}
        for key, value in items:
            require(key not in result, 'duplicate-json-key')
            result[key] = value
        return result
    def invalid(value):
        raise ValueError('nonfinite-json:'+value)
    return json.loads(raw, object_pairs_hook=unique, parse_constant=invalid)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def relative(name):
    require(isinstance(name, str) and name and '\\' not in name and ':' not in name
            and not name.startswith('/') and all(p not in ('', '.', '..') for p in name.split('/')),
            'owned-relative-path-required')
    return name


def normalize(request):
    """Match the retained independent outcome oracle's Request/Op normalization."""
    require(type(request) is dict and set(request) <= {'request', 'base', 'ops', 'packet'}
            and {'request', 'base', 'ops'} <= set(request), 'closed-request-shape')
    require(isinstance(request['request'], str) and type(request['ops']) is list,
            'request-types')
    base = request['base']
    if base is not None:
        require(type(base) is dict and set(base) == {'publication', 'digest'}, 'selector-shape')
        base = dict(publication=base['publication'], digest=base['digest'])
    ops = []
    for op in request['ops']:
        require(type(op) is dict and {'kind', 'id'} <= set(op)
                and set(op) <= {'kind', 'id', 'text', 'target', 'value'}, 'closed-op-shape')
        value = op.get('value', 0)
        require(type(value) is int and 0 <= value < 2**64, 'u64-op-value')
        ops.append(dict(kind=op['kind'], id=op['id'], text=op.get('text', ''),
                        target=op.get('target', ''), value=value))
    packet = request.get('packet', True)
    require(type(packet) is bool, 'packet-boolean')
    return dict(request=request['request'], base=base, ops=ops, packet=packet)


def intent(request):
    return sha(json.dumps(normalize(request), indent=2, ensure_ascii=False,
                          allow_nan=False).encode())


class Inputs:
    """Never overwrite differing captured bases by request ID under concurrency."""
    def __init__(self):
        self.attempts = {}
        self.accepted = {}
        self.lock = threading.Lock()

    def record(self, request):
        request = copy.deepcopy(request)
        key = (request['request'], intent(request))
        with self.lock:
            self.attempts.setdefault(key, request)
        return key

    def accept(self, request, result, selected):
        key = self.record(request)
        require(result.get('outcome') == 'accepted' and result.get('request') == key[0]
                and result.get('publication') == selected.get('publication'), 'accepted-result-binding')
        with self.lock:
            prior = self.accepted.get(key[0])
            value = dict(intent=key[1], request=copy.deepcopy(request),
                         result=copy.deepcopy(result), selected=copy.deepcopy(selected))
            require(prior is None or prior == value, 'conflicting-accepted-input')
            self.accepted[key[0]] = value

    def oracle_inputs(self):
        with self.lock:
            return {name: copy.deepcopy(row['request']) for name, row in self.accepted.items()}


class ThreadCalls:
    """Optional Adapter mixin; threads only call the injected guarded Driver.

    Adapter close_case MUST also close native descendants if a join fails. This
    helper provides no kill/cancel implementation and no native safety claim.
    """
    def spawn(self, callback):
        state = {'response': None, 'error': None}
        def run():
            try:
                state['response'] = callback()
            except BaseException as error:
                state['error'] = error
        state['thread'] = threading.Thread(target=run, daemon=False)
        state['thread'].start()
        return state

    def alive(self, handle):
        return handle['thread'].is_alive()

    def wait(self, handle, timeout):
        handle['thread'].join(timeout)
        require(not self.alive(handle), 'join-timeout-adapter-must-close-descendants')
        if handle['error'] is not None:
            raise handle['error']
        return handle['response']


def mapping_identity(state):
    """Catalog/descriptor content identity, separate from id/ordinal/work CAS."""
    return sha(json.dumps(state['catalog'], sort_keys=True, separators=(',', ':')).encode())


def descriptor_identities(state):
    return {json.dumps(row, sort_keys=True, separators=(',', ':'))
            for row in state['catalog']['packs']}


def transition(before, after):
    old, new = before['store']['physical'], after['store']['physical']
    require(new['id'] != old['id'] and new['ordinal'] == old['ordinal']+1,
            'distinct-next-physical-generation-required')
    require(mapping_identity(before) != mapping_identity(after), 'unchanged-mapping-not-activation-stress')
    require(descriptor_identities(after)-descriptor_identities(before), 'new-mapping-descriptor-required')


def quantiles(values):
    require(bool(values), 'no-samples')
    ordered = sorted(values)
    return dict(count=len(values), p50=ordered[math.ceil(len(values)*.50)-1],
                p95=ordered[math.ceil(len(values)*.95)-1],
                exploratory_p99=ordered[math.ceil(len(values)*.99)-1], max=ordered[-1])


class Harness:
    def __init__(self, driver, adapter, oracle, emit, *, final_pin):
        require(__debug__, 'optimized-Python-disables-injected-driver-checks')
        require(len(final_pin) == 40 and all(c in '0123456789abcdef' for c in final_pin), 'exact-final-pin')
        self.driver, self.a, self.oracle, self.emit = driver, adapter, oracle, emit
        self.final_pin = final_pin
        self.ledgers = {}
        self.lock = threading.Lock()
        self.active = set()
        self.oracles = []

    def adopt_inputs(self, root, records, *, seed_receipt_sha256):
        """Attach complete externally authenticated donor inputs without cloning."""
        require(len(seed_receipt_sha256) == 64 and root not in self.ledgers,
                'fresh-authenticated-donor-input-binding')
        ledger = Inputs()
        for row in records:
            ledger.accept(row['request'], row['result'], row['selected'])
        require(bool(ledger.accepted), 'complete-donor-inputs-required')
        self.ledgers[root] = ledger
        self.note('donor-inputs-adopted', root=str(root), seed_receipt_sha256=seed_receipt_sha256,
                  accepted=len(ledger.accepted), no_clone=True)

    def note(self, kind, **fields):
        # Sink must reserve before append, flush, retain every failed prefix and
        # must never redact or replace a failed event with a later success.
        with self.lock:
            self.emit(dict(kind=kind, final_pin=self.final_pin, **copy.deepcopy(fields)))

    def check_time(self):
        require(self.a.wall_time() < FUNCTIONAL_CUTOFF, 'functional-cutoff')

    @contextmanager
    def case(self, case_id, root, forecast):
        """Forecast/GO before any store/control writes; closure even on failure."""
        self.check_time()
        require(root not in self.active, 'case-root-already-owned')
        permit = self.a.preflight(case_id, root, copy.deepcopy(forecast), self.final_pin)
        require(permit.get('go') is True and permit.get('case_id') == case_id
                and permit.get('root') == str(root) and permit.get('final_pin') == self.final_pin,
                'case-forecast-or-meta-GO-missing')
        require(permit.get('reader_limit') == 256*MIB and permit.get('checker_limit') == 2048*MIB,
                'independent-reader-checker-roles-required')
        require(permit.get('default_payloads') is True, 'default-payload-profile-required')
        require(permit.get('heavy_token') and permit.get('host_guard'), 'guard-token-required')
        require(permit.get('binary_sha256') == self.driver.binary_sha256
                and permit.get('binary_source_pin') == self.final_pin
                and all(isinstance(permit.get(key), str) and len(permit[key]) == 64 for key in
                        ('binary_sha256', 'source_manifest_sha256', 'adapter_sha256', 'guard_sha256')),
                'source-binary-adapter-guard-bindings-required')
        self.active.add(root)
        self.ledgers.setdefault(root, Inputs())
        self.note('case-start', case_id=case_id, root=str(root), forecast=forecast, permit=permit)
        failure = None
        try:
            yield
        except BaseException as error:
            failure = repr(error)
            self.note('case-failure', case_id=case_id, root=str(root), error=failure)
            raise
        finally:
            self.active.remove(root)
            closure = self.a.close_case(case_id, root)
            self.note('case-closure', case_id=case_id, root=str(root), failure=failure, closure=closure)
            require(closure.get('processes_closed') is True and closure.get('handles_closed') is True,
                    'positive-native-process-handle-closure-required')
            # This is only a schedule outcome. External CaseLedger still requires
            # authentic raw evidence, full oracles and source/native bindings.
            if failure is None:
                self.note('schedule-complete-unqualified', case_id=case_id, root=str(root))

    def call(self, root, action, *, timeout=120, code=0, allowed_errors=(), **fields):
        require(root in self.active, 'unadmitted-root')
        self.check_time()
        role = 'reader' if action in READERS else 'checker'
        self.a.before_call(root, action, role, min(timeout, FUNCTIONAL_CUTOFF-self.a.wall_time()))
        payload = dict(root=str(root), action=action, **copy.deepcopy(fields))
        self.note('request-before-dispatch', input=payload, expected_exit=code, role=role)
        try:
            response = self.driver.call(root, action, timeout=min(timeout, FUNCTIONAL_CUTOFF-self.a.wall_time()),
                                        code=code, **fields)
        except AssertionError as error:
            # Existing Windows/Linux Driver.call accepts one expected exit, but
            # a concurrent publish can legitimately return 0 OR semantic exit2.
            # Those drivers retain their exact raw row in AssertionError(row).
            # Recover only this invocation's authentic, violation-free exit2;
            # never use shared driver.last (which races concurrent calls).
            row = error.args[0] if error.args and type(error.args[0]) is dict else {}
            if not (allowed_errors and row.get('input') == payload and row.get('exit') == 2
                    and row.get('violations') == [] and isinstance(row.get('stdout'), str)):
                self.note('call-failure', input=payload, expected_exit=code, error=repr(error))
                raise
            response = strict(row['stdout'].encode(), 4*MIB)
            require(response.get('status') == 'error' and response.get('error') in allowed_errors,
                    'unexpected-native-refusal')
            self.note('authentic-semantic-refusal', input=payload, response=response,
                      raw_driver_row_retained=True)
        except BaseException as error:
            self.note('call-failure', input=payload, expected_exit=code, error=repr(error))
            raise
        self.note('call-result', input=payload, expected_exit=code, response=response)
        if code == 0:
            require(type(response) is dict and (response.get('status') == 'ok' or
                    response.get('status') == 'error' and response.get('error') in allowed_errors),
                    'engine-success-or-declared-semantic-envelope')
        elif code == 2:
            require(type(response) is dict and response.get('status') == 'error', 'engine-error-envelope')
        return response

    def read(self, root, name, limit=128*1024):
        raw = self.a.read(root, relative(name), limit)
        require(type(raw) is bytes and len(raw) <= limit, 'adapter-read-bound')
        return raw

    def document(self, root, name, limit=128*1024):
        return strict(self.read(root, name, limit), limit)

    def selected(self, root):
        return self.document(root, 'SELECTED.json', 65536)

    def state(self, root):
        store = self.document(root, 'STORE.json', 65536)
        require(store.get('catalog') is not None and store.get('physical') is not None,
                'generation-catalog-required')
        catalog_raw = self.read(root, 'pack-catalogs/'+store['catalog']+'.json', 65536)
        require(sha(catalog_raw) == store['catalog'], 'catalog-hash')
        plan_raw = self.read(root, 'physical-plans/'+store['physical']['plan']+'.json')
        require(sha(plan_raw) == store['physical']['plan'], 'work-plan-hash')
        value = dict(store=store, catalog=strict(catalog_raw, 65536), work=strict(plan_raw, 128*1024),
                     selected=self.selected(root))
        self.note('selected-state', root=str(root), state=value)
        return value

    def containers(self, state):
        names = []
        for desc in state['catalog']['packs']:
            prefix = 'packs/'+(desc['instance']+'/' if desc.get('instance') else '')
            names.extend([relative(prefix+desc['pack']+'.pack'), relative(prefix+desc['index']+'.idx')])
        return names

    def initialize(self, root, mode, count=64):
        self.call(root, 'init', mode=mode, consumer='project', count=count)
        self.call(root, 'lifecycle', operation='setup')
        request = dict(request='initial', base=None, ops=[], packet=False)
        result = self.call(root, 'resolve', request_id='initial')['result']
        self.ledgers[root].accept(request, result, self.selected(root))

    def publish(self, root, name, ops=None, *, retries=32, code=0, env=None):
        for retry in range(retries):
            request = dict(request=name, base=self.selected(root), ops=ops or [], packet=False)
            self.ledgers[root].record(request)
            # Conflicts are returned as normal publish outcomes by the engine;
            # process errors/timeouts are never silently retried here.
            response = self.call(root, 'publish', request=request, code=code, env=env,
                                 allowed_errors=('conflict:captured-base', 'conflict:expected-publication')
                                 if code == 0 else ())
            if code != 0:
                return response
            if response.get('status') == 'error':
                self.note('semantic-conflict', request=request, response=response, retry=retry)
                continue
            result = response['result']
            if result.get('result', {}).get('outcome') == 'accepted':
                self.ledgers[root].accept(request, result['result'], result['selected'])
                return response
            self.note('semantic-publication-nonaccept', request=request, response=response, retry=retry)
            # Only an explicit semantic conflict gets another captured base.
            require(result.get('status') == 'conflict' or result.get('result', {}).get('outcome') == 'conflict',
                    'unexpected-publication-nonaccept')
        raise RuntimeError('semantic-retry-bound')

    def pack(self, root, codec='zstd', **fields):
        options = dict(operation='build', codec=codec, include_attempts=True, cleanup=False, force=True)
        options.update(fields)
        return self.call(root, 'packing', **options)

    def cleanup(self, root, *, max_batches=160, require_complete=True):
        """A bounded pass; all batches retained. Not equivalent to two-pass gate."""
        batches = []
        for _ in range(max_batches):
            row = self.call(root, 'packing', operation='cleanup')
            result = row['result']
            require(type(result.get('candidates')) is int and result['candidates'] <= 1000,
                    'cleanup-candidate-counter-required')
            require(type(result.get('batch_ns')) is int, 'cleanup-work-clock-required')
            if result['batch_ns'] > 50_000_000:
                self.note('cleanup-cooperative-target-miss', result=result,
                          qualification='native calls are indivisible; retain overrun')
            batches.append(result)
            if result['status'] == 'complete':
                return batches
        if require_complete:
            raise RuntimeError('cleanup-batch-watchdog')
        return batches

    def drain_two_passes(self, root):
        passes = []
        for number in range(2):
            # One maintenance invocation per pass. Do not relabel 160 batches
            # as a single pass to conceal a missed two-pass drainage target.
            batches = self.cleanup(root, max_batches=1, require_complete=False)
            pending = self.a.backlog(root)  # independent reachability/census, not journal text
            require({'unprotected', 'protected', 'excluded'} <= set(pending), 'complete-backlog-categories')
            passes.append(dict(number=number+1, batches=batches, backlog=pending))
        self.note('two-drainage-passes', root=str(root), passes=passes)
        require(passes[-1]['backlog']['unprotected'] == 0, 'unprotected-backlog-after-two-passes')
        return passes

    def verify(self, root, checkpoint, *, mapped_keys=()):
        self.check_time()
        self.a.quiesce(root)  # proves no active engine I/O, does not revoke held readers
        inputs = self.ledgers[root].oracle_inputs()
        proof = self.oracle(root=root, checkpoint=checkpoint, final_pin=self.final_pin,
                            known_requests=inputs, required_mapped_keys=list(mapped_keys))
        self.note('independent-full-oracle', root=str(root), checkpoint=checkpoint, proof=proof)
        require(proof.get('status') == 'passed' and proof.get('final_pin') == self.final_pin,
                'full-independent-oracle-required')
        require(proof.get('engine_code_imported') is False and proof.get('engine_audit_used') is False,
                'engine-audit-is-not-independent-oracle')
        require(ORACLE_CHECKS <= set(proof.get('checks', [])), 'incomplete-independent-oracle')
        require(proof.get('actual_H') == len(inputs), 'complete-accepted-history-count')
        require(set(mapped_keys) <= set(proof.get('mapped_keys', [])), 'new-tail-not-authentically-mapped')
        require(proof.get('receipt_sha256') and proof.get('source_unchanged') is True,
                'bound-read-only-oracle-receipt')
        self.oracles.append(proof)
        return proof

    def check_outcomes(self, root):
        for name, expected in list(self.ledgers[root].accepted.items()):
            require(self.call(root, 'resolve', request_id=name)['result'] == expected['result'],
                    'exact-outcome:'+name)

    @contextmanager
    def barrier(self, root, name, action, phase, **fields):
        require('barrier:'+phase in self.a.capabilities, 'unsupported-checkpoint:'+phase)
        control = self.a.control(root, name)
        env = dict(fields.pop('env', {}) or {}, EXP_BARRIER=phase,
                   EXP_READY=control['ready'], EXP_RELEASE=control['release'])
        handle = self.a.spawn(lambda: self.call(root, action, env=env, timeout=60, **fields))
        failure = None
        try:
            self.a.await_ready(control, handle, 10)
            require(self.a.alive(handle), 'barrier-process-ended-before-schedule')
            yield handle, control
        except BaseException as error:
            failure = error
            raise
        finally:
            self.a.release(control)
            try:
                response = self.a.wait(handle, 15)
                self.note('barrier-completed', root=str(root), phase=phase, response=response)
            except BaseException as error:
                self.note('barrier-join-failed', root=str(root), phase=phase, error=repr(error))
                if failure is None:
                    raise

    def coupled_capture(self, root, label, codec='zstd'):
        """Run on an initialized/discovered lineage; no fixture clone required."""
        before = self.state(root)
        containers = self.containers(before)
        request_id = label+'-tail-during-gap'
        expected = None
        held_since = self.a.monotonic()
        with self.barrier(root, label+'-capture', 'resolve', 'pack-catalog-captured',
                          request_id=request_id) as (handle, control):
            held_since = self.a.monotonic()
            published = self.publish(root, request_id)['result']
            expected = published['result']
            key = 'publications/'+published['selected']['publication']+'.json'
            raw = self.read(root, key, 128*1024)
            # Mapping observation is independently decoded by Adapter/Oracle
            # outside measured engine operations, with an explicit receipt.
            for successor in range(2):
                if successor:
                    self.publish(root, label+'-second-successor')
                prior = self.state(root)
                self.pack(root, codec)
                after = self.state(root)
                transition(prior, after)
                mapping = self.a.mapping(root, key)
                require(mapping.get('mapped') is True and mapping.get('raw_sha256') == sha(raw)
                        and mapping.get('independent') is True and mapping.get('receipt_sha256'),
                        'coupled-tail-mapping-proof')
                self.cleanup(root, max_batches=1, require_complete=False)
                require(self.a.alive(handle), 'old-reader-ended-before-two-successors')
                require(self.read(root, key, 128*1024) == raw, 'old-unmapped-loose-fallback-deleted')
                require(all(self.a.exists(root, p) for p in containers), 'old-container-deleted-while-pinned')
                require(self.call(root, 'resolve', request_id=request_id)['result'] == expected,
                        'new-reader-exact-result')
            self.a.sleep(max(0.0, 16.1-(self.a.monotonic()-held_since)))
            require(self.a.alive(handle) and self.a.monotonic()-held_since > 15,
                    'old-reader-must-survive-more-than-15s')
            # Release/resume occurs in context manager; no deletion assertion
            # after release is made until the reader has positively joined.
        require(handle['response']['result'] == expected, 'old-reader-exact-late-tail-result')
        self.note('old-reader-resumed', root=str(root), key=key,
                  held_seconds=self.a.monotonic()-held_since, exact_result=expected)
        self.drain_two_passes(root)
        # Rolling successors may intentionally share the stable base. A live
        # selected container must survive even after the old reader releases.
        # Actual obsolete-container deletion is a separate mandatory crash case.
        selected_containers = set(self.containers(self.state(root)))
        obsolete = set(containers)-selected_containers
        shared = set(containers) & selected_containers
        require(not any(self.a.exists(root, p) for p in obsolete), 'obsolete-old-container-not-reaped')
        require(all(self.a.exists(root, p) for p in shared), 'shared-live-container-was-reaped')
        hproof = dict(obsolete_containers=sorted(obsolete), shared_live_containers=sorted(shared),
                      actual_old_container_removal_covered_here=bool(obsolete))
        self.note('post-reader-container-reachability', root=str(root), proof=hproof)
        if self.document(root, 'STORE.json', 65536)['mode'] == 'A':
            require(not self.a.exists(root, key), 'A-loose-fallback-not-reaped-after-resume')
        else:
            require(self.read(root, key, 128*1024) == raw, 'B-publication-control-must-remain-loose')
        self.verify(root, label+'-post-resume-reap', mapped_keys=[key])

    def concurrent_cycle(self, root, label, publishers, accepted=16, readers=4, codec='zstd',
                         collect_conflicts=False):
        require(publishers in (1, 4) and readers == 4 and accepted >= 16, 'required-concurrency-shape')
        accepted_before = len(self.ledgers[root].accepted)
        self.a.begin_phase(root, label)
        # Four independent native readers remain alive while publishers and
        # maintenance run. Threads without positive native intervals do not count.
        with ExitStack() as stack:
            held = [stack.enter_context(self.barrier(root, f'{label}-reader-{i}', 'resolve',
                    'pack-catalog-captured', request_id='initial'))[0] for i in range(readers)]
            for number in range(accepted):
                if publishers == 1:
                    self.publish(root, f'{label}-p0-{number}', retries=1)
                    self.pack(root, codec)
                else:
                    # Exactly four attempts/round, all on the SAME captured base.
                    # All four reach candidate-ready before any is released:
                    # actual overlapping prepared work, not serialized frontend.
                    # Exactly one may select; all failed B generations stay charged.
                    require('barrier:candidate-ready' in self.a.capabilities, 'candidate-ready-map-required')
                    base = self.selected(root)
                    requests = [dict(request=f'{label}-round{number}-p{i}', base=base,
                                     ops=[], packet=False) for i in range(4)]
                    controls = [self.a.control(root, f'{label}-round{number}-p{i}') for i in range(4)]
                    for request in requests:
                        self.ledgers[root].record(request)
                    calls = []
                    try:
                        for request, control in zip(requests, controls):
                            env = dict(EXP_BARRIER='candidate-ready', EXP_READY=control['ready'],
                                       EXP_RELEASE=control['release'])
                            calls.append(self.a.spawn(lambda request=request, env=env:
                                self.call(root, 'publish', request=request, env=env, timeout=60,
                                          allowed_errors=('conflict:captured-base', 'conflict:expected-publication'))))
                        for control, handle in zip(controls, calls):
                            self.a.await_ready(control, handle, 10)
                        require(all(self.a.alive(handle) for handle in calls), 'four-native-preparations-not-overlapping')
                        self.pack(root, codec)
                        # Capture exact candidate owner bytes while every native
                        # publisher is positively paused, before any can select.
                        candidates = self.a.prepared_candidates(root, requests) if collect_conflicts else None
                    finally:
                        for control in controls:
                            self.a.release(control)
                    outcomes, failures = [], []
                    for request, handle in zip(requests, calls):
                        try:
                            response = self.a.wait(handle, 15)
                            outcomes.append(response)
                            if response.get('status') == 'ok':
                                value = response['result']
                                self.ledgers[root].accept(request, value['result'], value['selected'])
                            else:
                                self.note('semantic-conflict', request=request, response=response, retry=0)
                        except BaseException as error:
                            failures.append(repr(error))
                    require(not failures, 'concurrent-call-failures:'+repr(failures))
                    require(sum(row.get('status') == 'ok' for row in outcomes) == 1,
                            'same-base-four-prepared-round-must-select-exactly-once')
                    if collect_conflicts:
                        self.collect_failed_round(root, label+'-round'+str(number), requests, outcomes, candidates)
                require(all(self.a.alive(handle) for handle in held), 'four-held-reader-processes-ended')
        require(all(handle['response']['result'] == self.ledgers[root].accepted['initial']['result']
                    for handle in held), 'concurrent-old-reader-outcomes')
        require(len(self.ledgers[root].accepted)-accepted_before == accepted,
                'new-accepted-publication-count')
        self.pack(root, codec)
        self.drain_two_passes(root)
        overlap = self.a.overlap(root, label, publishers=publishers, readers=readers)
        self.note('concurrency-native-intervals', root=str(root), label=label, proof=overlap)
        require(overlap.get('positive_native_intervals') is True
                and overlap.get('independent_reader_processes') == 4
                and overlap.get('publisher_processes') >= publishers
                and overlap.get('maintenance_overlap') is True, 'native-concurrency-not-proven')
        self.note('bounded-concurrency-attempts', label=label, accepted=accepted,
                  attempted=accepted*publishers, failed_prepared_generations=accepted*(publishers-1),
                  raw_failed_prefix_evidence_retained=True, no_implicit_retries=True,
                  failed_corpus_policy='engine-abandon-collect-each-round' if collect_conflicts else 'retain-all')
        self.verify(root, label+'-cycle-boundary')

    def collect_failed_round(self, root, label, requests, outcomes, candidates):
        """Optional frozen policy, using supported owner abandonment/semantic GC.

        No planned bytes are credited. Exact owner/raw prefix evidence and full
        independent oracles precede collection. The next command remains blocked
        until a real before/after census proves actual engine removal.
        """
        require('failed-round-collection' in self.a.capabilities, 'failed-round-collection-adapter-required')
        require(type(candidates) is dict and set(candidates) == {r['request'] for r in requests},
                'all-four-prepared-candidate-owners-required')
        failed = []
        for request, response in zip(requests, outcomes):
            item = candidates[request['request']]
            raw = item['bytes']
            candidate = strict(raw, 4*MIB)
            require(candidate.get('request') == request and candidate.get('intent') == intent(request)
                    and candidate.get('expected') == request['base']
                    and item['path'] == 'attempts/'+candidate['attempt']+'/candidate.json',
                    'exact-native-prepared-owner-binding')
            self.note('prepared-prefix-raw-candidate', root=str(root), label=label,
                      request=request, path=item['path'], sha256=sha(raw), raw_utf8=raw.decode())
            if response.get('status') == 'error':
                failed.append(candidate['attempt'])
        require(len(failed) == 3, 'exact-three-failed-owners-per-round')
        prefix = self.a.retain_failed_prefix(root, label, failed)
        require(prefix.get('all_raw_events_retained') is True and prefix.get('inventory_sha256')
                and prefix.get('raw_candidate_evidence_retained') is True,
                'failed-prefix-evidence-must-precede-collection')
        self.note('failed-prefix-retained', root=str(root), label=label, evidence=prefix)
        self.verify(root, label+'-before-legitimate-collection')
        before = self.a.inventory(root)
        for attempt in failed:
            self.call(root, 'lifecycle', operation='abandon', attempt=attempt)
        collected = self.call(root, 'lifecycle', operation='collect')
        after = self.a.inventory(root)
        proof = self.a.collection_proof(root, failed, before, after)
        self.note('engine-collection-actual-census', label=label, response=collected, proof=proof)
        require(proof.get('actual_removal_proven') is True and proof.get('all_failed_generations_removed') is True
                and proof.get('planned_credit') == 0 and proof.get('retained_evidence_sha256'),
                'no-actual-failed-generation-collection-proof')
        self.verify(root, label+'-after-legitimate-collection')

    def small(self, root, mode, forecast, codec='zstd'):
        with self.case('S-'+mode+'-'+codec, root, forecast):
            self.initialize(root, mode, 64)
            for n in range(63):
                self.publish(root, f'S-{mode}-{codec}-initial-{n}')
            require(len(self.ledgers[root].accepted) == 64, 'initial-H64-includes-genesis')
            self.pack(root, codec, bootstrap=True)
            self.drain_two_passes(root)
            self.verify(root, 'N64-H64-bootstrap')
            for cycle, publishers in enumerate((1, 4, 1)):
                self.concurrent_cycle(root, f'S-{mode}-{codec}-c{cycle+1}', publishers, codec=codec,
                                      collect_conflicts=forecast.get('conflict_policy') ==
                                      'engine-abandon-collect-each-round')
            require(len(self.ledgers[root].accepted) == 112, 'three-new-16-publication-cycles')
            self.coupled_capture(root, 'S-'+mode+'-'+codec, codec)
            self.check_outcomes(root)
            self.verify(root, 'small-final')

    def mapping_stress(self, root, forecast, *, count=1000, native_focused=False):
        require((native_focused and 1 <= count <= 64) or (not native_focused and count >= 1000),
                'stress-sample-scope')
        with self.case('X-native-pressure' if native_focused else 'X-Windows1000', root, forecast):
            self.initialize(root, 'A', 10)
            self.pack(root, bootstrap=True)
            self.drain_two_passes(root)
            holds, work_holds, ids, catalogs = [], [], set(), set()
            for number in range(count):
                before = self.state(root)
                selected_before = self.selected(root)
                published = self.publish(root, f'X-new-tail-{number}')['result']
                require(published['selected'] != selected_before, 'authentic-new-semantic-tail-required')
                semantic = self.read(root, 'SELECTED.json', 65536)
                packed = self.pack(root)
                after = self.state(root)
                transition(before, after)
                require(after['store']['physical']['id'] not in ids, 'reused-generation-id')
                require(mapping_identity(after) not in catalogs, 'reused-mapping-catalog')
                ids.add(after['store']['physical']['id'])
                catalogs.add(mapping_identity(after))
                require(self.read(root, 'SELECTED.json', 65536) == semantic, 'physical-work-changed-semantic')
                metric = packed['metrics']
                require(len(metric['physical_activation_holds_ns']) == 1, 'one-mapping-activation-sample')
                holds.extend(metric['physical_activation_holds_ns'])
                work_holds.extend(metric['physical_work_holds_ns'])
                self.drain_two_passes(root)
                key = 'publications/'+published['selected']['publication']+'.json'
                mapped = self.a.mapping(root, key)
                require(mapped.get('mapped') is True and mapped.get('independent') is True,
                        'stress-tail-coverage')
                require(self.call(root, 'resolve', request_id=f'X-new-tail-{number}')['result'] ==
                        published['result'], 'stress-exact-new-outcome')
                self.note('mapping-stress-sample', index=number, before=before['store']['physical'],
                          after=after['store']['physical'], catalog_identity=mapping_identity(after),
                          activation_holds_ns=metric['physical_activation_holds_ns'],
                          work_holds_ns=metric['physical_work_holds_ns'], mapping=mapped)
                if (number+1) % 50 == 0:
                    self.verify(root, f'X-completed-{number+1}')
            self.check_outcomes(root)
            self.verify(root, 'X-final-all-authentic-inputs')
            self.note('stress-summary-unqualified', samples=count, native_focused=native_focused,
                      activation=quantiles(holds), work=quantiles(work_holds) if work_holds else None,
                      activation_gate_met=(len(holds) >= 1000 and quantiles(holds)['p95'] <= 10_000_000
                                           and quantiles(holds)['exploratory_p99'] <= 25_000_000
                                           and max(holds) <= 100_000_000),
                      qualification='native <=64 samples cannot pass Windows >=1000 requirement')

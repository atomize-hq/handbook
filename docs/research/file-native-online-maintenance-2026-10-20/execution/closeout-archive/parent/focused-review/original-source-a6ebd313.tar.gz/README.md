# Shared final focused protocol source

Source-only handoff. No engine/build/native workload or real fixture was run by
this worker. All engine cases remain PENDING on the eventual reviewed final pin.
The source budget is 131,072 bytes /8 regular files, nested inside Matrix F01's
existing 1MiB source allocation. Parent owns staging/commit/integration. The
proposed structured format standard remains proposed; JSON here is a new private
machine receipt, Markdown a derived explanation. No engine format is changed.

The controlling five consultation documents, independent prior review, structured
standard, frozen gates/watchdogs, execution checklist and admission claims were
read. Main and prior integration were read only. Retained CP1/CP2 scripts were
inspected as source, never executed/copied as qualification. GitNexus has no
available tools and this checkout is unregistered: dependency impact is UNKNOWN,
treated as manual HIGH. Only new symbols in this directory were created/edited;
no existing caller/engine symbol was changed. No indexing/bootstrap or Git action.

`focused_protocol.py` contains the injected Driver-facing core. It imports only
Python standard-library data/thread/context helpers; native processes, Windows
imports, subprocesses, job guards and resource-policy implementation stay in the
adapter. `focused_schedules.py` implements source-mapped CP1/CP2 extensions.
`case_ledger.py` retains every mandatory case ID and explicit missing evidence.
`fake_controls.py` performs pure in-memory controls and default geometry math.
`forecast.json` is prospective, never permission to execute. `source_receipt.json`
binds this source/control handoff, excluding itself from the hash manifest.

## Exact execution boundary for the adapter owner

Construct `Harness(driver, adapter, oracle, emit, final_pin=EXACT40HEX)`.
The Driver has the existing `call(root, action, timeout=..., code=..., env=...,
**engine_fields)` interface and `binary_sha256`. Existing Windows/Linux drivers
retain raw events before their expected-exit assertion. A concurrent publish's
explicit exit2 semantic conflict is recovered only from that invocation's
`AssertionError(row)` with exact input, exit2 and an empty violations list.
Shared `driver.last` is never used. Unknown refusals, RSS/time censors and raw
process-control failures remain failures. Adapters with a different assertion
contract must supply an explicitly reviewed compatible Driver bridge.

Adapter methods are a private harness boundary, not invented engine commands:

| Method | Required behavior |
| --- | --- |
| `wall_time()`, `monotonic()`, `sleep(seconds)` | Real clocks in native execution; fixed functional cutoff 2026-10-21T11:10:14Z, no restart. Clip waits to stage/functional limits. |
| `preflight(case_id,root,forecast,final_pin)` | Before any control/store write, enforce the current global allocation and exact root/phase byte/file/directory forecast including failed attempts and coexistence. Return `go`, exact case/root/final_pin, reader_limit=268435456, checker_limit=2147483648, default_payloads=true, heavy_token, host_guard, binary_sha256, binary_source_pin, source_manifest_sha256, adapter_sha256, guard_sha256. GO comes from meta, never this forecast file. |
| `before_call(root,action,role,timeout)` | Enforce exact executable/source binding, independent action role and prospective remaining cell growth before child launch. Readers are resolve/point/inspect/lookup-bench, regardless of executable basename. Every child belongs to ONE host guard/exclusive heavy token with positive native identity/RSS, deadline and final closure. |
| `read(root,relative,limit)`, `exists(root,relative)`, `file_sha256(root,relative)` | Confined, non-symlink bounded reads/observations, no mutating recovery on protected roots. Exact UTF-8 JSON bytes are hashed before decoding. |
| `inventory(root)` | Complete `{files:{relative:{bytes,sha256}},directories:[...]}` including durable physical pins, all stages/journals/failed outputs. Native allocation separately where available. No planned deletion credit. |
| `control(root,name)` | Create separately forecast owned unique control paths; return `ready`, `release`, `cancel`. These are outside engine state. Never overwrite an old control prefix. |
| `spawn(callback)`, `alive(handle)`, `wait(handle,timeout)` | Invoke the injected guarded Driver concurrently. Optional `ThreadCalls` mixin provides non-daemon Python threads only. Handle is a dict with `response`; native ownership remains the Driver/outer guard's responsibility. All joins/errors retained. |
| `await_ready(control,handle,timeout)`, `release(control)` | Require authentic native ready checkpoint and live exact process. Release by writing the owned control path. Join before asserting post-reader deletion. |
| `signal(control,'cancel')`, `end_signal(control,'cancel')` | Create cancellation signal, then retain its bytes/evidence while ending the signal. No accepted-control edits. |
| `begin_phase(root,label)`, `overlap(root,label,publishers,readers)` | Bind intervals to the phase. Return actual positive native start/end overlap with independent_reader_processes=4, publisher_processes>=configured count, maintenance_overlap=true. Threads or starts before stdin alone do not prove active work. |
| `mapping(root,key)` | Independent final-version decoder: mapped, raw_sha256, independent=true, receipt_sha256; no engine audit or guessed index offset. |
| `backlog(root)` | Independent reachable/protected/excluded census with integer `unprotected`, `protected`, `excluded`; count everything including abandoned owners and metadata. Selected journal status alone is insufficient. |
| `quiesce(root)` | Freeze mutation for the oracle and prove no active I/O. Paused native readers remain valid and are not revoked. No hidden engine audit/refresh. |
| `close_case(case_id,root)` | Always close/record all owned processes and handles, including a failed thread join. Return positive processes_closed/handles_closed with native guard receipt. |
| `removal_proof(root,before,phase)` | Actual path absence and deletion identity after a crash; actually_removed=true, removed_paths nonempty, no_planned_deletion_credit=true. |
| `interrupt(handle,kind)`, `finish_interrupted(handle,kind)` | Native adapter only: exact PID/start/handle, cancellation/death and joined I/O/pin release. No core process-kill implementation. Missing hook raises Unsupported/PENDING. |
| `extend(harness,root,spec)` | Reviewed source-bound native/paged extension; spec binds case_id/capability/source_sha256/schema_pin/required_checks. Only actual existing engine actions may be called. Raw mutation offsets, final schema, restore/reset proof and exact refusal are adapter-owned evidence. |

`capabilities` is an explicit set: e.g. `barrier:pack-catalog-captured`,
`barrier:candidate-ready`, `barrier:pack-before-catalog`, `exit:<actual-phase>`,
`reader-error`, `reader-cancel`, `reader-death`. Advertising a capability is not
evidence of a passed case. Source/checkpoint correspondence must be supplied.

The `emit(row)` sink reserves before append, persists JSON append-only with all
raw inputs/responses, failures and incomplete prefixes, and binds source/binary/
guard/adapter evidence. Driver raw stdout/stderr/RSS samples remain separately
retained. It must reject budget growth before writing, never truncate a failed
prefix to finance later work. Root paths should include the supported
`disposable` component for lifecycle setup, within the admitted native namespace.

The independent `oracle(**kwargs)` receives root, checkpoint, final_pin,
known_requests and required_mapped_keys. It returns status=passed, exact final_pin,
engine_code_imported=false, engine_audit_used=false, actual_H, mapped_keys,
receipt_sha256, source_unchanged=true and all checks in `ORACLE_CHECKS`.
These mean complete chosen physical representation, all accepted outcomes/intents,
membership, graph, exact source/navigation/provenance, retirement refusal, B loose
controls/ordinary selected-once extraction and a before/after read-only inventory.
An engine `audit` result cannot satisfy this interface. A fake callback cannot
qualify an engine case. `Inputs` retains attempted `(request_id,intent)` variants;
only the uniquely accepted input is projected into the outcome-oracle map.

## Executable schedules and deterministic offered load

`h.small(root,'A' or 'B',forecast)` uses N64 and real H64 including genesis,
then three cycles with configurations **1,4,1 publishers**, four independent native
readers each cycle, and at least16 NEW accepted publications/cycle. All history
requests here are explicitly no-op durable publications, not physical activations.
One-publisher cycles use16 attempts, within the32-attempt ceiling. The four-
publisher cycle uses16 rounds x4 attempts =64 TOTAL attempts, no implicit retries.
All4 processes pause at existing candidate-ready on the same semantic base while
maintenance runs; one accepts and three conflict. At most48 failed full B
generations stay charged. A missing ready, timeout or exhausted bound fails/censors
the cell; no serialized frontend substitute or hidden rerun is permitted.

`coupled_capture` then pauses a reader at physical capture BEFORE the later tail
exists, accepts the new tail, independently proves it mapped, activates2 physical
successors, keeps the loose fallback until old-reader resume after>15s, and only
then checks actual reclamation. In B the permanent loose publication control stays.
Still-selected shared stable-base containers survive release; only obsolete
containers may be reaped. The actual old-pack-removal crash remains a separate
mandatory case. These2 extra accepted publications give final H114. No second
deep B clone/restore is created; P0, crash, compatibility and backup obligations
reuse corresponding shallow donor roots when identical.

`h.mapping_stress(root,forecast,count=1000)` is Windows final-pin pressure: one
actual accepted N10-A tail per iteration, new catalog/descriptor identity plus
distinct exact generation id/ordinal, full exact-input/outcome coverage and
independent oracles at50-iteration boundaries/final. Physical work metadata CAS
samples are separate. ID-only or unchanged mapping switches refuse. Native
`native_focused=True,count<=64` is modest pressure and cannot pass Windows1000.
All holds/samples and missed timing targets remain visible.

`partial_interval`, `reservation_late`, `cutoff_and_stale_cas`,
`terminal_retirement`, `automatic_policy`, `stable_base`, `persistent_owners`,
`crash_extension`, `contenders` and `reader_end` are individually callable with
per-case forecast. F1 creates a distinct shallow A discovery lineage before
bootstrap; it never rewinds a completed cursor. Immutable oversize is terminal,
not mutated into later eligibility. F2 never manually aborts/forces to turn an
automatic decline into a pass. Cleanup target uses exactly TWO calls after
blockers/producers end; the general bounded cleanup helper is not relabeled as
a single pass. Complete independent oracles run at all implemented critical
crashes and cycle/restore boundaries. Missing counters refuse qualification.

An OPTIONAL policy `forecast.conflict_policy='engine-abandon-collect-each-round'`
has source support, disabled by default. It needs `failed-round-collection` plus
prepared_candidates/retain_failed_prefix/collection_proof adapter hooks. Exact
candidate bytes/intent/attempt paths from all4 paused publishers are captured;
raw failed-prefix events/candidates/inventory are retained BEFORE a full oracle.
Only the3 failed owners may be legally lifecycle-abandoned and engine-collected.
Another full oracle and actual complete before/after removal census precede the
next phase. No accepted B snapshot is retired to finance work. Planned collection
never funds peak admission. The retained-all forecast remains controlling until
the parent freezes/reviews this alternative and its actual peak/evidence topology.

## Required pending adapter work

`CaseLedger(host,pin)` starts every row PENDING: exact52 packing,24 recovery,24
strict and8 native focused IDs, workspace/immediate/ordinary routes and all new
focused rows. Windows also includes54 packing applicability and native sharing.
Legacy barriers get explicit final-version mappings, not old busy assertions
silently reused. Failed/censored observations remain append-only even after a
later pass. `PASSED` requires actual final-pin native raw/source/binary/guard/full-
oracle references and complete required checks. The parent independently reads
those artifacts and assesses performance gates/all-host completion.

The inspected CP2 source has STORE3/Work2/catalog3 and whole indexes. No paged
producer/schema/page offsets/route counters were present. CP3 cases therefore
remain adapter-required: all6 outcomes, authenticated negative across every
segment, touched route/leaf/raw corruption with good loose duplicate, untouched
corruption/full audit, equal/conflicting duplicates and full preselection
verification. Compatibility retains STORE1/2 and STORE3, catalog2/3->the actual
final version, initial old-operation quiescence and safe refusal; version4 is not
assumed implemented. Boundary cases raw8MiB,pack64MiB,index16MiB,65536records,
64packs,4segments,Work128KiB,deferred32KiB/128,cache64MiB and64MiB collateral
remain mandatory source-bound constructors. Native death, cancel, sharing,
same-content/fresh-birth/path-reuse/stale-journal and backup hooks likewise await
exact final implementation. Durable physical-pins/*.lock bytes ALL travel in
backup. Only finite named ephemeral global gates may be excluded.

Full scaled histories, document controls, long representation verification and
streaming restore remain Matrix-owned and separately required. No source-only
control or partial focused completion declares the experiment passed.

## Resource and control outcome

`forecast.json` explicitly reports NO_GO for real execution until final source,
native/Windows admission and all adapter proofs arrive. Current native cap is
96MiB total; proposed448MiB and Windows480MiB remain HOLD. The1,4,1 retained-all
B payload floor is126,853,120 bytes, including48 failed generations and the original.
Pure source geometry gives806,161 bytes/generation incl navigation/manifest;
conditional B generation+external metadata upper is147,154,114 bytes before init
objects/physical metadata/evidence. This replaces the earlier1,4,4 draft's164MB
payload floor; it is not a smaller payload profile or a dropped required case.
The whole native allocation can be repartitioned only by the parent with a full
prospective topology. The file contains per-root/per-case upper envelopes and
explicit unproven allowances rather than granting growth.

Run only `python -B fake_controls.py` for pure controls; syntax can be compiled
from strings with `ast.parse`/`compile` in memory. No pycache, fixture, output file
or native process is created by those checks. Tracemalloc measures Python
allocations, not native RSS qualification. Refer to the bound source receipt for
actual counts/hashes; these are harness controls only. Main/Landing/budget copies
remain untouched. Functional cutoff11:10:14Z and closeout13:10:14Z on2026-10-21
remain fixed, with final-source review/freeze target04:10:14Z.

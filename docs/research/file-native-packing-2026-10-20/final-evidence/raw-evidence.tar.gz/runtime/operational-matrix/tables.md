# Representative N8000 matched cells

| Mode | Cell | Seven-publication median ms | / qualified L | Ordinary gate |
|---|---|---:|---:|---|
| A | L-old | 370.800 | 1.000x | True |
| A | L-new | 367.010 | 0.990x | True |
| A | P0 | 364.792 | 0.984x | True |
| A | PZ | 386.171 | 1.041x | True |
| B | L-old | pending | - | null |
| B | L-new | pending | - | null |
| B | P0 | pending | - | null |
| B | PZ | pending | - | null |

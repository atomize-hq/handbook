# Final-reader original-cohort measurements

| Category | Qualified L µs | New loose µs | P0 µs | P0 / L | PZ µs | PZ / P0 |
|---|---:|---:|---:|---:|---:|---:|
| early | 987.50 | 961.40 | 963.35 | 0.976× | 1048.50 | 1.088× |
| middle | 984.90 | 975.20 | 929.95 | 0.944× | 1010.60 | 1.087× |
| recent | 966.05 | 990.65 | 930.70 | 0.963× | 958.15 | 1.029× |
| missing | 611.25 | 607.45 | 608.20 | 0.995× | 590.35 | 0.971× |
| cancelled | 641.65 | 646.15 | 666.55 | 1.039× | 647.25 | 0.971× |
| lost-reply | 948.20 | 957.80 | 993.60 | 1.048× | 966.95 | 0.973× |

P0 pack/index: 641,986,037 bytes; PZ: 283,460,393 bytes (44.1537% of P0).

P0 containers were created by 4cb6b9f; P0 and PZ final readers are d70f3864.
Warm is same-process after first lookup, 500 samples per category. Fresh is 20 process starts per category, with uncontrolled OS/device caches.
Original cohort keys are identical; no new loose tail substitutes for an original key.
Allocation is regular-file data only, excluding MFT/directory metadata. Logical instrumentation does not measure physical device writes.
Loose and old P0 duplicates still coexist at this measurement checkpoint.

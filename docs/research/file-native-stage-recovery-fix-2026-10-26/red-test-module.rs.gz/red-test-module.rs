use super::*;

impl Fixture {
    fn construction(&self)->(StoreConfig,Vec<u8>){
        let mut next=self.w.clone();next.jobs.clear();next.reconciled_absent+=1;
        next.transition_parent=Some(self.c.physical.as_ref().unwrap().plan.clone());
        next.garbage.push(plan_name(next.transition_parent.as_ref().unwrap()).unwrap());next.garbage.sort();next.garbage.dedup();
        let bytes=io::json(&next).unwrap();let mut target=self.c.clone();target.physical.as_mut().unwrap().plan=io::digest(&bytes);
        io::write_new(&self.root.join(selector_stage(&self.w.generation.id).unwrap()),&io::json(&target).unwrap(),&mut Metrics::default()).unwrap();
        io::write_new(&self.root.join(work_stage(&self.w.generation.id).unwrap()),&bytes,&mut Metrics::default()).unwrap();
        assert!(!self.root.join(plan_name(&target.physical.as_ref().unwrap().plan).unwrap()).exists());
        (target,bytes)
    }
}

#[test]
fn complete_uninstalled_stage_resumes_same_progress_without_payload_rewrite(){
    let _clock=Clock::new();let f=Fixture::new();let(target,bytes)=f.construction();
    let mut m=cleanup_metrics();let selected=load(&f.root,&f.c,&mut m).unwrap();
    assert!(selected.jobs.is_empty(),"complete owned construction progress must survive recovery");
    assert_eq!(selected.reconciled_absent,1);
    assert_eq!(config(&f.root,&mut Metrics::default()).unwrap().physical,target.physical);
    assert_eq!(fs::read(f.root.join(plan_name(&target.physical.as_ref().unwrap().plan).unwrap())).unwrap(),bytes);
    assert_eq!(m.bytes_written,0,"recovery must finish persistence, not reconstruct payloads");
    assert_eq!(m.file_syncs,1,"construction must be re-synced before immutable installation");
}

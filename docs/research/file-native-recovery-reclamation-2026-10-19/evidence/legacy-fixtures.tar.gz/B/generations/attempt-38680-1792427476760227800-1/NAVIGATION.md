# Collection navigation

Exact authored sources are in docs/. Read navigation/ in stable ID order for titles, kinds, source paths and typed local/external relationships. Use ordinary listing, text search, copying and SHA-256 tools.

[Overview](navigation/d000000.md) | [Packet](packet/context.md) | [Ordered provenance](packet/provenance.json)

Readable files do not grant edit/import authority. A may mix or lag; B requires one positively selected retained generation path.

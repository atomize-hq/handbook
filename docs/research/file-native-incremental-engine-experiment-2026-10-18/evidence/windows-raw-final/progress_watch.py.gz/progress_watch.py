import datetime,json,time
from pathlib import Path
base=Path('C:/file-native-incremental-20261018');end=time.monotonic()+21600
while time.monotonic()<end and not (base/'progress-watch.stop').exists():
    row={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    try:
        with (base/'history-common-pin/store/expected-ledger.jsonl').open('rb') as f:
            f.seek(0,2);f.seek(max(0,f.tell()-65536));lines=f.read().splitlines()
        for line in reversed(lines):
            try:row['receipted_history']=json.loads(line)['index'];break
            except (ValueError,KeyError):pass
        for name in ['serial-continuation-v2','final-verification-v3']:
            p=base/name/'steps.json'
            if p.exists():
                v=json.loads(p.read_bytes());v=v['rows'] if isinstance(v,dict) else v
                row[name]=v[-1]['name'] if v else None
    except Exception as ex:row['read_error']=str(ex)
    row['final_verification_complete']=(base/'final-verification-v3/completed.json').exists()
    text=json.dumps(row);print(text,flush=True)
    with (base/'progress.jsonl').open('a') as f:f.write(text+'\n')
    if row['final_verification_complete']:break
    time.sleep(60)

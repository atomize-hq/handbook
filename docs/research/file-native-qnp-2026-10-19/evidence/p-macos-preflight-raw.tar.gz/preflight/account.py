import os,json,time,datetime,subprocess,hashlib,stat
from pathlib import Path
O=Path('/private/tmp/file-native-p-macos-20261020/preflight');W=Path('/Users/spensermcconnell/__Active_Code/atomize-hq/handbook')
def save(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
def census(root):
 size=allocated=files=0
 for dp,ds,fs in os.walk(root,followlinks=False):
  for n in fs:
   s=(Path(dp)/n).lstat();size+=s.st_size;allocated+=s.st_blocks*512;files+=1
 return {'logical_bytes':size,'allocated_bytes':allocated,'files':files}
raw=[]
for a in [['git','status','--porcelain=v1','-b'],['git','rev-parse','HEAD'],['git','diff','--raw'],['git','diff','--cached','--raw']]:
 p=subprocess.run(a,cwd=W,env=dict(os.environ,GIT_OPTIONAL_LOCKS='0'),capture_output=True,text=True,timeout=110);raw.append({'argv':a,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
save('final-checkout.json',raw)
assert [r['stdout'] for r in raw]==[r['stdout'] for r in json.loads((O/'shared-before.json').read_text())]
baseline={r['root']:r for r in json.loads((O/'root-census.json').read_text())};git=census(W/'.git');bg=baseline[str(W/'.git')];growth=max(0,git['logical_bytes']-bg['logical_bytes']);fgrowth=max(0,git['files']-bg['files'])
save('final-shared-git.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actual':git,'logical_delta_bytes':git['logical_bytes']-bg['logical_bytes'],'delta_files':git['files']-bg['files'],'positive_growth_charged_to_native_report':growth,'positive_file_growth_charged_to_native_report':fgrowth,'limitation':'Known interval begins at 03:44 initial Git census after version probes. No Git writes performed before census; no whole-host transient disk peak claimed.'})
s=json.loads((O/'summary.json').read_text());s['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();s['shared_final_check_match']=True;s['free_available_bytes']=os.statvfs(O).f_bavail*os.statvfs(O).f_frsize;s['native_preflight_seconds_from_dispatch']=time.time()-datetime.datetime.fromisoformat('2026-10-20T03:42:17+00:00').timestamp();s['remaining_native_process_groups']=[];s['exact_package_search_in_preserved_roots']='complete; no matches';s['shared_git_interval_positive_growth_charged_to_P_bytes']=growth;s['shared_git_interval_positive_growth_charged_to_P_files']=fgrowth
save('summary.json',s)
r=O/'REPORT.md';r.write_text(r.read_text()+f'\nFinal supplemental inventory: actual rustc/cargo 1.89.0 and 1.97.0 binaries and native clang are individually hashed in native-compiler-bindings.json (launcher hashes are separately retained). Requested package-name search across preserved roots found no matches, with no errors. Final checkout comparison remains identical. All preflight helpers have returned, no lane-owned group remains; no timeout occurred. Final completion {s["finished_utc"]} ({s["native_preflight_seconds_from_dispatch"]:.3f}s from dispatch).\n\nThe 32 MiB / 2,000-file allocation is a unified lane allowance including parent/local/native reports and shared Git growth; this report grants no separate per-host allowance. final-accounting.json states this host\'s exact report-root and observed Git counts; parent must add any parent/other-host artifacts and unknown OS cache changes. OS-managed incidental cache growth was not independently baselined and remains unknown, rather than counted as zero.\n')
manifest={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(O.iterdir()) if p.is_file() and p.name not in ['manifest.json','final-accounting.json']}
save('manifest.json',{'scope':'All report files except self and final-accounting.json; both exclusions explicit','files':manifest})
account={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'report_root':str(O),'report_root_total_including_this_file':{},'observed_shared_git_positive_bytes':growth,'observed_shared_git_positive_files':fgrowth,'known_host_new_total_bytes':0,'known_host_new_total_files':0,'native_host_free_available_bytes':s['free_available_bytes'],'unified_lane_cap_bytes':33554432,'unified_lane_cap_files':2000,'parent_or_other_host_new_bytes':None,'parent_or_other_host_new_files':None,'os_managed_incidental_cache_delta_bytes':None,'ownership_note':'Only own new root and measured positive shared-Git interval growth are actual known native additions. Parent must aggregate entire lane. Shared checkout is unchanged. Cargo interval delta0; no cache install/fetch. APFS allocated bytes are st_blocks estimates, not exclusive physical storage.','all_preflight_children_finished':True,'remaining_lane_owned_process_groups':[],'ordinary_max_child_seconds':max(r['seconds'] for r in json.loads((O/'tools.json').read_text())),'whole_preflight_seconds_from_dispatch':s['native_preflight_seconds_from_dispatch']}
save('final-accounting.json',account)
for _ in range(8):
 c=census(O);account['report_root_total_including_this_file']=c;account['known_host_new_total_bytes']=c['logical_bytes']+growth;account['known_host_new_total_files']=c['files']+fgrowth;save('final-accounting.json',account)
actual=census(O);assert actual==account['report_root_total_including_this_file'];assert account['known_host_new_total_bytes']<33554432 and account['known_host_new_total_files']<2000
for n,v in manifest.items():assert hashlib.sha256((O/n).read_bytes()).hexdigest()==v['sha256']
print(json.dumps(account,indent=2))

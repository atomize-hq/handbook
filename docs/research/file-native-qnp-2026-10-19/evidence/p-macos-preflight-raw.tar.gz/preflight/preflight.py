import os,sys,json,time,datetime,subprocess,shutil,hashlib,stat,glob,signal
from pathlib import Path
O=Path('/private/tmp/file-native-p-macos-20261020/preflight')
W=Path('/Users/spensermcconnell/__Active_Code/atomize-hq/handbook')
H=Path('/Users/spensermcconnell')
DEADLINE=1792468337 # 2026-10-20 03:52:17 UTC
started=time.time()
env=dict(os.environ,RUSTUP_AUTO_INSTALL='0',RUSTUP_TOOLCHAIN='1.89.0-aarch64-apple-darwin',CARGO_NET_OFFLINE='true',PYTHONDONTWRITEBYTECODE='1',GIT_OPTIONAL_LOCKS='0')
def save(n,x): (O/n).write_text(json.dumps(x,indent=2)+'\n')
def run(args):
 remain=min(110,DEADLINE-time.time()-10)
 row={'argv':args,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stdout':None,'stderr':None,'exit':None,'timeout':False,'remaining_group':None}
 if remain<=0:row['error']='preflight deadline';return row
 t=time.monotonic();p=subprocess.Popen(args,cwd=W,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True)
 try: row['stdout'],row['stderr']=p.communicate(timeout=remain)
 except subprocess.TimeoutExpired:
  row['timeout']=True;os.killpg(p.pid,signal.SIGKILL);row['stdout'],row['stderr']=p.communicate(timeout=3)
 row['exit']=p.returncode;row['seconds']=time.monotonic()-t
 try:os.killpg(p.pid,0);row['remaining_group']=True
 except ProcessLookupError:row['remaining_group']=False
 return row

def census(root):
 root=Path(root);t=time.monotonic();row={'root':str(root),'logical_bytes':0,'allocated_bytes':0,'files':0,'directories':0,'symlinks':0,'errors':[],'complete':True}
 if not root.exists() and not root.is_symlink():row.update(logical_bytes=None,allocated_bytes=None,files=None,complete=False,errors=['missing']);return row
 stack=[root]
 while stack:
  if time.monotonic()-t>105 or time.time()>DEADLINE-15: row['complete']=False;row['errors'].append('census deadline; partial counts');break
  p=stack.pop()
  try:
   s=p.lstat()
   if stat.S_ISDIR(s.st_mode):
    row['directories']+=1
    with os.scandir(p) as entries:stack.extend(Path(e.path) for e in entries)
   else:
    row['files']+=1;row['logical_bytes']+=s.st_size;row['allocated_bytes']+=s.st_blocks*512
    if stat.S_ISLNK(s.st_mode):row['symlinks']+=1
  except OSError as e:row['complete']=False;row['errors'].append(str(e))
 row['seconds']=time.monotonic()-t;return row

before=[run(['git','status','--porcelain=v1','-b']),run(['git','rev-parse','HEAD']),run(['git','write-tree'])] if False else [run(['git','status','--porcelain=v1','-b']),run(['git','rev-parse','HEAD']),run(['git','diff','--raw']),run(['git','diff','--cached','--raw'])]
save('shared-before.json',before)
tools=[]
commands=[['/usr/bin/sw_vers'],['/usr/bin/uname','-a'],['/usr/sbin/sysctl','hw.memsize','hw.model','machdep.cpu.brand_string'],['/bin/df','-k',str(O),str(W)],['/usr/sbin/diskutil','info','-plist',str(O)],['/usr/bin/xcode-select','-p'],['/usr/bin/xcrun','--no-cache','--find','clang'],['rustup','toolchain','list'],['rustc','--version','--verbose'],['cargo','--version','--verbose'],[sys.executable,'--version'],['/usr/bin/clang','--version'],['/usr/bin/make','--version'],['/usr/bin/ar','--version'],['/opt/homebrew/bin/pkg-config','--modversion','libzstd'],['/opt/homebrew/bin/pkg-config','--variable=libdir','libzstd'],['/opt/homebrew/bin/zstd','--version']]
# No xcode-select install, cargo operation, rustup update, compiler invocation, or engine.
for cmd in commands:
 try:tools.append(run(cmd))
 except Exception as e:tools.append({'argv':cmd,'error':str(e),'exit':None})
save('tools.json',tools)
paths={n:shutil.which(n) for n in ['rustup','rustc','cargo','python3','clang','cc','make','ar','pkg-config','zstd','ps']}
bindings=[]
for n,p in paths.items():
 if p:
  q=Path(p).resolve();bindings.append({'tool':n,'path':p,'resolved':str(q),'bytes':q.stat().st_size,'sha256':hashlib.sha256(q.read_bytes()).hexdigest()})
save('tool-bindings.json',bindings)
libpaths=sorted(set(glob.glob('/opt/homebrew/opt/zstd/lib/libzstd*.dylib')+glob.glob('/opt/homebrew/lib/libzstd*.dylib')+glob.glob('/usr/local/lib/libzstd*.dylib')))
# Public C API probe in an isolated ordinary child; retained error if library missing.
probe='import ctypes,json,sys; z=ctypes.CDLL(sys.argv[1]); z.ZSTD_versionNumber.restype=ctypes.c_uint; z.ZSTD_versionString.restype=ctypes.c_char_p; print(json.dumps({"version_number":z.ZSTD_versionNumber(),"version":z.ZSTD_versionString().decode(),"symbols":{n:bool(getattr(z,n,None)) for n in ["ZSTD_compress","ZSTD_decompress","ZSTD_isError","ZSTD_getErrorName","ZSTD_getFrameContentSize","ZSTD_compressBound"]}}))'
libs=[]
for p in sorted(set(str(Path(x).resolve()) for x in libpaths)):
 q=Path(p);libs.append({'path':p,'sha256':hashlib.sha256(q.read_bytes()).hexdigest(),'bytes':q.stat().st_size,'public_c_api':run([sys.executable,'-B','-c',probe,p])})
save('libzstd.json',{'candidates':libpaths,'libraries':libs,'missing':not bool(libs),'system_dyld_shared_cache_not_probed':True})
packages={'zstd':'0.14.3','zstd-safe':'8.2.0','zstd-sys':'2.1.2+zstd.1.5.7','cc':'1.9.0','find-msvc-tools':'0.1.15','jobserver':'0.1.35','getrandom':'0.4.3','libc':'0.2.191','shlex':'2.0.1','pkg-config':'0.3.34'}
# Only enumerate the exact requested packages. Never read Cargo credentials.
cache=[]
for name,ver in packages.items():
 key=name+'-'+ver
 src=sorted((H/'.cargo/registry/src').glob('*/'+key))
 archives=sorted((H/'.cargo/registry/cache').glob('*/'+key+'.crate'))
 cache.append({'name':name,'version':ver,'source':[census(p) for p in src],'archives':[dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in archives],'missing_source':not bool(src),'missing_archive':not bool(archives)})
save('exact-package-cache.json',cache)
Q=H/'.codex/worktrees/file-native-q-macos-20261019'
N=H/'.codex/worktrees/file-native-n-macos-20261019'
roots=[str(Q),str(N),'/private/tmp/file-native-q-macos-20261019','/private/tmp/file-native-q-macos-20261019-admission.json','/private/tmp/file-native-prerequisite-macos-20261018-source','/private/tmp/file-native-incremental-macos-20261018','/private/tmp/file-native-prerequisite-macos-20261018',str(W/'docs/research/file-native-engine-followup-2026-10-17'),str(W/'docs/research/file-native-publication-experiment-2026-10-17'),str(W/'.git'),str(H/'.cargo'),str(H/'.rustup'),str(H/'.npm/_npx'),'/private/tmp/sw17-native-macos-env-20261018.ziJ037','/private/tmp/sw17-native-macos-env-20261018.ziJ037.tar.gz']
rows=[]
for p in roots:
 rows.append(census(p));save('root-census.json',rows)
# Nested subroot numbers are annotations only; excluded from unique total.
nested=[census(N/'handbook'),census(Q/'handbook'),census(N/'handbook/docs/research/file-native-navigation-2026-10-19/native-macos/runtime/followup-20261020'),census(H/'.cargo/registry'),census(H/'.cargo/registry/cache'),census(H/'.cargo/registry/src'),census(H/'.cargo/registry/index')]
save('nested-annotations-not-additive.json',nested)
after=[run(['git','status','--porcelain=v1','-b']),run(['git','rev-parse','HEAD']),run(['git','diff','--raw']),run(['git','diff','--cached','--raw'])];save('shared-after.json',after)
save('process-snapshot.json',run(['/bin/ps','-axo','pid,ppid,pgid,rss,comm']))
fs=os.statvfs(O)
save('summary.json',{'started_utc':datetime.datetime.fromtimestamp(started,datetime.timezone.utc).isoformat(),'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'preflight_deadline_utc':'2026-10-20T03:52:17Z','dispatch_utc':'2026-10-20T03:42:17Z','seconds':time.time()-started,'shared_bindings_unchanged':[r['stdout'] for r in before]==[r['stdout'] for r in after],'free_available_bytes':fs.f_bavail*fs.f_frsize,'free_blocks_bytes':fs.f_bfree*fs.f_frsize,'known_disjoint_inventory_bytes':sum(r['logical_bytes'] or 0 for r in rows),'known_disjoint_inventory_files':sum(r['files'] or 0 for r in rows),'all_root_census_complete':all(r['complete'] for r in rows),'commands_closed':all(not r.get('remaining_group',False) for r in tools),'qualification_started':False,'builds_started':False,'downloads_started':False,'unknown_scopes':['Full exact new Cargo.lock not supplied locally: remaining package availability and checksums unknown.','Ownership of shared Cargo/Rustup/npm caches and unrelated Git growth is not solely P; baseline census does not assign all bytes to experiment.','Cross-host global totals are parent-owned and not independently re-censused here.','Any additional protected roots absent from saved receipts remain unknown; inventory is bounded to listed roots.']})
print((O/'summary.json').read_text())

# Matched original-cohort lookup observations

| Category | Qualified L median µs | New loose median µs | P0 median µs | P0 / qualified L | PZ median µs | PZ / P0 |
|---|---:|---:|---:|---:|---:|---:|
| early | 987.50 | 961.40 | 955.95 | 0.968× | — | — |
| middle | 984.90 | 975.20 | 957.80 | 0.972× | — | — |
| recent | 966.05 | 990.65 | 952.55 | 0.986× | — | — |
| missing | 611.25 | 607.45 | 598.90 | 0.980× | — | — |
| cancelled | 641.65 | 646.15 | 639.30 | 0.996× | — | — |
| lost-reply | 948.20 | 957.80 | 946.30 | 0.998× | — | — |

| Cell | Logical records | Pack/index/catalog files | Pack + index bytes |
|---|---:|---:|---:|
| P0 | 504,833 | 33 | 641,986,037 |

All cells retain fixed original lookup keys. New loose tails are separate. Warm means the same process after first lookup. Fresh processes have uncontrolled OS/device caches. Representation files do not claim a compacted footprint while loose/old-container duplicates coexist. Instrumented opens/bytes are not physical device writes.

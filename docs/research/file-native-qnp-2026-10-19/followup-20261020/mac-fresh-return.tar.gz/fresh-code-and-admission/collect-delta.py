"""Post-run artifact-only collector for the fresh final-d70 recovery follow-up."""
import os,sys,json,gzip,tarfile,io,hashlib,subprocess,datetime,time,runpy,stat
from pathlib import Path
Q=Path(__file__).resolve().parent;sys.path.insert(0,str(Q));import control as c
R=c.R;F=c.F;D=R/'closeout';CUT=datetime.datetime.fromisoformat(c.CFG['followup_artifact_cutoff'].replace('Z','+00:00')).timestamp();assert time.time()<CUT and not D.exists()
auth=json.loads((Q/'authorization-fresh-F-v1.json').read_bytes());assert {n:c.digest(Q/n) for n in auth['approved_code_sha256']}==auth['approved_code_sha256']
processes=[];sampled=set()
with gzip.open(R/'raw-process-events.jsonl.gz','rt') as f:
 for line in f:processes.append(json.loads(line));sampled.add(processes[-1]['guard']['pgid'])
with gzip.open(R/'rss-samples.jsonl.gz','rt') as f:
 for line in f:sampled.add(json.loads(line)['pgid'])
observations=[]
for attempt in range(2):
 probe=subprocess.Popen(['/bin/ps','-axo','pid=,ppid=,pgid=,state=,uid=,rss=,args='],stdout=subprocess.PIPE,stderr=subprocess.PIPE);out,err=probe.communicate(timeout=3);obs={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'columns':['PID','PPID','PGID','state','UID','RSS_KiB','args'],'exit':probe.returncode,'stderr':err.decode(),'requested_numeric_PGIDs':sorted(sampled),'rows':None,'owned_native_root_command_rows':None}
 if probe.returncode==0:
  obs['rows']=[line for line in out.decode().splitlines() if len(line.strip().split(None,6))>=6 and int(line.strip().split(None,6)[2]) in sampled]
  allowed={os.getpid(),os.getppid(),probe.pid};obs['owned_native_root_command_rows']=[line for line in out.decode().splitlines() if len(line.strip().split(None,6))==7 and str(c.ROOT) in line.strip().split(None,6)[6] and int(line.strip().split(None,6)[0]) not in allowed]
 observations.append(obs)
 if attempt==0:time.sleep(.5)
assert all(x['exit']==0 and x['rows']==[] and x['owned_native_root_command_rows']==[] for x in observations),'numeric-closure-UNKNOWN-or-live'
A=runpy.run_path(str(Q/'execute.py'),run_name='approved_historical_definitions_only');historical=A['historical_preservation'](c);source=c.sourcecheck();anchors=c.N['preservation']()
events=json.loads((F/'recovery/events.json').read_bytes());result=json.loads((R/'recovery-result.json').read_bytes()) if (R/'recovery-result.json').exists() else None;passed=(R/'final.json').exists() and (R/'outer-closeout.json').exists() and result is not None and len(events)==282 and len(result['result']['cases'])==24
D.mkdir()
def put(name,value):
 data=(json.dumps(value,indent=2)+'\n').encode();assert len(data)<=1048576
 with (D/name).open('xb') as f:f.write(data)
summary={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'FRESH_F24_282_PASS_PENDING_PARENT_REVIEW' if passed else 'INCOMPLETE_OR_FAILED_NEW_PREFIX','fresh_actual_cases':len(result['result']['cases']) if result else None,'fresh_actual_engine_events':len(events),'required_cases':24,'required_events':282,'action_exit_sequence':[{'action':r['input']['action'],'exit':r['exit']} for r in events],'all_completed_processes':len(processes),'guard_failures':[{'name':r['name'],'guard':r['guard']} for r in processes if r['guard']['reason'] or r['guard']['violations']],'completed_process_missing_RSS':sum(r['guard']['missing_samples'] for r in processes),'unknown_final_presence':[r['guard']['pgid'] for r in processes if r['guard']['remaining_group'] is None],'numeric_group_closure_observations':observations,'whole_run_aggregate_peak_RSS':None,'aggregate_peak_note':'3GiB live aggregate ceiling checked by approved control; separate aggregate peak not persisted. Exact per-group samples retained.','historical_preservation':historical,'source145_core18_exe_library':source,'private1520_shared1262_tools':anchors,'new_code_hashes':{n:c.digest(Q/n) for n in auth['approved_code_sha256']},'authorization':auth,'original_censored_run_not_relabelled_or_resumed':True,'actual_pre_return':c.enforce()}
put('closeout.json',summary)
files=[]
def add(p,name):
 if p.exists():assert p.is_file() and not p.is_symlink();files.append((p,name))
for p in sorted(R.iterdir()):
 if p.is_file() and p.suffix in ['.json','.gz']:add(p,'fresh-native-receipts/'+p.name)
add(F/'recovery/events.json','fresh-case-reports/events.json');add(F/'recovery/summary.json','fresh-case-reports/summary.json')
for n in auth['approved_code_sha256']:add(Q/n,'fresh-code/'+n)
for n in ['authorization-fresh-F-v1.json','before-preparation.json','prelaunch-bindings.json','final-dry-admission.json','copy-hash-map.json','proposed-copy.diff','REVIEW.md','smoke-authorized-v1.py','controller-census-console-observations.json','collect-delta.py']:add(Q/n,'fresh-code-and-admission/'+n)
for p in sorted((Q/'smoke-v1').iterdir()):
 if p.is_file() and p.suffix in ['.json','.gz']:add(p,'fresh-benign-smoke/'+p.name)
add(D/'closeout.json','closeout.json');manifest=[{'member':name,'source':str(p),'bytes':p.stat().st_size,'sha256':c.digest(p)} for p,name in files];put('member-manifest.json',manifest);files.append((D/'member-manifest.json','member-manifest.json'))
def closing_bytes():
 total=0
 for b,ds,ns in os.walk(R):
  if Path(b)==R:ds[:]=[n for n in ds if n!='fixtures']
  for n in ns:total+=(Path(b)/n).stat().st_size
 return total
class BoundWriter:
 def __init__(self,p):self.f=p.open('xb');self.n=0
 def write(self,b):
  assert closing_bytes()+len(b)+131072<=4*1048576,'new-closing-and-temp4MiB';assert self.n+len(b)<=4*1048576;n=self.f.write(b);self.n+=n;return n
 def flush(self):self.f.flush()
 def tell(self):return self.n
path=D/'fresh-F24-282-native-delta.tar.gz';writer=BoundWriter(path)
try:
 with gzip.GzipFile(fileobj=writer,mode='wb',filename='',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|',format=tarfile.USTAR_FORMAT) as tar:
  for p,name in files:
   assert time.time()<CUT;data=p.read_bytes();m=tarfile.TarInfo(name);m.size=len(data);m.mode=0o644;m.mtime=0;tar.addfile(m,io.BytesIO(data))
finally:writer.f.close()
with tarfile.open(path,'r:gz') as tar:
 ms=tar.getmembers();assert len(ms)==len(files)
 for m,(p,name) in zip(ms,files):assert m.isfile() and m.name==name and tar.extractfile(m).read()==p.read_bytes()
meta={'status':summary['status'],'archive':str(path),'bytes':path.stat().st_size,'sha256':c.digest(path),'members':len(files),'member_raw_bytes':sum(p.stat().st_size for p,name in files),'member_manifest_sha256':c.digest(D/'member-manifest.json'),'member_manifest_bytes':(D/'member-manifest.json').stat().st_size,'fresh_cases':summary['fresh_actual_cases'],'fresh_events':len(events),'new_closing_bytes_including_archive':closing_bytes(),'actual_after_archive':c.enforce(),'old_all12953files_unchanged':True,'no_old_archive_or_fixture_payload_in_delta':True,'original_clocks_and_censor_unchanged':True}
put('return-binding.json',meta);assert c.census(Q)['bytes']<=1048576;print(json.dumps(meta,indent=2))

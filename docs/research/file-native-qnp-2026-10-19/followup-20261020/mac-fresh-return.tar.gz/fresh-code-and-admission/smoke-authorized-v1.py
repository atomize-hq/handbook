import os,sys,json,time,errno
from pathlib import Path
os.environ['P_CONTROLLER_PID']=str(os.getpid());os.environ['PYTHONDONTWRITEBYTECODE']='1'
import control as c
expected={'config.json':'57b016c19c48d2a961a31fb873addcb8cc0d14aeb4081d1ac229bcedd7113b63','control.py':'d3c2b17d08bce022ff11a5b058ae1afe0b8e4d9c9910662b34c231b6c801abef','actor.py':'80d1a9b8681cbd5b620c5ea78cc6b824831ac3a9abff66958d203412a661a7b8','execute.py':'3b115233c86f0065ee9bec0c8cb23f5f2ea4a07699e7d4efef769d85d6625457','launch.py':'d715ad93cb2c675e3f033a416c768b54ec32c1f42ce5dd7ed76a47c1bb097587'}
assert {n:c.digest(c.Q/n) for n in expected}==expected and not c.R.exists()
c.R=c.Q/'smoke-v1';c.F=c.R/'fixtures';assert not c.R.exists();c.R.mkdir();began=time.monotonic();c.CUTOFF=min(c.CUTOFF,time.time()+10)
p,res=c.run([sys.executable,'-B','-c','import json;print(json.dumps({"smoke":"benign","null":None}))'],10,'benign-json-guard-smoke',env=dict(os.environ),limit=268435456);assert p.returncode==0 and json.loads(p.stdout)=={'smoke':'benign','null':None}
value={'dict':'roundtrip','null':None};c.write_report(c.R/'dict-null.json',value);assert json.loads((c.R/'dict-null.json').read_bytes())==value
old_present=c.N['group_present'];old_popen=c.subprocess.Popen
class FakeNativeProbe:
 returncode=0
 def communicate(self,timeout):assert timeout==3;return b'',b''
def mocked_eperm(pgid):raise PermissionError(errno.EPERM,'synthetic-final-presence-permission-error')
def mocked_native_ps(argv,**kwargs):
 assert argv==['/bin/ps','-axo','pid=,ppid=,pgid=,state=,uid=,rss=,args='];return FakeNativeProbe()
try:
 c.N['group_present']=mocked_eperm;c.subprocess.Popen=mocked_native_ps;unknown=c.final_group_observation(-100001)
 assert unknown['remaining_group'] is None and unknown['errno']==1 and 'PermissionError' in unknown['error'];later=unknown['later_native_numeric_observation'];assert later['rows']==[] and later['exit']==0 and later['absence_verified_at_own_epoch'] is True and later['epoch']>=unknown['epoch']
finally:c.N['group_present']=old_present;c.subprocess.Popen=old_popen
assert time.monotonic()-began<10 and not (c.ROOT/'native-P-recovery-followup-20261020').exists();assert c.census(c.Q)['bytes']<=1048576
result={'status':'PASS','seconds':time.monotonic()-began,'guard_smoke':res,'synthetic_EPERM_unknown_then_later_absence':unknown,'synthetic_observation_is_not_a_native_process_claim':True,'dict_null_roundtrip':True,'fresh_F_root_absent':True,'no_engine_or_capsule_executed':True,'five_reviewed_code_hashes':expected}
c.write_report(c.R/'result.json',result);print(json.dumps(result,indent=2))

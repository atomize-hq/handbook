import os,sys,json,stat,hashlib,runpy,subprocess,datetime
from pathlib import Path
O=Path('/private/tmp/file-native-p-macos-20261020');C=O/'cargo-private-proposed';Q=C/'.p-native-qualification-prep-v2';NEW=C/'.p-recovery-followup-20261020';R=O/'native-P-recovery-followup-20261020';N=runpy.run_path(str(C/'.p-build-receipts-v6/build-supervisor.py'),run_name='reviewed_preservation_helpers_only');A=runpy.run_path(str(C/'.p-preservation-receipts-v6/archive-stage.py'),run_name='reviewed_sdk_helpers_only')
assert not NEW.exists() and not R.exists(),'fresh follow-up paths required'
def digest(p):return N['digest'](p)
whole=private=files=0;h=hashlib.sha256()
for b,ds,ns in os.walk(O,followlinks=False):
 ds.sort();ns.sort()
 for n in ds:assert not (Path(b)/n).is_symlink()
 for n in ns:
  p=Path(b)/n;s=p.lstat();assert stat.S_ISREG(s.st_mode);whole+=s.st_size;files+=1
  if p.is_relative_to(C):private+=s.st_size
  h.update(str(p.relative_to(O)).encode()+b'\0'+str(s.st_size).encode()+b'\0'+digest(p).encode()+b'\n')
auth=json.loads((Q/'authorization-parent-20261020T072200Z.json').read_bytes());actual={n:digest(Q/n) for n in auth['approved_code_sha256']};assert actual==auth['approved_code_sha256']
anchors=N['preservation']();qn=N['old_snapshots']();sdk=A['sdk']()
archives={str(p):{'bytes':p.stat().st_size,'sha256':digest(p)} for p in [O/'preservation-build-unit-v6/targets.tar.gz',O/'preservation-build-unit-v6/unit-fixture.tar.gz',O/'preservation-build-unit-v6/full-sorted-inventory.json',O/'native-P-full-closeout-v1/native-P-full-portable-return.tar.gz',O/'native-P-full-closeout-v1/supplemented-native-P-full-portable-return.tar.gz']}
expected=['163a4e98adcf372701fa8e68e35046b621439dfc0968251c24d926f3e7b0e8de','f86a392c3447d9657600a94f6a02a8229844cc5ba58900fc3e05b8e0cedddcdd','96ef101fde15c26547a4a8a4f57d8efb5a688b83db7c4a81a263ca5f673c18f7','032ab642f612583c6cbefb82fa80b2ff4e7069a1a4c6cdc2d50a346f6f819e61','85af97d4b7db4b0e010314b945575f028244a224f936328c0eac383868cea9c4'];assert [v['sha256'] for v in archives.values()]==expected
exe=O/'frozen-bin-private-proposed-v6/file-native-incremental';lib=Path('/opt/homebrew/Cellar/zstd/1.5.7_1/lib/libzstd.1.5.7.dylib');assert digest(exe)=='9ae57af7f16a05aa01d79b0aa88ce90b50f7669858548be6933cfc2d0f1c0def' and digest(lib)=='69d8dee81bccdee425d167300d11431f3c5ecc34a3011400e536aa89f7756189'
probe=subprocess.Popen(['/bin/ps','-axo','pid=,ppid=,pgid=,state=,uid=,rss=,args='],stdout=subprocess.PIPE,stderr=subprocess.PIPE);out,err=probe.communicate(timeout=3);assert probe.returncode==0;owned=[];allowed={os.getpid(),os.getppid(),probe.pid}
for line in out.decode().splitlines():
 x=line.strip().split(None,6)
 if len(x)==7 and str(O) in x[6] and int(x[0]) not in allowed:owned.append(line)
assert not owned,('owned-native-processes-remain',owned)
free=os.statvfs(O).f_bavail*os.statvfs(O).f_frsize;forecast=whole+(80+16+4+1)*1048576+1572864;ff=files+10000+256
assert forecast<=301989888 and ff<=30000 and private+1048576<=36*1048576 and free>=20*1024**3
report={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'read_only':True,'source145_core18_tools_private1520_shared1262':anchors,'old_QN':qn,'SDK':sdk,'old_nine_wrappers':actual,'old_archive_bindings':archives,'whole_bytes':whole,'files':files,'private_bytes':private,'old_owned_path_size_content_sha256':h.hexdigest(),'free_bytes':free,'forecast_bytes_with80MiBfixture16MiBreport4MiBclosing1MiBcode1_5MiBincidental':forecast,'forecast_files_with10000fixture_and256code_report_allowance':ff,'global_native_limit_bytes':301989888,'global_native_limit_files':30000,'no_deletion_credit':True,'native_process_rows':owned,'fresh_followup_paths_absent':True}
print(json.dumps(report,indent=2))

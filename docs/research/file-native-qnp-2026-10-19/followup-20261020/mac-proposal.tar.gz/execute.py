"""Fresh final-d70 F recovery only. Default is preparation; execution requires parent GO."""
import os,sys,json,hashlib,time,datetime,runpy
from pathlib import Path
Q=Path(__file__).resolve().parent
CODE=['config.json','control.py','actor.py','execute.py','launch.py']
def bindings():return {n:hashlib.sha256((Q/n).read_bytes()).hexdigest() for n in CODE}
def historical_preservation(c):
 before=json.loads((Q/'before-preparation.json').read_bytes());h=hashlib.sha256();total=files=0
 for b,dirs,names in os.walk(c.ROOT,followlinks=False):
  dirs[:]=sorted(d for d in dirs if not (Path(b)/d).is_relative_to(Q) and not (Path(b)/d).is_relative_to(c.R));names.sort()
  for d in dirs:assert not (Path(b)/d).is_symlink()
  for n in names:
   p=Path(b)/n;assert p.is_file() and not p.is_symlink();size=p.stat().st_size;h.update(str(p.relative_to(c.ROOT)).encode()+b'\0'+str(size).encode()+b'\0'+c.digest(p).encode()+b'\n');total+=size;files+=1
 assert h.hexdigest()==before['old_owned_path_size_content_sha256'] and total==before['whole_bytes'] and files==before['files'],'historical-owned-file-drift'
 for n,want in before['old_nine_wrappers'].items():assert c.digest(c.C/'.p-native-qualification-prep-v2'/n)==want
 assert c.N['old_snapshots']()==before['old_QN'];sdk=runpy.run_path(str(c.C/'.p-preservation-receipts-v6/archive-stage.py'),run_name='reviewed_sdk_definitions')['sdk']();assert sdk==before['SDK']
 for p,row in before['old_archive_bindings'].items():assert Path(p).stat().st_size==row['bytes'] and c.digest(Path(p))==row['sha256']
 return {'old_owned_files':files,'old_owned_bytes':total,'old_owned_path_size_content_sha256':h.hexdigest(),'old_nine_wrappers_match':True,'old_QN_SDK_archives_match':True}
def main():
 for n in CODE:
  if n.endswith('.py'):compile((Q/n).read_bytes(),str(Q/n),'exec')
 current=bindings()
 if len(sys.argv)==1:
  import control as c
  assert not c.R.exists(),'fresh followup output required'
  new_code=c.census(Q);assert new_code['bytes']<=1048576
  print(json.dumps({'status':'RECOVERY_ONLY_PREPARATION_EXECUTION_HOLD','code_sha256':current,'source_binding':c.sourcecheck(),'historical_preservation':historical_preservation(c),'live_private_shared_preservation':c.N['preservation'](),'dry_admission':c.admit_full(),'new_code':new_code,'no_engine_capsule_or_smoke_executed':True},indent=2));return
 assert len(sys.argv)==3 and sys.argv[1] in ['--execute','--worker']
 auth=json.loads(Path(sys.argv[2]).read_bytes());assert auth['parent_approved_fresh_recovery_execution'] is True and auth['approved_code_sha256']==current
 start=datetime.datetime.fromisoformat(auth['fixed_stage_start_utc'].replace('Z','+00:00')).timestamp();cut=datetime.datetime.fromisoformat(auth['fixed_stage_functional_cutoff_utc'].replace('Z','+00:00')).timestamp();assert start<=time.time()<cut and 0<cut-start<=1800
 os.environ['P_STAGE_CUTOFF']=str(cut);os.environ.setdefault('P_CONTROLLER_PID',str(os.getpid()));os.environ['PYTHONDONTWRITEBYTECODE']='1'
 import control as c
 window_start=datetime.datetime.fromisoformat(c.CFG['followup_start'].replace('Z','+00:00')).timestamp();assert start>=window_start and cut<=c.FOLLOWUP_CUTOFF
 if sys.argv[1]=='--execute':
  assert not c.R.exists();admission=c.admit_full();assert c.census(Q)['bytes']<=1048576;c.R.mkdir()
  child,res=c.run([sys.executable,'-B',str(Q/'execute.py'),'--worker',str(Path(sys.argv[2]).resolve())],1800,'complete-fresh-F-recovery-worker',env=dict(os.environ),limit=3221225472)
  c.write_report(c.R/'outer-closeout.json',{'exit':child.returncode,'resources':res,'actual':c.enforce(),'new_followup_clock':c.CFG['followup_functional_cutoff'],'old_censored_run_unchanged':True});assert child.returncode==0,child.stderr.decode();return
 assert c.R.exists() and not c.F.exists();admission=c.admit_full();source=c.sourcecheck();historical=historical_preservation(c);anchors=c.N['preservation']()
 c.write_report(c.R/'admission.json',{'authorization':auth,'actual':admission,'source_binding':source,'historical_preservation':historical,'preservation':anchors,'recovery_only':True,'fresh_fixture_no_resume':True})
 child,res=c.run([sys.executable,'-B',str(Q/'actor.py'),'recovery'],1800,'fresh-actual-F24-282',env=dict(os.environ),limit=3221225472)
 c.write_report(c.R/'phase-result.json',{'phase':'recovery','exit':child.returncode,'resources':res});assert child.returncode==0,child.stderr.decode()
 result=json.loads((c.R/'recovery-result.json').read_bytes());assert result['status']=='passed' and len(result['result']['cases'])==24 and result['result']['events']==282
 events=json.loads((c.F/'recovery/events.json').read_bytes());assert len(events)==282
 assert c.sourcecheck()==source and historical_preservation(c)==historical;after=c.N['preservation']()
 c.write_report(c.R/'final.json',{'status':'FRESH_F24_282_PASS_PENDING_PARENT_REVIEW','result':result,'engine_events':len(events),'source_binding':source,'historical_preservation':historical,'after_preservation':after,'resources':res,'actual':c.enforce(),'no_old_run_relabelled_or_resumed':True,'new_followup_functional_cutoff':c.CFG['followup_functional_cutoff']})
if __name__=='__main__':main()

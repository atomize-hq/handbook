import sys,os,json,time,hashlib,types,ctypes.util,threading,ast,contextlib
from pathlib import Path
import control as c
R=c.Q
PACK=c.ROOT/'source-final/docs/research/file-native-packing-2026-10-20';sys.path.insert(0,str(PACK));os.environ['FILE_NATIVE_P_EXE']=str(c.EXE);os.environ['FILE_NATIVE_P_ROOT']=str(c.ROOT);os.environ['PYTHONDONTWRITEBYTECODE']='1';shim=types.ModuleType('guard');shim.ROOT=c.ROOT;shim.CUTOFF=c.CUTOFF;sys.modules['guard']=shim
assert c.digest(c.LIB)==c.CFG['lib_sha256'];_find=ctypes.util.find_library;ctypes.util.find_library=lambda name:str(c.LIB) if name=='zstd' else _find(name)
# Install serialization before any consumer can import a shared decode context.
import independent
_decode=independent.Zstd.decode;_decode_lock=threading.Lock()
def serialized_decode(self,data,length):
 with _decode_lock:return _decode(self,data,length)
independent.Zstd.decode=serialized_decode
# Whole-group independent timers cover complete Python verifiers, including hangs.
def complete_verifier(fn):
 def bounded(*args,**kwargs):
  timer=c.N['arm'](os.getpgrp(),min(c.CUTOFF,time.time()+900))
  try:return fn(*args,**kwargs)
  finally:c.N['cancel'](timer)
 return bounded
independent.verify=complete_verifier(independent.verify)
nav=c.ROOT/'source-final/docs/research/file-native-navigation-2026-10-19';sys.path.insert(0,str(nav));import oracle
assert Path(oracle.__file__).resolve()==nav/'oracle.py'
oracle.verify=complete_verifier(oracle.verify)
# Only now may capsule and its legacy consumers bind verify/oracle names.
sys.path.insert(0,str(PACK));import driver,capsule
assert Path(capsule.__file__).resolve()==PACK/'capsule.py'
c.install_io()
identity=(c.EXE.stat().st_dev,c.EXE.stat().st_ino,c.EXE.stat().st_size,c.EXE.stat().st_mtime_ns);c.sourcecheck()
def native_call(self,root,action,code=0,env=None,timeout=120,exe_override=None,**fields):
 exe=Path(exe_override) if exe_override else c.EXE;assert exe.resolve()==c.EXE and (exe.stat().st_dev,exe.stat().st_ino,exe.stat().st_size,exe.stat().st_mtime_ns)==identity
 payload={'root':str(root),'action':action,**fields};environ={k:v for k,v in os.environ.items() if not k.startswith('EXP_')};environ['EXP_NAVIGATION']='4'
 if env:environ.update(env)
 bs,fs=c.engine_forecast(root,action,fields);limit=268435456 if action in ['resolve','point','inspect','lookup-bench'] else 2147483648
 with c.reserve(bs,fs,'engine:'+action):p,res=c.run([str(exe)],min(115,timeout),'engine-'+action,input=json.dumps(payload).encode(),env=environ,limit=limit)
 row={'input':payload,'exe':str(exe),'exe_sha256':c.EXPECTED,'env':env,'exit':p.returncode,'seconds':res['seconds'],'stdout':p.stdout.decode(),'stderr':p.stderr.decode(),'sampled_peak_rss':None,'missing_samples':res['guard']['missing_samples'],'rss_limit':limit,'violations':res['guard']['violations'],'native_guard':res['guard']}
 with self.lock:self.events.append(row);c.write_report(self.base/'events.json',json.dumps(self.events,indent=2))
 assert p.returncode==code,'unexpected-engine-exit:'+action+':'+str(p.returncode)+' expected '+str(code)
 return json.loads(p.stdout) if p.stdout else None
driver.Driver.call=native_call
# The frozen backup semantics run unchanged inside a whole-operation coexistence forecast.
backup=capsule.backup;_capture=backup.capture;_restore=backup.restore

def capture(source,dest,*args,**kw):
 x=c.census(source)
 with c.reserve(2*x['bytes']+x['files']*1024+1048576,2*x['files']+64,'operational-capture:'+str(dest),covered=True):return _capture(source,dest,*args,**kw)
def restore(source,dest,*args,**kw):
 x=c.census(source)
 with c.reserve(2*x['bytes']+x['files']*1024+1048576,2*x['files']+64,'operational-restore:'+str(dest),covered=True):return _restore(source,dest,*args,**kw)
backup.capture=capture;backup.restore=restore
ordinary_rows=[]
def ordinary(root,name,captured=None,save=None,code=0,destination_base=None):
 dest=Path(destination_base or c.F/'ordinary')/(name+'-copy');x=c.census(root);env=dict(os.environ,PYTHON=sys.executable,HELPER=str(R),STORE=str(root),OUT=str(dest),CAPTURED=str(captured) if captured else '',SAVE=str(save) if save else '')
 with c.reserve(2*x['bytes']+1048576,2*x['files']+64,'ordinary-selected-once-copy:'+name,covered=True):p,res=c.run(['/bin/bash',str(R/('ordinary-copy-focus.sh' if name.startswith('focus-') else 'ordinary-copy.sh'))],30,'bash-'+name,env=env,limit=268435456)
 row={'name':name,'root':str(root),'destination':str(dest),'captured':str(captured) if captured else None,'save':str(save) if save else None,'exit':p.returncode,'expected_success':code==0,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest(),'stdout':p.stdout.decode(),'stderr':p.stderr.decode(),'engine_or_pack_decoder_used':False,'selection_reads':1,'native_guard':res['guard']};ordinary_rows.append(row);c.write_report(c.R/(sys.argv[1]+'-ordinary-shell-events.json'),json.dumps(ordinary_rows,indent=2))
 assert (p.returncode==0)==(code==0),'ordinary-shell-unexpected-result:'+name
 if code!=0:assert 'selected-generation-missing' in p.stderr.decode(),'wrong-ordinary-refusal:'+name
 return json.loads(p.stdout) if p.returncode==0 else None

def immediate():
 base=c.F/'immediate';d=driver.Driver(base/'events');cases=[]
 for mode in ['A','B']:
  for count in [16,128]:
   name=mode+str(count);root=base/(name+'/disposable/store');d.call(root,'init',mode=mode,consumer='project',count=count);d.call(root,'lifecycle',operation='setup');before=ordinary(root,'immediate-'+name+'-before');packed=d.call(root,'packing',operation='build',codec='raw',include_attempts=True,cleanup=True);after=ordinary(root,'immediate-'+name+'-after');assert before['selected']==after['selected'] and before['files']==after['files'];cases.append({'case':'immediate-'+name+'-ordinary-selected-once-exact-copy','status':'passed','before_after_exact_files':True,'no_subsequent_publication':True,'packing_status':packed['result']['status']})
 result={'status':'passed','cases':cases,'engine_events':len(d.events),'ordinary_shell_processes':len(ordinary_rows)};c.write_report(c.R/'immediate-result.json',json.dumps(result,indent=2));print(json.dumps({'phase':'immediate','cases':len(cases),'engine_events':len(d.events),'ordinary_shell_processes':len(ordinary_rows)}));return result

def focus():
 original=PACK/'fix2_regression.py';text=original.read_text();tree=ast.parse(text);base=c.F/'focus';base.mkdir(exist_ok=False);d=driver.Driver(base/'events');shell=[];cases=[];m=json.loads((c.ROOT/'p-candidate-d70f-source-manifest.json').read_text());binding={'exe_sha256':c.EXPECTED,'files':{x['path']:x for x in m['final_core_files']}};ns={'__name__':'native_frozen_focus_body','__file__':str(original)}
 for node in tree.body:
  if isinstance(node,(ast.Import,ast.ImportFrom)):exec(compile(ast.Module(body=[node],type_ignores=[]),str(original),'exec'),ns)
 ns.update(base=base,here=PACK,exe=c.EXE,binding=binding,d=d,shell=shell,cases=cases)
 def ordinary_focus(root,name,captured=None,save=None,code=0):
  value=ordinary(root,'focus-'+name,captured,save,code,destination_base=base);shell.append(ordinary_rows[-1]);return value
 ns['ordinary']=ordinary_focus;start=next(node.lineno for node in tree.body if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='root' for t in node.targets));skip_line=next(i+1 for i,line in enumerate(text.splitlines()) if line.startswith('hold=exclusive_delete_handle'));selected=[node for node in tree.body if node.lineno>=start and node.lineno!=skip_line];c.write_report(c.R/'focus-AST-selection.json',json.dumps({'frozen_source_sha256':hashlib.sha256(original.read_bytes()).hexdigest(),'selected_original_top_level_line_numbers':[x.lineno for x in selected],'only_case_skipped':'B-control-no-delete-sharing-remains-retained','skip_reason':'Windows handle-sharing only; not emulated on POSIX','omitted_bootstrap':'Windows binary/PowerShell binding and duplicate harness-source copies; replaced by authoritative native binding and ordinary Bash helper'},indent=2))
 for node in selected:exec(compile(ast.Module(body=[node],type_ignores=[]),str(original),'exec'),ns)
 result=ns['result'];assert len(result['cases'])==8 and result['events']==25 and len(result['ordinary_shell'])==9;c.write_report(c.R/'focus-result.json',json.dumps({'status':'passed','result':result,'windows_only_skips':['B-control-no-delete-sharing-remains-retained']},indent=2));return result

def main(mode):
 assert mode=='recovery','recovery-only-followup'
 c.F.mkdir(exist_ok=True);binding=c.sourcecheck()
 if mode=='immediate':result=immediate()
 elif mode=='capsule':
  result=capsule.run(c.F/'capsule');assert len(result['cases'])==52;c.write_report(c.R/'capsule-result.json',json.dumps({'status':'passed','result':result,'windows_only_skips':['windows-loose-no-delete-sharing-A','windows-loose-no-delete-sharing-B']},indent=2))
 elif mode=='strict':
  import strict_supplement
  with c.reserve(25165824,1000,'complete-strict24-including16MiBtruncate-and-clones',covered=True):result=strict_supplement.run(c.F/'capsule',c.F/'strict')
  assert len(result['cases'])==24;c.write_report(c.R/'strict-result.json',json.dumps(result,indent=2))
 elif mode=='recovery':
  import loose_regression as lr
  rows=[]
  def bounded(argv,input=None,env=None,**kw):
   payload=json.loads(input);action=payload['action'];bs,fs=c.engine_forecast(payload['root'],action,payload);limit=268435456 if action in ['resolve','point','inspect'] else 2147483648
   environ=dict(env or os.environ);environ['EXP_NAVIGATION']='4'
   with c.reserve(bs,fs,'actual-prior-engine:'+action):p,res=c.run(list(map(str,argv)),115,'actual-prior-'+action,input=input,env=environ,limit=limit)
   rows.append({'action':action,'exit':p.returncode,'guard':res['guard']});return p
  lr.prior.subprocess=types.SimpleNamespace(run=bounded);result=lr.prior.run(c.EXE,c.F/'recovery');assert len(result['cases'])==24 and result['events']==282;c.write_report(c.R/'recovery-result.json',json.dumps({'status':'passed','result':result,'native_engine_resources':rows},indent=2))
 elif mode=='focus':result=focus()
 else:raise ValueError(mode)
 assert c.sourcecheck()==binding;summary={'epoch':time.time(),'phase':mode,'status':'passed','source_binding':binding,'ownership':c.ownership(),'case_event_format':'plain UTF-8 compact JSON preserving every original value and raw stdout/stderr string; raw process ledger explicitly named .jsonl.gz','original145modules_unchanged':True};c.write_report(c.R/(mode+'-phase-summary.json'),json.dumps(summary,indent=2));print(json.dumps({'phase':mode,'status':'passed','ownership':summary['ownership']},separators=(',',':')))
if __name__=='__main__':main(sys.argv[1])

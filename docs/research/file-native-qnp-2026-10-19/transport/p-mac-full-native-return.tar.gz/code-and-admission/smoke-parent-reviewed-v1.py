import os,sys,json,time,hashlib,subprocess
from pathlib import Path
os.environ['P_STAGE_CUTOFF']='1792482720';os.environ['P_CONTROLLER_PID']=str(os.getpid());os.environ['PYTHONDONTWRITEBYTECODE']='1'
import control as c
assert c.digest(c.Q/'control.py')=='56fc2ff83fa16f0244e0a8cf8613f4443b49d6733d59513953787534edc0c34c'
assert not c.R.exists(),'full qualification root must remain fresh'
for p in [c.ROOT,*c.ROOT.parents]:assert not p.is_symlink() and p.resolve()==p
before=c.sourcecheck();admission=c.admit_full()
for pgid in [50316,70997,85083]:assert not c.N['group_present'](pgid)
probe=subprocess.Popen(['/bin/ps','-axo','pid=,ppid=,pgid=,command='],stdout=subprocess.PIPE,stderr=subprocess.PIPE);out,err=probe.communicate(timeout=2);assert probe.returncode==0
allowed={os.getpid(),os.getppid(),probe.pid};owned=[]
for line in out.decode().splitlines():
 parts=line.strip().split(None,3)
 if len(parts)==4 and str(c.ROOT) in parts[3] and int(parts[0]) not in allowed:owned.append(line)
assert not owned,('owned-process-quiescence',owned)
c.R=c.ROOT/'native-P-smoke-v1';c.F=c.R/'fixtures';assert not c.R.exists();c.R.mkdir();start=time.monotonic()
p,res=c.run([sys.executable,'-B','-c','import json;print(json.dumps({"smoke":"benign","null":None}))'],10,'benign-python-smoke',env=dict(os.environ),limit=268435456)
assert p.returncode==0 and json.loads(p.stdout)=={'smoke':'benign','null':None};value={'smoke':'dict-report','null':None,'resource':res};c.write_report(c.R/'report.json',value);assert json.loads((c.R/'report.json').read_bytes())==value
assert time.monotonic()-start<10 and c.census(c.R)['bytes']<=2*1048576 and not (c.ROOT/'native-P-full-v1').exists();assert c.sourcecheck()==before
c.write_report(c.R/'result.json',{'status':'PASS','no_engine_or_capsule':True,'resource':res,'seconds':time.monotonic()-start,'binding':before,'initial_admission':admission,'smoke_census':c.census(c.R),'full_root_absent':True})
print((c.R/'result.json').read_text())

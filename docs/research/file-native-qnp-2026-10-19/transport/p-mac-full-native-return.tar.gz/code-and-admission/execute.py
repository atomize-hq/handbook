"""Default is read-only preparation validation. Full execution needs reviewed authorization."""
import sys,os,json,hashlib,time,datetime,runpy,contextlib,io
from pathlib import Path
Q=Path(__file__).resolve().parent
CODE=['config.json','control.py','actor.py','execute.py','launch.py','ordinary-route.py','ordinary-manifest.py','ordinary-copy.sh','ordinary-copy-focus.sh']
def bindings():return {name:hashlib.sha256((Q/name).read_bytes()).hexdigest() for name in CODE}
def syntax():
 for name in CODE:
  if name.endswith('.py'):compile((Q/name).read_bytes(),str(Q/name),'exec')
def main():
 syntax();current=bindings()
 if len(sys.argv)==1:
  import control as c
  print(json.dumps({'status':'PREPARATION_ONLY_NATIVE_EXECUTION_HOLD','code_sha256':current,'binding':c.sourcecheck(),'dry_admission':c.admit_full(),'plain_JSON':'all values preserved; old+temporary <=16MiB or explicit refusal','no_engine_or_capsule_imported':True},indent=2));return
 assert len(sys.argv)==3 and sys.argv[1] in ['--execute','--worker'],'usage: execute.py [--execute AUTHORIZATION.json]'
 auth=json.loads(Path(sys.argv[2]).read_bytes());assert auth['parent_approved_full_native_execution'] is True and auth['approved_code_sha256']==current,'unreviewed code';start=datetime.datetime.fromisoformat(auth['fixed_stage_start_utc'].replace('Z','+00:00')).timestamp();cut=datetime.datetime.fromisoformat(auth['fixed_stage_functional_cutoff_utc'].replace('Z','+00:00')).timestamp();assert start<=time.time()<cut and cut-start<=1800
 os.environ['P_STAGE_CUTOFF']=str(cut);os.environ.setdefault('P_CONTROLLER_PID',str(os.getpid()));os.environ['PYTHONDONTWRITEBYTECODE']='1'
 import control as c
 assert cut<=c.ORIGINAL,'fixed original cutoff'
 if sys.argv[1]=='--execute':
  assert not c.R.exists(),'fresh output required';admission=c.admit_full();c.R.mkdir()
  child,res=c.run([sys.executable,'-B',str(Q/'execute.py'),'--worker',str(Path(sys.argv[2]).resolve())],1800,'complete-native-qualification-worker',env=dict(os.environ),limit=3221225472)
  c.write_report(c.R/'outer-closeout.json',{'exit':child.returncode,'resources':res,'actual':c.enforce(),'original_clocks_unchanged':True});assert child.returncode==0,child.stderr.decode();return
 # launch.py consumed the activation byte only after the parent armed its timer.
 assert c.R.exists() and not c.F.exists(),'fresh worker fixtures required';admission=c.admit_full();before=c.sourcecheck();anchors=c.N['preservation']();qn=c.N['old_snapshots']();sdk=runpy.run_path(str(c.C/'.p-preservation-receipts-v6/archive-stage.py'),run_name='reviewed_sdk_definitions')['sdk']()
 c.write_report(c.R/'admission.json',{'authorization':auth,'actual':admission,'binding':before,'preservation':anchors,'old_QN':qn,'SDK':sdk});phase_rows=[]
 for phase in c.CFG['phases']:
  assert time.time()<c.CUTOFF
  env=dict(os.environ);env['PYTHONDONTWRITEBYTECODE']='1'
  p,res=c.run([sys.executable,'-B',str(Q/'actor.py'),phase],1800,'phase-'+phase,env=env,limit=3*1024**3)
  phase_rows.append({'phase':phase,'exit':p.returncode,'resources':res});c.write_report(c.R/'phase-results.json',phase_rows);assert p.returncode==0,('phase-failed',phase,p.stderr.decode())
 assert c.sourcecheck()==before and c.N['old_snapshots']()==qn
 after=c.N['preservation']();assert runpy.run_path(str(c.C/'.p-preservation-receipts-v6/archive-stage.py'),run_name='reviewed_sdk_definitions')['sdk']()==sdk
 # Explicit cardinality checks on fresh actual native receipts; no historical reuse.
 immediate=json.loads((c.R/'immediate-result.json').read_bytes());packing=json.loads((c.R/'capsule-result.json').read_bytes());strict=json.loads((c.R/'strict-result.json').read_bytes());focus=json.loads((c.R/'focus-result.json').read_bytes());recovery=json.loads((c.R/'recovery-result.json').read_bytes())
 assert len(immediate['cases'])==4 and immediate['engine_events']==12 and immediate['ordinary_shell_processes']==8
 assert len(packing['result']['cases'])==52
 pe=json.loads((c.F/'capsule/events.json').read_bytes());assert len(pe)==267
 assert len(strict['cases'])==24 and len(focus['result']['cases'])==8 and focus['result']['events']==25 and len(focus['result']['ordinary_shell'])==9
 assert len(recovery['result']['cases'])==24 and recovery['result']['events']==282
 c.write_report(c.R/'final.json',{'status':'PASS','source_binding':before,'after_preservation':after,'old_QN_SDK_match':True,'phases':phase_rows,'packing':52,'packing_engine_events':267,'strict':24,'focus':8,'focus_engine_events':25,'actual_F':24,'actual_F_events':282,'ordinary_Bash_processes':17,'windows_only_skips':['windows-loose-no-delete-sharing-A','windows-loose-no-delete-sharing-B','B-control-no-delete-sharing-remains-retained'],'account':c.enforce()})
if __name__=='__main__':main()

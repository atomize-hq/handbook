"""Activation-gated exec: timer is armed before any authored workload starts."""
import os,sys,json
assert os.read(0,1)==b'G','activation denied'
argv=json.loads(sys.argv[1]);os.execve(argv[0],argv,dict(os.environ))

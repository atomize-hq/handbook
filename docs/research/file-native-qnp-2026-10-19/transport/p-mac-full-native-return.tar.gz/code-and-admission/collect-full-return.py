"""Artifact-only post-run collector. Never runs engine, capsule, build, or cleanup."""
import os,sys,json,time,hashlib,gzip,tarfile,io,runpy,subprocess,datetime,stat
from pathlib import Path
Q=Path(__file__).resolve().parent;C=Q.parent;O=C.parent;R=O/'native-P-full-v1';F=R/'fixtures';D=O/'native-P-full-closeout-v1';CAP=4*1048576;CUT=datetime.datetime.fromisoformat('2026-10-20T08:02:00+00:00').timestamp()
assert time.time()<CUT and not D.exists();D.mkdir()
N=runpy.run_path(str(C/'.p-build-receipts-v6/build-supervisor.py'),run_name='reviewed_helpers_only');A=runpy.run_path(str(C/'.p-preservation-receipts-v6/archive-stage.py'),run_name='reviewed_preservation_only')
def sha(p):return N['digest'](p)
def put(name,value):
 data=(json.dumps(value,indent=2)+'\n').encode();assert len(data)<=1048576
 with (D/name).open('xb') as f:f.write(data)
def ownership():
 rows=[];total=files=0
 for b,ds,ns in os.walk(O,followlinks=False):
  for n in ds:assert not (Path(b)/n).is_symlink()
  for n in ns:
   p=Path(b)/n;s=p.lstat();assert stat.S_ISREG(s.st_mode);total+=s.st_size;files+=1
 return {'bytes':total,'files':files}
# No further signals: live owned processes cause HOLD rather than forced reclamation.
probe=subprocess.Popen(['/bin/ps','-axo','pid=,ppid=,pgid=,rss=,command='],stdout=subprocess.PIPE,stderr=subprocess.PIPE);raw,err=probe.communicate(timeout=3);assert probe.returncode==0
allowed={os.getpid(),os.getppid(),probe.pid};live=[]
for line in raw.decode().splitlines():
 fields=line.strip().split(None,4)
 if len(fields)==5 and str(O) in fields[4] and int(fields[0]) not in allowed:live.append(line)
assert not live,('owned-processes-remain',live)
processes=[]
with gzip.open(R/'raw-process-events.jsonl.gz','rt') as f:
 for line in f:processes.append(json.loads(line))
sampled_pgids=set()
with gzip.open(R/'rss-samples.jsonl.gz','rt') as f:
 for line in f:sampled_pgids.add(json.loads(line)['pgid'])
pgids=sorted({row['guard']['pgid'] for row in processes}|sampled_pgids);closures={str(pgid):not N['group_present'](pgid) for pgid in pgids};assert all(closures.values())
anchors=N['preservation']();qn=N['old_snapshots']();sdk=A['sdk']();before=json.loads((R/'admission.json').read_bytes());assert qn==before['old_QN'] and sdk==before['SDK'],'QN-or-SDK-drift';exe=O/'frozen-bin-private-proposed-v6/file-native-incremental';assert sha(exe)=='9ae57af7f16a05aa01d79b0aa88ce90b50f7669858548be6933cfc2d0f1c0def';manifest=O/'p-candidate-d70f-source-manifest.json';assert sha(manifest)=='0c636670f89bd11086b139b966452d4f852e537d06997aa1f6649af5ad01d29a'
lib=Path('/opt/homebrew/Cellar/zstd/1.5.7_1/lib/libzstd.1.5.7.dylib');assert sha(lib)=='69d8dee81bccdee425d167300d11431f3c5ecc34a3011400e536aa89f7756189'
archive_bindings={str(p):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in [O/'preservation-build-unit-v6/targets.tar.gz',O/'preservation-build-unit-v6/unit-fixture.tar.gz',O/'preservation-build-unit-v6/full-sorted-inventory.json']}
assert [x['sha256'] for x in archive_bindings.values()]==['163a4e98adcf372701fa8e68e35046b621439dfc0968251c24d926f3e7b0e8de','f86a392c3447d9657600a94f6a02a8229844cc5ba58900fc3e05b8e0cedddcdd','96ef101fde15c26547a4a8a4f57d8efb5a688b83db7c4a81a263ca5f673c18f7']
code_names=['config.json','control.py','actor.py','execute.py','launch.py','ordinary-route.py','ordinary-manifest.py','ordinary-copy.sh','ordinary-copy-focus.sh'];code={n:sha(Q/n) for n in code_names};auth=json.loads((Q/'authorization-parent-20261020T072200Z.json').read_bytes());assert code==auth['approved_code_sha256']
case_paths={'immediate':'immediate/events/events.json','capsule':'capsule/events.json','strict':'strict/events.json','focus':'focus/events/events.json','recovery':'recovery/events.json'};sequences={}
for name,path in case_paths.items():
 p=F/path
 if p.exists():
  rows=json.loads(p.read_bytes());sequences[name]={'events':len(rows),'action_exit_sequence':[{'action':x['input']['action'],'exit':x['exit']} for x in rows]}
summary={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS_PENDING_PARENT_REVIEW' if (R/'final.json').exists() else 'INCOMPLETE_OR_FAILED_PREFIX','phase_results':json.loads((R/'phase-results.json').read_bytes()) if (R/'phase-results.json').exists() else [],'sequences':sequences,'completed_processes':len(processes),'cutoff_observation':{'functional_cutoff':'2026-10-20T07:52:00Z','outer_execute_exit':1,'cutoff_PGID':8284,'native_ps_at_cutoff':[{'pid':8284,'ppid':8254,'rss_bytes':0}],'signal_zero_errno':1,'cutoff_closeout_exception':'PermissionError: [Errno 1] Operation not permitted','outer_guard_receipt_committed':False,'read_only_owned_process_census_empty_at':'2026-10-20T07:52:26Z','no_post_cutoff_functional_work':True},'guard_reasons':[{'name':x['name'],'reason':x['guard']['reason']} for x in processes if x['guard']['reason']],'missing_RSS_samples':sum(x['guard']['missing_samples'] for x in processes),'NULL_peak_processes':[x['name'] for x in processes if x['guard']['peak_group_rss_bytes'] is None],'all_recorded_and_sampled_PGIDs_closed':closures,'sampled_PGIDs_without_completed_child_receipt':sorted(sampled_pgids-{row['guard']['pgid'] for row in processes}),'before_after_QN_SDK_match':True,'frozen_exe_sha256':sha(exe),'native_owned_command_census_empty':True,'after_preservation':anchors,'old_QN':qn,'SDK':sdk,'archive_bindings':archive_bindings,'source_manifest_sha256':sha(manifest),'library_sha256':sha(lib),'corrected_code_sha256':code,'ownership_before_return':ownership(),'functional_cutoff':'2026-10-20T07:52:00Z','artifact_cutoff':'2026-10-20T08:02:00Z','original_clocks_unchanged':True}
put('closeout.json',summary)
files=[]
def add(p,name):
 if p.exists():assert p.is_file() and not p.is_symlink();files.append((p,name))
for p in sorted(R.iterdir()):
 if p.is_file() and (p.suffix=='.json' or p.suffix=='.gz'):add(p,'native-receipts/'+p.name)
for name,path in case_paths.items():add(F/path,'case-events/'+name+'-events.json')
for name in case_paths:
 add(F/name/'summary.json','case-events/'+name+'-summary.json')
add(F/'focus/B-independent.json','case-events/focus-B-independent.json')
for n in code_names+['control-before-parent-review.py','smoke-parent-reviewed-v1.py','FINAL-bound-dry-admission.json','authorization-parent-20261020T072200Z.json','REVIEW.md','collect-full-return.py']:add(Q/n,'code-and-admission/'+n)
for p in sorted((O/'native-P-smoke-v1').iterdir()):
 if p.is_file() and (p.suffix in ['.json','.gz']):add(p,'benign-smoke/'+p.name)
add(manifest,'bindings/source145-manifest.json');add(D/'closeout.json','closeout.json')
member_manifest=[{'member':name,'source':str(p),'bytes':p.stat().st_size,'sha256':sha(p)} for p,name in files];put('member-manifest.json',member_manifest);files.append((D/'member-manifest.json','member-manifest.json'))
class BoundWriter:
 def __init__(self,p):self.f=p.open('xb');self.n=0
 def write(self,b):
  existing=sum(p.stat().st_size for p in R.iterdir() if p.is_file())+sum(p.stat().st_size for p in D.iterdir() if p.is_file())
  assert existing+len(b)+131072<=CAP,'all-closing-receipts-and-return-4MiB';assert self.n+len(b)<=CAP,'portable-archive-4MiB';n=self.f.write(b);self.n+=n;return n
 def flush(self):self.f.flush()
 def tell(self):return self.n
path=D/'native-P-full-portable-return.tar.gz';writer=BoundWriter(path)
try:
 with gzip.GzipFile(fileobj=writer,mode='wb',filename='',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|',format=tarfile.USTAR_FORMAT) as tar:
  for p,name in files:
   assert time.time()<CUT;data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
finally:writer.f.close()
with tarfile.open(path,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(files)
 for member,(source,name) in zip(members,files):assert member.isfile() and member.name==name and tar.extractfile(member).read()==source.read_bytes()
final=ownership();assert final['bytes']+1572864<=288*1048576 and final['files']<=30000
binding={'path':str(path),'bytes':path.stat().st_size,'sha256':sha(path),'members':len(files),'member_raw_bytes':sum(p.stat().st_size for p,n in files),'member_manifest_bytes':(D/'member-manifest.json').stat().st_size,'member_manifest_sha256':sha(D/'member-manifest.json'),'status':summary['status'],'actual_final_ownership':final,'all_raw_native_files_retained':True,'no_fixture_payload_or_cache_or_large_preservation_archive_in_return':True};put('return-binding.json',binding);print(json.dumps(binding,indent=2))

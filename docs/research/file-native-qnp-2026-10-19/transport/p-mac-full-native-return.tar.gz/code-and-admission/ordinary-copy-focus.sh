#!/bin/bash
set -euo pipefail
# SELECTED is read once by the route helper, before any content copy.
tree="$("$PYTHON" -B "$HELPER/ordinary-route.py" "$STORE" "$OUT" "$CAPTURED" "$SAVE")"
/bin/cp -R "$tree"/. "$OUT"/
"$PYTHON" -B "$HELPER/ordinary-manifest.py" "$OUT"

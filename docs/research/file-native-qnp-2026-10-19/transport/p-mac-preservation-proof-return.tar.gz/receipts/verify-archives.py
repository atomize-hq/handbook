"""Independent streaming USTAR+gzip verifier; never extracts or writes archives."""
import gzip,hashlib,json,sys,time
from pathlib import Path,PurePosixPath
P=Path('/private/tmp/file-native-p-macos-20261020/preservation-build-unit-v6')
R=Path('/private/tmp/file-native-p-macos-20261020/cargo-private-proposed/.p-preservation-receipts-v6')
def read_exact(f,n):
 b=f.read(n)
 if len(b)!=n:raise ValueError('truncated archive')
 return b
def number(b):return int(b.rstrip(b'\0 ').lstrip(b' ') or b'0',8)
def sha_file(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def verify(label,rows,cap):
 archive=P/(label+'.tar.gz');assert archive.stat().st_size<=cap
 expected={r['path']:r for r in rows};assert len(expected)==len(rows);seen=set();payload=0;directories=0;headers=0
 with gzip.open(archive,'rb') as f:
  while True:
   h=read_exact(f,512)
   if h==b'\0'*512:
    assert read_exact(f,512)==b'\0'*512
    padding=1024
    while True:
     b=f.read(1048576)
     if not b:break  # gzip CRC/ISIZE and compressed EOF have now been read.
     assert not b.strip(b'\0'),'nonzero trailing tar data'
     padding+=len(b)
    assert padding<=10240 and padding%512==0
    break
   assert h[257:263]==b'ustar\0'
   assert number(h[148:156])==sum(h[:148])+8*32+sum(h[156:]),'header checksum'
   name=h[:100].split(b'\0',1)[0].decode('utf-8');prefix=h[345:500].split(b'\0',1)[0].decode('utf-8')
   name=((prefix+'/') if prefix else '')+name;kind=h[156:157]
   assert kind in [b'0',b'\0',b'5'],'only regular files and directories admitted'
   if kind==b'5':name=name.rstrip('/')
   pp=PurePosixPath(name);assert not pp.is_absolute() and '..' not in pp.parts and str(pp)==name
   assert name in expected and name not in seen,(label,name);seen.add(name);row=expected[name]
   size=number(h[124:136]);mode=number(h[100:108]);assert mode==row['mode']
   assert h[157:257].strip(b'\0')==b'','link target forbidden'
   if kind==b'5':assert row['type']=='directory' and size==0;directories+=1
   else:
    assert row['type']=='regular' and size==row['bytes'];digest=hashlib.sha256();left=size
    while left:
     b=read_exact(f,min(left,1048576));digest.update(b);left-=len(b)
    assert digest.hexdigest()==row['sha256'],name;payload+=size
   pad=(-size)%512
   if pad:assert read_exact(f,pad)==b'\0'*pad
   headers+=1
 assert seen==set(expected),'missing archive members'
 return {'label':label,'archive_bytes':archive.stat().st_size,'archive_sha256':sha_file(archive),'all_names_types_modes_sizes_hashes_match':True,'gzip_CRC_ISIZE_EOF':True,'USTAR_checksum_padding_EOF':True,'members':headers,'regular_members':len(rows)-directories,'directory_members':directories,'raw_regular_bytes':payload,'no_extract_restore_or_copy':True}
if __name__=='__main__':
 inv=json.loads((P/'full-sorted-inventory.json').read_bytes())
 out=[verify('targets',inv['targets'],36*1048576),verify('unit-fixture',inv['unit-fixture'],2*1048576)]
 result={'status':'PASS','verifier':'independent manual USTAR parsing and gzip CRC/EOF reader; no tarfile parsing used','archives':out}
 with (R/'independent-verifier-result.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
 print(json.dumps(result,indent=2))

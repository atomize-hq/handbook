"""Parent-authorized preservation ONLY. No deletion, restore, compiler or engine."""
import os,sys,time,json,hashlib,stat,gzip,tarfile,subprocess,datetime,runpy
from pathlib import Path
M=1048576;O=Path('/private/tmp/file-native-p-macos-20261020');C=O/'cargo-private-proposed';R=C/'.p-preservation-receipts-v6';P=O/'preservation-build-unit-v6'
S=O/'source-final/docs/research/file-native-incremental-engine-experiment-2026-10-18'
TARGETS=[O/'target-private-proposed',O/'target-private-proposed-v2',O/'target-private-proposed-v3',O/'target-private-proposed-v4',O/'target-private-proposed-v5',O/'target-private-proposed-v6']
U=S/'target';CUT=datetime.datetime.fromisoformat('2026-10-20T06:58:00+00:00').timestamp()
ns=runpy.run_path(str(C/'.p-build-receipts-v6/build-supervisor.py'),run_name='import_reviewed_signal_and_preservation_helpers')
def now():return ns['utc']()
def sha(p):return ns['digest'](p)
def save(n,d):
 p=R/n;assert not p.exists();raw=(json.dumps(d,indent=2)+'\n').encode();assert len(raw)<M
 with p.open('xb') as f:f.write(raw)
def paths(root):
 assert not root.is_symlink() and root.resolve()==root
 if not root.exists():return []
 out=[root]
 for parent,dirs,names in os.walk(root,followlinks=False):
  for n in dirs+names:
   p=Path(parent)/n;st=p.lstat();assert stat.S_ISDIR(st.st_mode) or stat.S_ISREG(st.st_mode),('nonregular',str(p));out.append(p)
 return sorted(set(out))
def inventory(roots):
 rows=[];absent=[]
 for root in roots:
  if not root.exists():absent.append(str(root));continue
  for p in paths(root):
   st=p.lstat();kind='directory' if stat.S_ISDIR(st.st_mode) else 'regular'
   r={'path':str(p.relative_to(O)),'type':kind,'bytes':st.st_size if kind=='regular' else 0,'sha256':sha(p) if kind=='regular' else None,'mode':stat.S_IMODE(st.st_mode),'mtime_ns':st.st_mtime_ns,'device':st.st_dev,'inode':st.st_ino,'nlink':st.st_nlink}
   info=tarfile.TarInfo(r['path']+('/' if kind=='directory' else ''));info.type=tarfile.DIRTYPE if kind=='directory' else tarfile.REGTYPE;info.size=r['bytes'];info.mode=r['mode'];info.tobuf(format=tarfile.USTAR_FORMAT,encoding='utf-8',errors='strict')
   rows.append(r)
 return sorted(rows,key=lambda x:x['path']),absent
def footprint(root):
 return sum(p.lstat().st_size for p in paths(root) if p.is_file()) if root.exists() else 0
def account():
 whole=0;files=0;cache=0;preserve=0;other=0;target=0;frozen=0;unit=0
 for p in paths(O):
  st=p.lstat()
  if not stat.S_ISREG(st.st_mode):continue
  whole+=st.st_size;files+=1
  if p.is_relative_to(C):cache+=st.st_size
  elif p.is_relative_to(P):preserve+=st.st_size
  elif any(p.is_relative_to(t) for t in TARGETS):target+=st.st_size
  elif p.is_relative_to(U):unit+=st.st_size
  elif p.is_relative_to(O/'frozen-bin-private-proposed-v6'):frozen+=st.st_size
  else:other+=st.st_size
 assert cache<=36*M and preserve<=40*M and other+1572864<=4*M and target<=164*M and frozen<=8*M and unit<=84*M
 assert whole+1572864<=256*M and files<=5000
 assert os.statvfs(O).f_bavail*os.statvfs(O).f_frsize>20*1024**3
 return {'whole_bytes':whole,'files':files,'private_bytes':cache,'preservation_bytes':preserve,'targets_bytes':target,'unit_bytes':unit,'frozen_bytes':frozen,'other_bytes':other,'incidental_reserve_bytes':1572864}
def noncase():
 h=hashlib.sha256();n=total=0
 for p in paths(O):
  if p.is_relative_to(P) or p.is_relative_to(R) or p.is_relative_to(U) or any(p.is_relative_to(t) for t in TARGETS):continue
  st=p.lstat()
  if not stat.S_ISREG(st.st_mode):continue
  rel=str(p.relative_to(O));h.update(rel.encode()+b'\0'+str(st.st_size).encode()+b'\0'+sha(p).encode()+b'\n');n+=1;total+=st.st_size
 return {'files':n,'bytes':total,'full_sorted_path_size_content_sha256':h.hexdigest()}
class BoundedWriter:
 def __init__(self,p,cap):self.f=p.open('xb');self.cap=cap;self.n=0
 def write(self,b):
  assert self.n+len(b)<=self.cap,'archive bound exceeded';n=self.f.write(b);self.n+=n;return n
 def flush(self):self.f.flush()
 def tell(self):return self.n
 def close(self):self.f.close()
def archive(label,rows,cap):
 assert time.time()<CUT-10;account();p=P/(label+'.tar.gz');writer=BoundedWriter(p,cap)
 try:
  with gzip.GzipFile(fileobj=writer,mode='wb',compresslevel=6,mtime=0) as gz:
   with tarfile.open(fileobj=gz,mode='w|',format=tarfile.USTAR_FORMAT,dereference=True) as tar:
    for row in rows:
     assert time.time()<CUT-5
     q=O/row['path'];st=q.lstat();assert (st.st_dev,st.st_ino,st.st_mtime_ns,st.st_nlink)==(row['device'],row['inode'],row['mtime_ns'],row['nlink'])
     info=tarfile.TarInfo(row['path']+('/' if row['type']=='directory' else ''));info.mode=row['mode'];info.mtime=0;info.uid=info.gid=0;info.uname=info.gname=''
     if row['type']=='directory':info.type=tarfile.DIRTYPE;info.size=0;tar.addfile(info)
     else:
      assert st.st_size==row['bytes'];info.type=tarfile.REGTYPE;info.size=row['bytes']
      with q.open('rb') as f:tar.addfile(info,f)
 finally:writer.close()
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p),'regular_members':sum(r['type']=='regular' for r in rows),'directory_members':sum(r['type']=='directory' for r in rows),'all_originals_retained':True}
def sdk():
 rows=json.loads((C/'.p-build-receipts-v6/SDK-before.json').read_bytes())['SDK_bindings']
 for row in rows:
  p=Path(row['path']);assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256']
 return rows
def worker():
 assert sys.stdin.buffer.read(1)==b'G';assert time.time()<CUT-30;assert not P.exists()
 before=account();assert before['whole_bytes']+36*M+2*M+M+2*M+1572864<=256*M
 assert footprint(R)<=2*M
 source=ns['preservation']();old=ns['old_snapshots']();sdk_before=sdk();frozen=O/'frozen-bin-private-proposed-v6/file-native-incremental';assert sha(frozen)=='9ae57af7f16a05aa01d79b0aa88ce90b50f7669858548be6933cfc2d0f1c0def'
 original_noncase=noncase();targets,absent=inventory(TARGETS);unit,unit_absent=inventory([U]);assert not unit_absent
 assert sum(r['type']=='regular' for r in targets)==456 and sum(r['bytes'] for r in targets)==89141974
 assert sum(r['type']=='regular' for r in unit)==8 and sum(r['bytes'] for r in unit)==80976318
 save('before.json',{'utc':now(),'account':before,'preservation':source,'old_QN':old,'SDK':sdk_before,'noncase':original_noncase,'target_absent':absent,'target_regular_bytes':89141974,'unit_regular_bytes':80976318})
 P.mkdir();raw=(json.dumps({'targets':targets,'unit-fixture':unit,'absent_target_roots':absent,'metadata_note':'Archives preserve type/path/mode/content; inventory retains original mtime_ns/device/inode/nlink. Tar metadata timestamps normalized0; no restoration performed.'},indent=2)+'\n').encode();assert len(raw)<=M
 with (P/'full-sorted-inventory.json').open('xb') as f:f.write(raw)
 built=[archive('targets',targets,36*M),archive('unit-fixture',unit,2*M)];save('archiver-stream-result.json',built)
 assert time.time()<CUT-15
 with (R/'verifier.stdout').open('xb') as out,(R/'verifier.stderr').open('xb') as err:
  p=subprocess.Popen([sys.executable,'-B',str(R/'verify-archives.py')],stdout=out,stderr=err);rc=p.wait(timeout=min(120,max(1,CUT-time.time()-5)))
 assert rc==0,('independent verifier',rc)
 second_targets,second_absent=inventory(TARGETS);second_unit,_=inventory([U]);assert second_targets==targets and second_absent==absent and second_unit==unit
 assert noncase()==original_noncase;after_source=ns['preservation']();after_QN=ns['old_snapshots']();assert after_QN==old;assert sdk()==sdk_before and sha(frozen)=='9ae57af7f16a05aa01d79b0aa88ce90b50f7669858548be6933cfc2d0f1c0def'
 save('after.json',{'utc':now(),'account':account(),'all_original_target_and_unit_inventory_second_pass_match':True,'all_noncase_files_match':True,'source145_core18_tools_private1520_shared1262_pass':True,'preservation':after_source,'old_QN_match':True,'SDK_match':True,'frozen_binary_sha256':sha(frozen),'archives':built,'inventory_bytes':len(raw),'inventory_sha256':sha(P/'full-sorted-inventory.json'),'no_cleanup_restore_engine_Cargo_compiler':True,'original_unit_run_identity':'packing-cache-boundary-52875-1792478528830285000-2'})
 print(json.dumps({'status':'ARCHIVES_CREATED_AND_INDEPENDENTLY_VERIFIED; ALL ORIGINALS RETAINED','archives':built,'inventory_sha256':sha(P/'full-sorted-inventory.json'),'account':account()},indent=2))
def supervisor():
 out=(R/'worker.stdout').open('xb');err=(R/'worker.stderr').open('xb')
 p=subprocess.Popen([sys.executable,'-B',__file__,'--worker'],stdin=subprocess.PIPE,stdout=out,stderr=err,start_new_session=True)
 watch=ns['arm'](p.pid,CUT);peak=None;per=None;samples=0;reason=None
 try:
  p.stdin.write(b'G');p.stdin.flush();p.stdin.close()
  while p.poll() is None:
   rows=ns['ps_tree'](os.getpid());rss=sum(r['rss_bytes'] for r in rows);largest=max(r['rss_bytes'] for r in rows)
   peak=max(peak or 0,rss);per=max(per or 0,largest);samples+=1
   assert rss<=3*1024**3 and largest<=2*1024**3
   assert os.statvfs(O).f_bavail*os.statvfs(O).f_frsize>20*1024**3
   time.sleep(.1)
  p.wait(timeout=2);assert p.returncode==0,('worker',p.returncode)
 except BaseException as e:reason=type(e).__name__+': '+str(e);ns['kill_group'](p.pid);p.wait(timeout=3)
 finally:
  if ns['group_present'](p.pid):ns['kill_group'](p.pid)
  ns['cancel'](watch);out.close();err.close()
  remaining=ns['group_present'](p.pid);save('supervisor-final.json',{'utc':now(),'worker_PGID':p.pid,'worker_exit':p.returncode,'remaining_group':remaining,'reason':reason,'sampled_aggregate_peak_RSS_bytes':peak,'sampled_per_process_peak_RSS_bytes':per,'samples':samples,'missing_RSS_policy':'NULL+stop; no zero','functional_cutoff':'2026-10-20T06:58:00Z','artifact_cutoff':'2026-10-20T07:03:00Z','original_P_cutoff':'2026-10-20T07:55:16Z','original_P_closeout':'2026-10-20T08:25:16Z','no_cleanup':True})
 if reason:raise SystemExit(1)
if __name__=='__main__':
 if '--worker' in sys.argv:worker()
 else:supervisor()

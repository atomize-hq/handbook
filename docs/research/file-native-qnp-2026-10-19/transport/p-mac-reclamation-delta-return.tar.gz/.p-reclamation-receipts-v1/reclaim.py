"""Exact parent-authorized archived-root reclamation; no engine or build."""
import os,sys,time,json,stat,runpy,subprocess,hashlib
from pathlib import Path
O=Path('/private/tmp/file-native-p-macos-20261020');C=O/'cargo-private-proposed';R=C/'.p-reclamation-receipts-v1';P=O/'preservation-build-unit-v6';RP=C/'.p-preservation-receipts-v6'
A=runpy.run_path(str(RP/'archive-stage.py'),run_name='reviewed_definitions_only');N=A['ns'];V=runpy.run_path(str(RP/'verify-archives.py'),run_name='reviewed_verifier_definitions_only')
CUT=1792479801.0  # 2026-10-20 07:03:21 UTC; conservatively within five minutes of receipt.
def sha(p):return A['sha'](p)
def save(name,data):
 raw=(json.dumps(data,indent=2)+'\n').encode();assert len(raw)<1048576
 with (R/name).open('xb') as f:f.write(raw)
def checktime():assert time.time()<CUT,'fixed-reclamation-cutoff'
def canonical(p):
 for q in [p,*p.parents]:assert not q.is_symlink() and q.resolve()==q,('noncanonical',str(q))
def account():
 total=files=0
 for p in A['paths'](O):
  s=p.lstat()
  if stat.S_ISREG(s.st_mode):total+=s.st_size;files+=1
 private=A['footprint'](C);free=os.statvfs(O).f_bavail*os.statvfs(O).f_frsize
 assert total+1572864<=300*1048576 and private<=36*1048576 and free>20*1024**3
 return {'whole_bytes':total,'files':files,'private_bytes':private,'incidental_reserve_bytes':1572864,'free_bytes':free}
def noncase():
 h=hashlib.sha256();count=total=0
 for p in A['paths'](O):
  if p.is_relative_to(R) or p.is_relative_to(A['U']) or any(p.is_relative_to(t) for t in A['TARGETS']):continue
  s=p.lstat()
  if stat.S_ISREG(s.st_mode):
   h.update(str(p.relative_to(O)).encode()+b'\0'+str(s.st_size).encode()+b'\0'+sha(p).encode()+b'\n');count+=1;total+=s.st_size
 return {'files':count,'bytes':total,'path_size_content_sha256':h.hexdigest()}
BIND={P/'targets.tar.gz':'163a4e98adcf372701fa8e68e35046b621439dfc0968251c24d926f3e7b0e8de',P/'unit-fixture.tar.gz':'f86a392c3447d9657600a94f6a02a8229844cc5ba58900fc3e05b8e0cedddcdd',P/'full-sorted-inventory.json':'96ef101fde15c26547a4a8a4f57d8efb5a688b83db7c4a81a263ca5f673c18f7',RP/'archive-stage.py':'38ef76e1cb55b1fe0b432871a327f986cada1acdfc821ee5c2dc3eab0ea4b743',RP/'verify-archives.py':'afb269bb72b07702bad6ac19f6e08f19cb6bc772c37b5a3d7d0f74fca009105b',O/'frozen-bin-private-proposed-v6/file-native-incremental':'9ae57af7f16a05aa01d79b0aa88ce90b50f7669858548be6933cfc2d0f1c0def'}
def bind():
 for p,want in BIND.items():canonical(p);assert sha(p)==want,('binding-drift',str(p))
def quiescent():
 for pgid in [50316,70997]:assert not N['group_present'](pgid),('old-group-live',pgid)
 probe=subprocess.Popen(['/bin/ps','-axo','pid=,ppid=,pgid=,command='],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 out,err=probe.communicate(timeout=10);assert probe.returncode==0
 allowed={os.getpid(),os.getppid(),probe.pid}
 bad=[]
 for line in out.decode().splitlines():
  parts=line.strip().split(None,3)
  if len(parts)==4 and str(O) in parts[3] and int(parts[0]) not in allowed and '--timer' not in parts[3]:bad.append(line)
 assert not bad,('unrecognized-owned-process',bad)
 return {'native_old_groups_empty':True,'unrecognized_owned_processes':bad}
def worker():
 assert sys.stdin.buffer.read(1)==b'G';checktime();bind();q=quiescent()
 inv=json.loads((P/'full-sorted-inventory.json').read_bytes());targets,absent=A['inventory'](A['TARGETS']);unit,ua=A['inventory']([A['U']]);assert targets==inv['targets'] and unit==inv['unit-fixture'] and absent==inv['absent_target_roots'] and not ua
 for root in A['TARGETS']+[A['U']]:canonical(root)
 verification=[V['verify']('targets',targets,36*1048576),V['verify']('unit-fixture',unit,2*1048576)]
 anchors=N['preservation']();qn=N['old_snapshots']();sdk=A['sdk']();nc=noncase();before=account()
 roots=[O/'target-private-proposed',O/'target-private-proposed-v3',O/'target-private-proposed-v4',O/'target-private-proposed-v6',A['U']]
 assert [str(t) for t in A['TARGETS'] if not t.exists()]==absent
 save('before.json',{'utc':N['utc'](),'inventory_exact_match':True,'quiescence':q,'account':before,'archive_manual_verification':verification,'preservation':anchors,'old_QN':qn,'SDK':sdk,'noncase':nc,'exact_roots':list(map(str,roots))})
 # Rebind the entire original inventory immediately before first unlink.
 assert A['inventory'](A['TARGETS'])==(targets,absent) and A['inventory']([A['U']])==(unit,[]);bind();quiescent();checktime()
 deleted=deletedfiles=0
 for root in roots:
  checktime();rows=[r for r in targets+unit if (O/r['path']).is_relative_to(root)]
  for r in sorted(rows,key=lambda r:(r['path'].count('/'),r['path']),reverse=True):
   checktime();p=O/r['path'];canonical(p);s=p.lstat()
   assert s.st_dev==r['device'] and s.st_ino==r['inode'] and stat.S_IMODE(s.st_mode)==r['mode']
   if r['type']=='regular':
    assert stat.S_ISREG(s.st_mode) and s.st_size==r['bytes'] and s.st_mtime_ns==r['mtime_ns'] and sha(p)==r['sha256']
    # nlink can decrease after removing another archived link to this same inode.
    assert 1<=s.st_nlink<=r['nlink'];p.unlink();deleted+=r['bytes'];deletedfiles+=1
   else:assert stat.S_ISDIR(s.st_mode);p.rmdir()
  assert not root.exists()
 assert deleted==170118292 and deletedfiles==464
 bind();assert noncase()==nc;assert N['old_snapshots']()==qn and A['sdk']()==sdk;afteranchors=N['preservation']();after=account();assert all(not r.exists() for r in A['TARGETS']+[A['U']])
 forecast=after['whole_bytes']+1572864+(192+16+4)*1048576
 save('after.json',{'utc':N['utc'](),'status':'EXACT_RECLAMATION_COMPLETE','actual_deleted_regular_bytes':deleted,'actual_deleted_regular_files':deletedfiles,'all_exact_roots_absent':True,'all_archives_and_code_and_binary_bindings_match':True,'all_noncase_content_match':True,'old_QN_SDK_match':True,'preservation':afteranchors,'account':after,'future_full_forecast_bytes_including_incidental':forecast,'future_full_forecast_files':after['files']+25000,'fits_288MiB_30000files':forecast<=288*1048576 and after['files']+25000<=30000,'engine_started':False})
 print((R/'after.json').read_text())
def supervisor():
 out=(R/'worker.stdout').open('xb');err=(R/'worker.stderr').open('xb');p=subprocess.Popen([sys.executable,'-B',__file__,'--worker'],stdin=subprocess.PIPE,stdout=out,stderr=err,start_new_session=True);watch=N['arm'](p.pid,min(CUT,time.time()+120));peak=per=None;samples=0;reason=None
 try:
  p.stdin.write(b'G');p.stdin.close()
  while p.poll() is None:
   rows=N['ps_tree'](os.getpid());assert rows,'missing-native-RSS';total=sum(x['rss_bytes'] for x in rows);largest=max(x['rss_bytes'] for x in rows);peak=max(peak or 0,total);per=max(per or 0,largest);samples+=1;assert total<=3*1024**3 and largest<=2*1024**3;assert os.statvfs(O).f_bavail*os.statvfs(O).f_frsize>20*1024**3;time.sleep(.1)
  assert p.returncode==0,('worker-exit',p.returncode)
 except BaseException as e:reason=repr(e);N['kill_group'](p.pid);p.wait(timeout=3)
 finally:
  if N['group_present'](p.pid):N['kill_group'](p.pid)
  N['cancel'](watch);out.close();err.close();remaining=N['group_present'](p.pid);save('supervisor-final.json',{'utc':N['utc'](),'worker_PGID':p.pid,'worker_exit':p.returncode,'reason':reason,'remaining_group':remaining,'aggregate_peak_RSS':peak,'per_process_peak_RSS':per,'samples':samples,'missing_RSS':None if samples==0 else 0,'cutoff_epoch':CUT})
 if reason:raise SystemExit(1)
if __name__=='__main__':worker() if '--worker' in sys.argv else supervisor()

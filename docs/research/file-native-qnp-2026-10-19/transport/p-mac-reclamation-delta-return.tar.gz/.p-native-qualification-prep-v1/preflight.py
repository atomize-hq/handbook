"""Read-only admission report. This preparation has no execution entry point."""
import hashlib, json, os, stat, time
from pathlib import Path
Q=Path(__file__).resolve().parent
ROOT=Q.parent.parent
EXE=ROOT/'frozen-bin-private-proposed-v6/file-native-incremental'
LIB=Path('/opt/homebrew/Cellar/zstd/1.5.7_1/lib/libzstd.1.5.7.dylib')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def census(p):
 total=count=0
 for base,dirs,names in os.walk(p,followlinks=False,onerror=lambda e:(_ for _ in ()).throw(e)):
  for name in dirs+names:
   path=Path(base)/name
   s=path.lstat()
   if stat.S_ISLNK(s.st_mode):raise RuntimeError('alias:'+str(path))
   if name in names:
    if not stat.S_ISREG(s.st_mode):raise RuntimeError('nonregular:'+str(path))
    total+=s.st_size;count+=1
 return {'bytes':total,'files':count}
def main():
 cfg=json.loads((Q/'config-proposal.json').read_text())
 bindings={str(p):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in (EXE,LIB,ROOT/'p-candidate-d70f-source-manifest.json',Q/'linux-source-transport.tar.gz')}
 for p,want in cfg['expected_bindings'].items():
  if bindings[p]['sha256']!=want:raise RuntimeError('binding-drift:'+p)
 actual=census(ROOT);private=census(Q.parent);prep=census(Q)
 future_bytes=sum(cfg['future_budgets_bytes'].values());future_files=cfg['fixture_files']
 report={'observed_epoch':time.time(),'read_only':True,'execution_implemented':False,'execution_authorized':False,'bindings':bindings,'actual_whole':actual,'actual_private':private,'actual_preparation':prep,'future_reservations_bytes':future_bytes,'admission_using_actual_retained_baseline':{'bytes':actual['bytes']+future_bytes,'files':actual['files']+future_files,'byte_bound':cfg['whole_bytes'],'file_bound':cfg['whole_files'],'fits':actual['bytes']+future_bytes<=cfg['whole_bytes'] and actual['files']+future_files<=cfg['whole_files']},'reclaimed_bytes_assumed':0,'remaining_review_gaps':cfg['remaining_review_gaps']}
 print(json.dumps(report,indent=2))
if __name__=='__main__':main()

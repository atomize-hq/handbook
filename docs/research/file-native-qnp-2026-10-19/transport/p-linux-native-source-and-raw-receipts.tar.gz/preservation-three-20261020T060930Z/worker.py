
import os,sys,time,json,gzip,tarfile,hashlib,stat
from pathlib import Path
ROOT=Path('/home/spenser/file-native-p-linux-20261020');R=ROOT/'preservation-three-20261020T060930Z';C=json.loads((R/'config.json').read_text());CUT=1792477290
targets=[('final-qualification-fixtures',ROOT/'final-qualification/fixtures'),('recovery-bootstrap-fixture',ROOT/'recovery-only-20261020T054348Z/fixture'),('recovery-complete-fixture',ROOT/'recovery-only-20261020T054348Z/fixture-complete')]
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(65536),b''):h.update(b)
 return h.hexdigest()
def census(p):
 b=f=0
 for base,ds,ns in os.walk(p,followlinks=False):
  for name in ns:q=Path(base)/name;b+=q.lstat().st_size;f+=1
 return {'bytes':b,'files':f}
def check():
 assert time.time()<CUT
 assert os.statvfs(ROOT).f_bavail*os.statvfs(ROOT).f_frsize>=21474836480
 assert C['combined_before_bytes']+sum(p.stat().st_size for p in R.iterdir() if p.is_file())<297795584
 assert sum(p.stat().st_size for p in R.iterdir() if p.is_file() and p.name not in ['three-roots.tar.gz','inventory.jsonl'])+C['controller_stage_bound']<2097152
def inventory():
 rows=[]
 for label,root in targets:
  assert root.resolve(strict=True)==root and root.is_dir() and not root.is_symlink()
  for p in [root]+sorted(root.rglob('*')):
   st=p.lstat();assert not stat.S_ISLNK(st.st_mode) and (stat.S_ISREG(st.st_mode) or stat.S_ISDIR(st.st_mode))
   rows.append({'path':label+('/'+p.relative_to(root).as_posix() if p!=root else ''),'type':'directory' if p.is_dir() else 'file','bytes':st.st_size if p.is_file() else 0,'sha256':sha(p) if p.is_file() else None})
 rows.sort(key=lambda x:x['path']);assert len({x['path'] for x in rows})==len(rows);return rows
def protection():
 rows=[]
 for base,ds,ns in os.walk(ROOT,followlinks=False):
  b=Path(base);ds[:]=[d for d in ds if b/d!=R and all(b/d!=t for _,t in targets)]
  for name in ns:
   p=b/name;assert not p.is_symlink();rows.append([str(p.relative_to(ROOT)),p.stat().st_size,sha(p)])
 return sorted(rows)
def bindings():
 m=json.loads((ROOT/'final-source-stage/source-manifest.json').read_text());assert len(m['files'])==145 and len(m['final_core_files'])==18
 for x in m['files']:
  b=(ROOT/'source-final'/x['path']).read_bytes();assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256'] and hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==x['git_blob_sha1']
 old=json.loads((ROOT/'preparation/source-manifest.json').read_text())
 for x in old['files']:p=ROOT/'source'/x['path'];assert p.stat().st_size==x['bytes'] and sha(p)==x['sha256']
 bins={name:sha(ROOT/'bin'/name) for name in ['candidate-linux','candidate-linux-final']};assert list(bins.values())==['063342e6bbd6bfb49729ff856462b9fdaa4a8d7cdf51d941d2a60f356d2c0cbe','a8501737ca4fdd5cfc177620860c1ae103d56f2e9b2151104a922df511a3d84b']
 qn=[]
 for name in ['file-native-n-linux-20261019','file-native-q-linux-20261019-final']:
  p=Path('/home/spenser')/name;mm=json.loads((p/'source-manifest.json').read_text());files=mm.get('files',mm)
  for rel,x in files.items():q=p/'source'/rel;assert q.stat().st_size==x['bytes'] and sha(q)==x['sha256']
  qn.append({'root':str(p),'source_files':len(files),'match':True})
 return {'final_source145_core18_match':True,'old_source139_match':True,'frozen_bins':bins,'protected_QN_sources':qn}
check();before=bindings();protected=protection();data=gzip.compress(json.dumps(protected,separators=(',',':')).encode(),mtime=0);assert len(data)<300000;(R/'protected-before.json.gz').write_bytes(data)
rows=inventory();raw=b''.join((json.dumps(x,separators=(',',':'))+'\n').encode() for x in rows);assert len(raw)<=8388608;check();(R/'inventory.jsonl').write_bytes(raw)
class Limited:
 def __init__(self,p):self.f=p.open('xb');self.n=0
 def write(self,b):
  if self.n+len(b)>16777216-65536:raise RuntimeError('compressed-archive-soft-stop')
  check();n=self.f.write(b);self.n+=n;return n
 def flush(self):self.f.flush()
limited=Limited(R/'three-roots.tar.gz')
with gzip.GzipFile(fileobj=limited,mode='wb',compresslevel=6,mtime=0) as gz:
 with tarfile.open(fileobj=gz,mode='w|',format=tarfile.GNU_FORMAT) as tar:
  for x in rows:
   label,_,rel=x['path'].partition('/');root=dict(targets)[label];p=root/rel if rel else root;info=tarfile.TarInfo(x['path']);info.mode=0o755 if x['type']=='directory' else 0o644;info.mtime=0
   if x['type']=='directory':info.type=tarfile.DIRTYPE;tar.addfile(info)
   else:
    info.size=x['bytes']
    with p.open('rb') as f:tar.addfile(info,f)
limited.f.flush();os.fsync(limited.f.fileno());limited.f.close();check()
verified=0;logical=0;trailing=0
with (R/'three-roots.tar.gz').open('rb') as archive:
 with gzip.GzipFile(fileobj=archive,mode='rb') as gz:
  with tarfile.open(fileobj=gz,mode='r|') as tar:
   for member in tar:
    assert verified<len(rows);x=rows[verified];assert member.name.rstrip('/')==x['path'] and member.size==x['bytes']
    if x['type']=='directory':assert member.isdir()
    else:
     assert member.isfile();h=hashlib.sha256();n=0
     with tar.extractfile(member) as f:
      for b in iter(lambda:f.read(65536),b''):h.update(b);n+=len(b)
     assert n==x['bytes'] and h.hexdigest()==x['sha256'];logical+=n
    verified+=1
  while True:
   b=gz.read(65536)
   if not b:break
   assert not b.strip(b'\0');trailing+=len(b)
  assert archive.tell()==(R/'three-roots.tar.gz').stat().st_size
assert verified==len(rows) and inventory()==rows and protection()==protected and bindings()==before;check()
roots=[]
for label,p in targets:
 rr=[x for x in rows if x['path']==label or x['path'].startswith(label+'/')];roots.append({'label':label,'canonical_root':str(p),'files':sum(x['type']=='file' for x in rr),'directories':sum(x['type']=='directory' for x in rr),'logical_bytes':sum(x['bytes'] for x in rr)})
out={'epoch':time.time(),'status':'ARCHIVED_STREAM_VERIFIED_ORIGINALS_PRESERVED_NO_DELETION','roots':roots,'inventory':{'path':str(R/'inventory.jsonl'),'bytes':len(raw),'sha256':sha(R/'inventory.jsonl'),'rows':len(rows),'format':'sorted UTF-8 JSONL; explicit directories; bytes and SHA256 for each regular file'},'archive':{'path':str(R/'three-roots.tar.gz'),'bytes':(R/'three-roots.tar.gz').stat().st_size,'sha256':sha(R/'three-roots.tar.gz'),'members_verified':verified,'logical_bytes_verified':logical,'stream_EOF_CRC_verified':True,'post_tar_zero_padding_drained_bytes':trailing},'originals_full_inventory_rechecked_equal':True,'protected_all_noncase_native_files_unchanged':True,'protected_file_count':len(protected),'bindings':before,'native_actual':census(ROOT),'clocks':{'stage_start_epoch':1792476570,'functional_cutoff_epoch':CUT,'closeout_deadline_epoch':1792477590},'no_deletion_or_restore_or_engine_build_Cargo':True,'cleanup_authorized':False};(R/'manifest.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))

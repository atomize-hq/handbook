
import os,sys,subprocess,time,json,threading,signal
from pathlib import Path
R=Path('/home/spenser/file-native-p-linux-20261020/preservation-three-20261020T060930Z');CUT=1792477290;start=time.monotonic();p=subprocess.Popen([sys.executable,'-B',str(R/'worker.py')],stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);peak=None;missing=0;violations=[];stop=threading.Event();samples=0
def kill(reason):
 if reason not in violations:violations.append(reason)
 try:os.killpg(p.pid,signal.SIGKILL)
 except ProcessLookupError:pass
timer=threading.Timer(min(900,max(.01,CUT-time.time())),lambda:kill('independent-whole-group-timeout'));timer.daemon=True;timer.start()
def monitor():
 global peak,missing,samples
 while not stop.is_set():
  rss=[];worker_rss=None
  for q in Path('/proc').iterdir():
   if not q.name.isdigit():continue
   try:
    s=(q/'stat').read_text();r=s[s.rfind(')')+2:].split();pid=int(q.name)
    if r[0]!='Z' and (int(r[2])==p.pid or pid==os.getpid()):
     n=int(r[21])*os.sysconf('SC_PAGE_SIZE');rss.append(n)
     if pid==p.pid:worker_rss=n
   except (OSError,ValueError,IndexError):pass
  value=sum(rss) if worker_rss is not None else None;samples+=1
  if value is None:missing+=1
  else:
   peak=value if peak is None else max(peak,value)
   if value>3221225472:kill('native-aggregate3GiB')
  if worker_rss is not None and worker_rss>2147483648:kill('checker2GiB')
  stop.wait(.1)
t=threading.Thread(target=monitor,daemon=True);t.start();out,err=p.communicate();stop.set();t.join(2);timer.cancel();remaining=[]
for q in Path('/proc').iterdir():
 if not q.name.isdigit():continue
 try:
  s=(q/'stat').read_text();r=s[s.rfind(')')+2:].split()
  if int(r[2])==p.pid and r[0]!='Z':remaining.append(int(q.name))
 except (OSError,ValueError,IndexError):pass
result={'epoch':time.time(),'exit':p.returncode,'seconds':time.monotonic()-start,'worker_stdout':out.decode(),'worker_stderr':err.decode(),'resource':{'observed_aggregate_RSS_peak_bytes':peak,'exact_continuous_peak_bytes':None,'missing_samples':missing,'missing_sample_value':None,'samples':samples,'violations':violations,'remaining_live_pids':remaining,'timer_independent_of_worker_and_census':True,'whole_seconds_limit':min(900,max(.01,CUT-(time.time()-(time.monotonic()-start))))}};assert len(json.dumps(result).encode())<30000;(R/'supervisor.json').write_text(json.dumps(result,indent=2));print(json.dumps(result));assert p.returncode==0 and not violations and not remaining


import os,sys,json,time,hashlib,shutil,stat
from pathlib import Path
ROOT=Path('/home/spenser/file-native-p-linux-20261020');R=ROOT/'final-qualification';assert R.is_dir() and not (R/'cleanup-intent.json').exists();Q=ROOT/'qualification';S=ROOT/'source-final';sys.path.insert(0,str(Q));import native_control_tiny as n
M=json.loads((ROOT/'final-source-stage/source-manifest.json').read_text())
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def check():
 for x in M['files']:
  b=(S/x['path']).read_bytes();assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256'] and hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==x['git_blob_sha1']
 assert digest(ROOT/'bin/candidate-linux-final')=='a8501737ca4fdd5cfc177620860c1ae103d56f2e9b2151104a922df511a3d84b';assert n.sourcecheck()['exe_sha256']=='063342e6bbd6bfb49729ff856462b9fdaa4a8d7cdf51d941d2a60f356d2c0cbe'
check();mapping=json.loads((ROOT/'final-source-stage/unit-fixture-remap-proposal.json').read_text());archive=ROOT/'preservation-artifact/two-roots.tar.gz';inventory=ROOT/'preservation-artifact/inventory.jsonl';assert digest(archive)=='d6f3eca1abd4bb74ca393c9c3ef743abdf5c6061bb98aad74ac938769c2cdbc7' and digest(inventory)=='1cf2e7bb0116495dfd0b883bf62916bd8701be60db9305eec5ff62ffc4b27ad9';base={x['p']:x for x in [json.loads(line) for line in inventory.read_text().splitlines()]};targets=[Path('/home/spenser/file-native-p-linux-20261020/target-final'),Path('/home/spenser/file-native-p-linux-20261020/source-final/docs/research/file-native-incremental-engine-experiment-2026-10-18/target')];before=[]
for p in targets:
 assert p.is_dir() and p.resolve()==p and p.is_relative_to(ROOT)
 for part in [p,*p.parents]:assert not part.is_symlink()
 assert not any(x.is_symlink() for x in p.rglob('*'));before.append(n.census(p))
assert (before[0]['bytes'],before[0]['files'])==(129336661,434) and (before[1]['bytes'],before[1]['files'])==(80976318,8);actual={str(p) for p in targets[1].rglob('*') if p.is_file()};assert actual=={x['new_path'] for x in mapping['path_mapping']}
for x in mapping['path_mapping']:
 p=Path(x['new_path']);old=base[x['existing_archive_member']];assert p.stat().st_size==x['bytes']==old['n'] and digest(p)==x['sha256']==old['h']
intent={'epoch':time.time(),'stage_start_epoch':1792472565,'functional_deadline_epoch':1792474665,'closeout_deadline_epoch':1792474965,'targets':before,'unit_fixture_complete8mapping_rechecked':True,'source145_core18_old139_bothbins_verified':True,'archive_sha256':digest(archive),'inventory_sha256':digest(inventory),'mapping_sha256':digest(ROOT/'final-source-stage/unit-fixture-remap-proposal.json'),'no_other_cleanup_authorized':True};(R/'cleanup-intent.json').write_text(json.dumps(intent,indent=2))
for p in [Path('/home/spenser/file-native-p-linux-20261020/target-final'),Path('/home/spenser/file-native-p-linux-20261020/source-final/docs/research/file-native-incremental-engine-experiment-2026-10-18/target')]:
 assert p.resolve()==p and not p.is_symlink() and p.is_relative_to(ROOT);shutil.rmtree(p);assert not p.exists()
check();assert digest(archive)==intent['archive_sha256'] and digest(inventory)==intent['inventory_sha256'];result={'epoch':time.time(),'status':'FINAL_TARGET_AND_MAPPED_UNIT_FIXTURE_RECLAIMED','actual_successfully_deleted_bytes':210312979,'actual_successfully_deleted_files':442,'targets':[{**x,'absent':not Path(x['root']).exists()} for x in before],'both_targets_absent':True,'new_unit_results_remain_separate':True,'new_unit_bytes_preserved_in_existing_archive_by_explicit_mapping':mapping,'new_and_old_source_bin_archive_preserved':True,'native_ownership':n.ownership(),'stage_start_epoch':1792472565,'functional_deadline_epoch':1792474665,'closeout_deadline_epoch':1792474965};(R/'cleanup-result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))

import os,sys,json,time,hashlib,gzip,subprocess,threading,signal,contextlib,fcntl,shutil
from pathlib import Path
ROOT=Path('/home/spenser/file-native-p-linux-20261020');R=ROOT/'final-qualification';F=R/'fixtures';CFG=json.loads((R/'config.json').read_text());CUTOFF=CFG['functional_cutoff_epoch'];EXE=ROOT/'bin/candidate-linux-final';LIB=Path('/usr/lib/libzstd.so.1.5.7');EXPECTED=CFG['exe_sha256'];local=threading.local();lock=threading.RLock();reservations={};counter=0
class Refused(RuntimeError):pass
def census(p):
 p=Path(p);bs=fs=0
 if not p.exists():return {'bytes':0,'files':0}
 for b,ds,ns in os.walk(p,followlinks=False):
  for name in ns:
   q=Path(b)/name
   try:
    if q.is_symlink():raise Refused('symlink-in-owned-census:'+str(q))
    bs+=q.stat().st_size;fs+=1
   except FileNotFoundError:pass
 return {'bytes':bs,'files':fs}
def report_path(p):
 try:rel=Path(p).relative_to(R)
 except ValueError:return False
 if not rel.parts or rel.parts[0]!='fixtures':return True
 name=Path(p).name
 return name in ['events.json','events.json.gz','cases.json','summary.json','route.json','result.json'] or 'independent' in name or name.endswith('.stdout') or name.endswith('.stderr') or (name.endswith('.jsonl') and '/disposable/' not in str(p))
def report_files_fast():
 found=set()
 for b,ds,ns in os.walk(R):
  if Path(b)==R:ds[:]=[d for d in ds if d!='fixtures']
  for name in ns:
   p=Path(b)/name
   if report_path(p):found.add(p)
 if F.exists():
  for b,ds,ns in os.walk(F):
   ds[:]=[d for d in ds if d!='disposable']
   for name in ns:
    p=Path(b)/name
    if report_path(p):found.add(p)
 return found
def report_bytes():
 total=0
 for p in report_files_fast():
  try:total+=p.stat().st_size
  except FileNotFoundError:pass
 return total
def ownership():
 x=census(ROOT);f=census(F);return {'native':x,'fixtures':f,'combined_bound_bytes':x['bytes']+CFG['cache_growth_bytes']+CFG['controller_shared_future_bound_bytes'],'combined_bound_files':x['files']+CFG['cache_new_files']+CFG['controller_file_future_bound'],'free_bytes':os.statvfs(ROOT).f_bavail*os.statvfs(ROOT).f_frsize,'native_report_bytes':report_bytes()}
def compact_live_ledgers_locked():
 # These are mutable compressed transports. Preserve exact decompressed JSONL bytes,
 # every row and EOF; no original search log or fixture file is touched.
 import io
 for name in ['rss-samples.jsonl.gz','raw-process-events.jsonl.gz','operation-forecasts.jsonl.gz']:
  p=R/name
  if not p.exists() or p.stat().st_size<32768:continue
  class Sink:
   def __init__(self):self.n=0
   def write(self,b):self.n+=len(b);return len(b)
   def flush(self):pass
  sink=Sink();rawhash=hashlib.sha256();rawbytes=0;rows=0
  with gzip.open(p,'rb') as src,gzip.GzipFile(filename='',mode='wb',fileobj=sink,compresslevel=6,mtime=0) as dst:
   for b in iter(lambda:src.read(65536),b''):rawhash.update(b);rawbytes+=len(b);rows+=b.count(b'\n');dst.write(b)
  oldsize=p.stat().st_size
  if sink.n+4096>=oldsize:continue
  if report_bytes()+sink.n+8192>CFG['reports_cap_bytes']-CFG['controller_future_reports_reserve']:continue
  oldcompressed=hashlib.sha256(p.read_bytes()).hexdigest();tmp=p.with_name(p.name+'.reencoding')
  with tmp.open('xb') as file,gzip.GzipFile(filename='',mode='wb',fileobj=file,compresslevel=6,mtime=0) as dst,gzip.open(p,'rb') as src:
   for b in iter(lambda:src.read(65536),b''):dst.write(b)
  assert tmp.stat().st_size==sink.n;h=hashlib.sha256();n=0
  with gzip.open(tmp,'rb') as f:
   for b in iter(lambda:f.read(65536),b''):h.update(b);n+=len(b)
  assert n==rawbytes and h.hexdigest()==rawhash.hexdigest()
  newcompressed=hashlib.sha256(tmp.read_bytes()).hexdigest();os.replace(tmp,p)
  record={'epoch':time.time(),'path':str(p),'old_compressed_sha256':oldcompressed,'new_compressed_sha256':newcompressed,'old_compressed_bytes':oldsize,'new_compressed_bytes':sink.n,'exact_decompressed_bytes':rawbytes,'decompressed_sha256':rawhash.hexdigest(),'all_JSONL_rows_and_EOF_preserved':True,'original_search_logs_untouched':True}
  data=(json.dumps(record,separators=(',',':'))+'\n').encode()
  with (R/'compressed-transport-reencodings.jsonl').open('ab') as f:f.write(data)
def append_record(file,row,emergency=False):
 data=gzip.compress((json.dumps(row,separators=(',',':'))+'\n').encode(),compresslevel=5,mtime=0)
 with (R/'.append.lock').open('ab') as lk:
  fcntl.flock(lk,fcntl.LOCK_EX)
  
  if report_bytes()>1179648:compact_live_ledgers_locked()
  maximum=CFG['reports_cap_bytes']-CFG['controller_future_reports_reserve']-(0 if emergency else 131072)
  if report_bytes()+len(data)>maximum:raise Refused('raw-report-prewrite-bound')
  with Path(file).open('ab') as f:f.write(data)
  fcntl.flock(lk,fcntl.LOCK_UN)
@contextlib.contextmanager
def reserve(bs,files,name,covered=False):
 if getattr(local,'covered',0):yield;return
 global counter
 with lock:
  x=ownership();rb=sum(v[0] for v in reservations.values());rf=sum(v[1] for v in reservations.values())
  if x['combined_bound_bytes']+rb+bs+131072>CFG['lane_cap_bytes']:raise Refused('whole-operation-total:'+name)
  if x['fixtures']['bytes']+rb+bs>CFG['fixture_cap_bytes']:raise Refused('whole-operation-fixtures:'+name)
  if x['combined_bound_files']+rf+files+20>CFG['lane_files_cap']:raise Refused('whole-operation-files:'+name)
  if x['free_bytes']<CFG['minimum_native_free_bytes']:raise Refused('native-free-floor')
  counter+=1;key=(os.getpid(),counter);reservations[key]=(bs,files)
  append_record(R/'operation-forecasts.jsonl.gz',{'epoch':time.time(),'name':name,'max_new_bytes':bs,'max_new_files':files,'existing':x,'other_reserved_bytes':rb})
 if covered:local.covered=getattr(local,'covered',0)+1
 try:yield
 finally:
  if covered:local.covered-=1
  with lock:reservations.pop(key,None)
def engine_forecast(root,action,fields):
 x=census(root)
 if action in ['resolve','point','inspect','lookup-bench','dump','audit'] or (action=='packing' and fields.get('operation')=='status'):return 65536,32
 if action=='init':return (8388608,1024) if fields.get('count',16)>16 else (2097152,256)
 if action=='packing':return 3*x['bytes']+1048576,512
 return 2*x['bytes']+1048576,768
def run(argv,seconds,name,input=None,env=None,limit=2147483648,disk=False):
 global counter
 if time.time()>=CUTOFF:raise Refused('fixed-functional-cutoff')
 with lock:counter+=1;ident=f'{name}-{os.getpid()}-{counter}'
 process=R/'process';process.mkdir(exist_ok=True);guardfile=process/(ident+'.guard.json');begin=time.monotonic();p=subprocess.Popen(list(map(str,argv)),stdin=subprocess.PIPE if input is not None else subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,start_new_session=True)
 g=subprocess.Popen([sys.executable,'-B',str(R/'watchdog-v2.py'),str(p.pid),str(os.getpid()),str(min(seconds,max(.01,CUTOFF-time.time()))),str(limit),str(guardfile),str(int(disk))],start_new_session=True)
 try:out,err=p.communicate(input,timeout=min(seconds+4,max(.01,CUTOFF-time.time()+4)))
 except subprocess.TimeoutExpired:
  try:os.killpg(p.pid,signal.SIGKILL)
  except ProcessLookupError:pass
  out,err=p.communicate(timeout=3)
 g.wait(timeout=6);guard=json.loads(guardfile.read_text());row={'epoch':time.time(),'name':name,'argv':list(map(str,argv)),'exit':p.returncode,'seconds':time.monotonic()-begin,'guard_path':str(guardfile),'input':input.decode() if input is not None else None,'stdout':out.decode(errors='strict'),'stderr':err.decode(errors='strict'),'stdout_sha256':hashlib.sha256(out).hexdigest(),'stderr_sha256':hashlib.sha256(err).hexdigest()};append_record(R/'raw-process-events.jsonl.gz',row)
 if guard['violations'] or guard['remaining_live_pids']:raise Refused('guard-failed:'+name+':'+repr(guard['violations']))
 return subprocess.CompletedProcess(argv,p.returncode,out,err),{'seconds':row['seconds'],'guard':guard,'name':name}
def sourcecheck():
 m=json.loads((ROOT/'final-source-stage/source-manifest.json').read_text());assert m['core_commit']==CFG['core'];assert len(m['files'])==145 and len(m['final_core_files'])==18
 for row in m['files']:
  b=(ROOT/'source-final'/row['path']).read_bytes();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'] and hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==row['git_blob_sha1']
 assert hashlib.sha256(EXE.read_bytes()).hexdigest()==EXPECTED
 return {'core':m['core_commit'],'all145_and18_match':True,'exe_sha256':EXPECTED,'manifest_sha256':hashlib.sha256((ROOT/'final-source-stage/source-manifest.json').read_bytes()).hexdigest()}
def write_report(p,data):
 if isinstance(data,str):data=data.encode()
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);packed=gzip.compress(data,compresslevel=5,mtime=0);dest=p.with_name(p.name+'.gz');tmp=dest.with_name(dest.name+'.writing')
 with lock:
  if report_bytes()+len(packed)+131072>CFG['reports_cap_bytes']-CFG['controller_future_reports_reserve']:raise Refused('case-report-prewrite-bound')
  with tmp.open('wb') as f:f.write(packed)
  os.replace(tmp,dest)
 return len(data)
# External I/O adapters: exact original event JSON bytes are stored losslessly as .json.gz.
_original_text=Path.write_text;_original_bytes=Path.write_bytes

def bounded_text(self,data,*args,**kw):
 if self.name=='events.json' and self.is_relative_to(F):return write_report(self,data)
 if self.is_relative_to(F):
  encoded=data.encode(kw.get('encoding') or 'utf-8')
  with reserve(len(encoded)+65536,4,'write_text:'+self.name):return _original_text(self,data,*args,**kw)
 return _original_text(self,data,*args,**kw)
def bounded_bytes(self,data):
 if self.is_relative_to(F):
  with reserve(len(data)+65536,4,'write_bytes:'+self.name):return _original_bytes(self,data)
 return _original_bytes(self,data)
Path.write_text=bounded_text;Path.write_bytes=bounded_bytes
_copytree=shutil.copytree;_copyfile=shutil.copyfile

def copytree(src,dst,*args,**kw):
 if getattr(local,'covered',0):return _copytree(src,dst,*args,**kw)
 x=census(src)
 with reserve(2*x['bytes']+65536,2*x['files']+32,'copytree:'+str(dst),covered=True):return _copytree(src,dst,*args,**kw)
def copyfile(src,dst,*args,**kw):
 if getattr(local,'covered',0):return _copyfile(src,dst,*args,**kw)
 with reserve(Path(src).stat().st_size+65536,4,'copyfile:'+str(dst),covered=True):return _copyfile(src,dst,*args,**kw)
shutil.copytree=copytree;shutil.copyfile=copyfile

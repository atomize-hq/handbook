import os,sys,time,json,signal
from pathlib import Path
pid=int(sys.argv[1]);supervisor=int(sys.argv[2]);seconds=float(sys.argv[3]);limit=int(sys.argv[4]);output=Path(sys.argv[5]);deadline=time.monotonic()+seconds;known={};groups={pid};samples=[];bad=[];peak=None;missing=0
while True:
 table={}
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   st=(p/'stat').read_text();r=st[st.rfind(')')+2:].split();table[int(p.name)]={'state':r[0],'ppid':int(r[1]),'pgrp':int(r[2]),'start':int(r[19]),'rss':int(r[21])*os.sysconf('SC_PAGE_SIZE')}
  except (OSError,ValueError,IndexError):pass
 owned={p for p,v in table.items() if v['pgrp'] in groups or p==pid or (p in known and known[p]==v['start'])}
 changed=True
 while changed:
  new={p for p,v in table.items() if v['ppid'] in owned};changed=not new<=owned;owned|=new
 for p in owned:known[p]=table[p]['start'];groups.add(table[p]['pgrp'])
 live={p for p in owned if table[p]['state']!='Z'}
 aggregate_ids=live|({supervisor,os.getpid()}&table.keys());agg=sum(table[p]['rss'] for p in aggregate_ids);val=agg if live and agg>0 else None
 if val is None:missing+=1
 else:peak=val if peak is None else max(peak,val)
 samples.append({'epoch':time.time(),'native_aggregate_rss_bytes':val,'live_owned_pids':sorted(live)})
 if not live:break
 if time.monotonic()>=deadline:bad.append('preemptive-whole-group-timeout')
 if val is not None and val>3*1024**3:bad.append('native-aggregate3GiB')
 if any(table[p]['rss']>limit for p in live):bad.append('per-process-RSS-limit')
 if os.statvfs('/home/spenser').f_bavail*os.statvfs('/home/spenser').f_frsize<20*1024**3:bad.append('native-free20GiB')
 root_live=pid in live
 if bad or not root_live:
  for pg in groups:
   if pg==os.getpgrp():continue
   try:os.killpg(pg,signal.SIGKILL)
   except ProcessLookupError:pass
  if bad:break
  if not root_live:break
 time.sleep(.05)
time.sleep(.05);remaining=[]
for p in known:
 try:
  st=Path(f'/proc/{p}/stat').read_text();r=st[st.rfind(')')+2:].split()
  if int(r[19])==known[p] and r[0]!='Z':remaining.append(p)
 except (OSError,ValueError,IndexError):pass
output.write_text(json.dumps({'root_pid':pid,'supervisor_pid':supervisor,'watchdog_pid':os.getpid(),'seconds_limit':seconds,'per_process_limit_bytes':limit,'native_aggregate_limit_bytes':3*1024**3,'observed_native_aggregate_peak_bytes':peak,'missing_samples':missing,'violations':bad,'remaining_live_pids':remaining,'samples':samples,'independent_timer':True,'includes_supervisor_and_watchdog':True},indent=2))

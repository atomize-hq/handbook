import os,sys,json,time,hashlib,stat,subprocess,signal,threading
from pathlib import Path
ROOT=Path('/home/spenser/file-native-p-linux-20261020');Q=ROOT/'qualification';CARGO=Path('/home/spenser/.cargo');CUTOFF=1792471152.;CAP=293601280;CONTROLLER_BOUND=8*1024**2
BASE=json.loads((ROOT/'preparation/cargo-before.json').read_text())
def snap(p):
 out={}
 for base,dirs,files in os.walk(p,followlinks=False):
  for n in files:
   q=Path(base)/n
   try:out[str(q.relative_to(p))]=q.lstat().st_size
   except FileNotFoundError:pass
 return out
def census(p):
 x=snap(p);return {'root':str(p),'bytes':sum(x.values()),'files':len(x)}
def ownership():
 own=census(ROOT);c=snap(CARGO);g=sum(v for k,v in c.items() if k not in BASE)+sum(max(0,v-BASE[k][0]) for k,v in c.items() if k in BASE)
 return {'native':own,'cache_positive_growth_bytes':g,'cache_new_files':sum(k not in BASE for k in c),'conservative_controller_bytes':CONTROLLER_BOUND,'combined_bound_bytes':own['bytes']+g+CONTROLLER_BOUND,'combined_bound_files':own['files']+sum(k not in BASE for k in c)+200,'free_bytes':os.statvfs(ROOT).f_bavail*os.statvfs(ROOT).f_frsize}
def sourcecheck():
 m=json.loads((ROOT/'preparation/source-manifest.json').read_text());rows=[]
 for x in m['files']:
  p=ROOT/'source'/x['path'];b=p.read_bytes();h=hashlib.sha256(b).hexdigest();rows.append({'path':x['path'],'sha256':h,'match':h==x['sha256'] and len(b)==x['bytes']})
 assert len(rows)==139 and all(x['match'] for x in rows)
 exe=ROOT/'bin/candidate-linux';h=hashlib.sha256(exe.read_bytes()).hexdigest();assert h=='063342e6bbd6bfb49729ff856462b9fdaa4a8d7cdf51d941d2a60f356d2c0cbe'
 return {'source139':rows,'exe_sha256':h}
def rss(pid):
 try:
  d={line.split(':')[0]:int(line.split()[1])*1024 for line in Path(f'/proc/{pid}/status').read_text().splitlines() if line.startswith(('VmRSS:','VmHWM:'))};return d['VmRSS'],d['VmHWM']
 except (OSError,ValueError,KeyError):return None
counter=0;lock=threading.Lock()
def run(argv,seconds,name,input=None,env=None,cwd=None,limit=2*1024**3,unit=False):
 global counter
 assert time.time()<CUTOFF
 with lock:counter+=1;ident=f'{name}-{os.getpid()}-{counter}'
 receipts=Q/'process';receipts.mkdir(exist_ok=True);r=receipts/ident
 p=subprocess.Popen(argv,stdin=subprocess.PIPE if input is not None else subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,cwd=cwd,start_new_session=True)
 g=subprocess.Popen([sys.executable,'-B',str(Q/'watchdog.py'),str(p.pid),str(os.getpid()),str(min(seconds,max(.01,CUTOFF-time.time()))),str(limit),str(r.with_suffix('.guard.json'))],start_new_session=True)
 stop=threading.Event();bad=[];samples=[]
 def disk():
  while not stop.is_set():
   try:
    own=ownership();sample={'epoch':time.time(),**own};samples.append(sample)
    if own['combined_bound_bytes']>CAP:bad.append('combined280MiB')
    if own['combined_bound_files']>20000:bad.append('combined20kfiles')
    if own['free_bytes']<20*1024**3:bad.append('nativefree20GiB')
    target=census(ROOT/'target')['bytes']
    if unit and target>123573292+33554432:bad.append('test-target-growth32MiB')
    fixture=ROOT/'source/docs/research/file-native-incremental-engine-experiment-2026-10-18/target'
    if census(fixture)['bytes']>88080384:bad.append('syntheticcache84MiB')
    if census(Q/'fixtures')['bytes']>117440512:bad.append('allfixtures112MiB')
    if bad:
     try:os.killpg(p.pid,signal.SIGKILL)
     except ProcessLookupError:pass
     return
   except Exception as e:bad.append('census:'+repr(e));return
   stop.wait(1)
 monitor=threading.Thread(target=disk,daemon=True);monitor.start();begin=time.monotonic()
 try:out,err=p.communicate(input,timeout=min(seconds+3,max(.01,CUTOFF-time.time()+3)))
 except subprocess.TimeoutExpired:
  bad.append('communicate-fallback-censor')
  try:os.killpg(p.pid,signal.SIGKILL)
  except ProcessLookupError:pass
  out,err=p.communicate(timeout=3)
 finally:stop.set();monitor.join(timeout=4)
 g.wait(timeout=5);guard=json.loads(r.with_suffix('.guard.json').read_text());row={'argv':list(map(str,argv)),'returncode':p.returncode,'seconds':time.monotonic()-begin,'violations':bad,'guard':guard,'ownership_samples':samples,'stdout_sha256':hashlib.sha256(out).hexdigest(),'stderr_sha256':hashlib.sha256(err).hexdigest()};r.with_suffix('.json').write_text(json.dumps(row,indent=2));r.with_suffix('.stdout').write_bytes(out);r.with_suffix('.stderr').write_bytes(err)
 assert not bad and not guard['violations'] and not guard['remaining_live_pids'],row
 return subprocess.CompletedProcess(argv,p.returncode,out,err),row

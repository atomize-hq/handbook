import sys,os,json,hashlib,types,threading,time,ctypes,ctypes.util,subprocess
from pathlib import Path
HERE=Path('/home/spenser/file-native-p-linux-20261020/qualification');sys.path.insert(0,str(HERE));import native_control as n
PACK=n.ROOT/'source/docs/research/file-native-packing-2026-10-20';sys.path.insert(0,str(PACK));os.environ['FILE_NATIVE_P_EXE']=str(n.ROOT/'bin/candidate-linux');os.environ['FILE_NATIVE_P_ROOT']=str(n.ROOT);os.environ['PYTHONDONTWRITEBYTECODE']='1'
shim=types.ModuleType('guard');shim.ROOT=n.ROOT;shim.CUTOFF=n.CUTOFF;shim.rss=n.rss;sys.modules['guard']=shim
import driver
EXE=n.ROOT/'bin/candidate-linux';expected='063342e6bbd6bfb49729ff856462b9fdaa4a8d7cdf51d941d2a60f356d2c0cbe';assert hashlib.sha256(EXE.read_bytes()).hexdigest()==expected
LIB=Path('/usr/lib/libzstd.so.1.5.7');assert hashlib.sha256(LIB.read_bytes()).hexdigest()=='d03364aeedd46783c2f2ae4aae83f728bd1c8d2c5a6e31e5205bd95939f711c7';oldfind=ctypes.util.find_library;ctypes.util.find_library=lambda name:str(LIB) if name=='zstd' else oldfind(name)
def native_call(self,root,action,code=0,env=None,timeout=120,exe_override=None,**fields):
 payload=dict(root=str(root),action=action,**fields);environ={k:v for k,v in os.environ.items() if not k.startswith('EXP_')};environ['EXP_NAVIGATION']='4'
 if env:environ.update(env)
 executable=Path(exe_override) if exe_override else EXE;binding=hashlib.sha256(executable.read_bytes()).hexdigest();assert binding==expected
 limit=256*1024**2 if action in ['resolve','point','inspect','lookup-bench'] else 2*1024**3
 p,res=n.run([str(executable)],min(115,timeout),'engine-'+action,input=json.dumps(payload).encode(),env=environ,limit=limit,disk_monitor=False)
 row=dict(input=payload,exe=str(executable),exe_sha256=binding,env=env,exit=p.returncode,seconds=res['seconds'],stdout=p.stdout.decode(),stderr=p.stderr.decode(),sampled_peak_rss=None,missing_samples=res['guard']['missing_samples'],rss_limit=limit,violations=res['violations']+res['guard']['violations'],native_supervision=res['guard'])
 with self.lock:self.events.append(row);(self.base/'events.json').write_text(json.dumps(self.events,indent=2),encoding='utf-8')
 assert p.returncode==code and not row['violations'],row
 return json.loads(p.stdout) if p.stdout else None
driver.Driver.call=native_call

def run_mode(mode):
 fixtures=n.Q/'fixtures';fixtures.mkdir(exist_ok=True)
 if mode=='capsule':
  import capsule;result=capsule.run(fixtures/'capsule');assert len(result['cases'])==52
  (n.Q/'posix-skips.json').write_text(json.dumps({'skipped':[{'case':'windows-loose-no-delete-sharing-A','reason':'Windows no-delete-sharing semantics; native POSIX host'},{'case':'windows-loose-no-delete-sharing-B','reason':'Windows no-delete-sharing semantics; native POSIX host'}],'not_claimed_pass':True},indent=2))
 elif mode=='strict':
  import strict_supplement;result=strict_supplement.run(fixtures/'capsule',fixtures/'strict');assert len(result['cases'])==24
 elif mode=='loose':
  import loose_regression as lr
  rows=[]
  def bounded(argv,input=None,env=None,**kw):
   action=json.loads(input)['action'];limit=256*1024**2 if action in ['resolve','point','inspect'] else 2*1024**3
   p,row=n.run(list(map(str,argv)),115,'actual-prior-'+action,input=input,env=env,limit=limit,disk_monitor=False);rows.append({'action':action,**row});(n.Q/'loose-regression-resources.json').write_text(json.dumps(rows,indent=2));return p
  lr.prior.subprocess=types.SimpleNamespace(run=bounded);result=lr.prior.run(EXE,fixtures/'loose');assert len(result['cases'])==24 and result['events']==282
 else:raise ValueError(mode)
 (n.Q/(mode+'-result.json')).write_text(json.dumps({'epoch':time.time(),'status':'passed','mode':mode,'result':result,'source_binding':n.sourcecheck(),'ownership':n.ownership(),'adapter_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},indent=2))
 return result
if __name__=='__main__':run_mode(sys.argv[1])


import sys,json
from pathlib import Path
Q=Path('/home/spenser/file-native-p-linux-20261020/qualification');sys.path.insert(0,str(Q));import native_control_v2 as n;sys.modules['native_control']=n;import native_adapter_v2 as a;a.run_mode(sys.argv[1])

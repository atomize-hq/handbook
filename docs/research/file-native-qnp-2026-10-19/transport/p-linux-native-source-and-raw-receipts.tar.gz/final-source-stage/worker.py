
import os,sys,json,time,stat,hashlib,tarfile,subprocess,threading,signal,shutil
from pathlib import Path,PurePosixPath
ROOT=Path('/home/spenser/file-native-p-linux-20261020');R=ROOT/'final-source-stage';S=ROOT/'source-final';T=ROOT/'target-final';sys.path.insert(0,str(ROOT/'qualification'));import native_control_tiny as n
MODE=sys.argv[1];CONF=json.loads((R/(MODE+'-config.json')).read_text());assert time.time()<CONF['functional_deadline_epoch'];M=json.loads((R/'source-manifest.json').read_text());assert M['core_commit']=='d70f3864f2888d46d9112213b4a03f8d82745a8e';files={x['path']:x for x in M['files']};core={x['path']:x for x in M['final_core_files']};assert len(files)==145 and len(core)==18
assert hashlib.sha256((R/'source.tar.gz').read_bytes()).hexdigest()=='0082767199baa9f9e06ea70f9efa40f5a9a086b71d2f236cf7356238ca1bdf64';assert hashlib.sha256((R/'source-manifest.json').read_bytes()).hexdigest()=='0c636670f89bd11086b139b966452d4f852e537d06997aa1f6649af5ad01d29a'
def digest(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(65536),b''):h.update(b)
 return h.hexdigest()
def write(name,obj):
 data=json.dumps(obj,indent=2).encode();assert len(data)<131072;assert not (R/name).exists();(R/name).write_bytes(data)
def sourcecheck():
 rows=[]
 for rel,x in files.items():
  p=S/rel;b=p.read_bytes();h=hashlib.sha256(b).hexdigest();g=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();assert len(b)==x['bytes'] and h==x['sha256'] and g==x['git_blob_sha1'];rows.append({'path':rel,'bytes':len(b),'sha256':h,'git_blob_sha1':g,'is_final_core':rel in core})
 for rel,x in core.items():assert files[rel]==x
 return {'core':M['core_commit'],'harness':M['harness_commit'],'all145_names_bytes_SHA256_GitblobSHA1_match':True,'all18_final_core_match':True,'files':rows}
def own():
 value=n.ownership();value['combined_bound_bytes']=value['native']['bytes']+value['cache_positive_growth_bytes']+CONF['controller_shared_future_bound_bytes'];return value
old_source=n.sourcecheck();old_archive=digest(ROOT/'preservation-artifact/two-roots.tar.gz');assert old_archive=='d6f3eca1abd4bb74ca393c9c3ef743abdf5c6061bb98aad74ac938769c2cdbc7'
if MODE=='build':
 assert not S.exists() and not T.exists() and not (ROOT/'bin/candidate-linux-final').exists()
 actual=own();forecast=actual['combined_bound_bytes']+201326592+6291456+2097152;assert forecast<=268435456 and actual['combined_bound_files']+2000<20000
 write('build-admission.json',{'epoch':time.time(),'current_ownership':actual,'whole_operation_forecast_bytes':forecast,'target_max_bytes':201326592,'new_source_transport_bin_bound_bytes':6291456,'extra_returns_bound_bytes':2097152,'admitted':True})
 with tarfile.open(R/'source.tar.gz','r:gz') as tar:
  seen=set()
  for member in tar.getmembers():
   p=PurePosixPath(member.name);assert member.isfile() and not p.is_absolute() and '..' not in p.parts and ':' not in member.name and '\\' not in member.name and member.name in files and member.name not in seen;b=tar.extractfile(member).read();x=files[member.name];assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256'] and hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==x['git_blob_sha1'];seen.add(member.name)
  assert seen==set(files);S.mkdir()
  for member in tar.getmembers():
   p=S/member.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(tar.extractfile(member).read())
else:
 assert MODE=='unit' and CONF['fresh_total_actual_before_unit_bytes']<=170917888 and CONF['prospective_unit_total_bytes']<=268435456
 build=json.loads((R/'build-result.json').read_text());assert build['returncode']==0;assert digest(ROOT/'bin/candidate-linux-final')==build['native_final_binary']['sha256']
before=sourcecheck();write(MODE+'-source-before.json',before)
# Fresh metadata backup before normal offline Cargo bookkeeping updates; registry payloads untouched.
p=Path('/home/spenser/.cargo/.global-cache');backup=R/(MODE+'-global-cache-before.bin');assert not backup.exists();shutil.copyfile(p,backup);write(MODE+'-Cargo-metadata-backup.json',{'path':str(p),'backup':str(backup),'bytes':p.stat().st_size,'sha256':digest(p)})
B='/home/spenser/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin';env=dict(os.environ,RUSTUP_AUTO_INSTALL='0',RUSTUP_TOOLCHAIN='stable-x86_64-unknown-linux-gnu',RUSTC=B+'/rustc',CARGO_HOME='/home/spenser/.cargo',CARGO_NET_OFFLINE='true',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='2',PYTHONDONTWRITEBYTECODE='1');env['PATH']=B+':'+env.get('PATH','');command=[B+'/cargo','build' if MODE=='build' else 'test','--locked','--offline','--workspace','--release','-j2','--target-dir',str(T)];fout=(R/(MODE+'.stdout')).open('xb');ferr=(R/(MODE+'.stderr')).open('xb');start=time.time();p=subprocess.Popen(command,cwd=S/'docs/research/file-native-incremental-engine-experiment-2026-10-18',env=env,stdout=fout,stderr=ferr);violations=[];samples=[]
while p.poll() is None:
 value=own();target=n.census(T);fixture=n.census(S/'docs/research/file-native-incremental-engine-experiment-2026-10-18/target');samples.append({'epoch':time.time(),'ownership':value,'target_bytes':target['bytes'],'synthetic_bytes':fixture['bytes']})
 if value['combined_bound_bytes']>CONF['total_soft_stop_bytes']:violations.append('total-soft-stop-before256MiB')
 if value['combined_bound_files']>19500:violations.append('file-soft-stop-before20k')
 if target['bytes']>CONF['target_soft_stop_bytes']:violations.append('target-soft-stop')
 if MODE=='unit' and target['bytes']>CONF['unit_target_before_bytes']+8388608:violations.append('unit-target-growth8MiB')
 if fixture['bytes']>88080384:violations.append('unit-synthetic84MiB')
 if value['free_bytes']<20*1024**3:violations.append('native-free20GiB')
 if time.time()>=CONF['functional_deadline_epoch']:violations.append('fixed-stage-cutoff')
 if violations:
  p.kill();break
 time.sleep(.5)
rc=p.wait(timeout=4);fout.close();ferr.close();assert sourcecheck()==before and n.sourcecheck()==old_source and digest(ROOT/'preservation-artifact/two-roots.tar.gz')==old_archive;write(MODE+'-source-after.json',sourcecheck());frozen=None
if MODE=='build' and rc==0 and not violations:
 source=T/'release/file-native-incremental';dest=ROOT/'bin/candidate-linux-final';assert not dest.exists();source_used=874196+(R/'source.tar.gz').stat().st_size+(R/'source-manifest.json').stat().st_size+47392+294018+source.stat().st_size;assert source_used<=6291456 and own()['combined_bound_bytes']+source.stat().st_size<=268435456;shutil.copyfile(source,dest);dest.chmod(0o755);frozen={'path':str(dest),'bytes':dest.stat().st_size,'sha256':digest(dest),'core':M['core_commit'],'all145_and_core18_bound':True,'executed':False}
if MODE=='unit':frozen=json.loads((R/'build-result.json').read_text())['native_final_binary'];assert digest(Path(frozen['path']))==frozen['sha256']
result={'mode':MODE,'start_epoch':start,'completed_epoch':time.time(),'command':command,'returncode':rc,'seconds':time.time()-start,'violations':violations,'native_final_binary':frozen,'source145_core18_before_after_match':True,'old_source139_old_bin_archive_unchanged':True,'ownership_after':own(),'target':n.census(T),'new_synthetic_fixture':n.census(S/'docs/research/file-native-incremental-engine-experiment-2026-10-18/target'),'ownership_samples':samples,'Cargo_metadata_before_backup':str(backup),'native_qualification_pass':None,'full_capsule_or_cleanup_started':False};write(MODE+'-result.json',result);print(json.dumps(result,indent=2));assert rc==0 and not violations

import os,sys,time,json,signal,threading
from pathlib import Path
R=Path('/home/spenser/file-native-p-linux-20261020/recovery-only-20261020T054348Z');sys.path.insert(0,str(R));import stage_control_v2 as c
pid=int(sys.argv[1]);supervisor=int(sys.argv[2]);seconds=float(sys.argv[3]);limit=int(sys.argv[4]);output=Path(sys.argv[5]);disk=bool(int(sys.argv[6]));known={};groups={pid};bad=[];peak=None;missing=0;samples=0;last_disk=0;state_lock=threading.RLock();expired=threading.Event()
def kill(reason):
 with state_lock:
  if reason and reason not in bad:bad.append(reason)
  for pg in list(groups):
   if pg==os.getpgrp():continue
   try:os.killpg(pg,signal.SIGKILL)
   except ProcessLookupError:pass
def deadline():expired.set();kill('independent-whole-tree-timeout')
timer=threading.Timer(seconds,deadline);timer.daemon=True;timer.start()
while True:
 table={}
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   s=(p/'stat').read_text();r=s[s.rfind(')')+2:].split();table[int(p.name)]={'state':r[0],'ppid':int(r[1]),'pgrp':int(r[2]),'start':int(r[19]),'rss':int(r[21])*os.sysconf('SC_PAGE_SIZE')}
  except (OSError,ValueError,IndexError):pass
 with state_lock:
  owned={p for p,v in table.items() if v['pgrp'] in groups or p==pid or (p in known and known[p]==v['start'])};changed=True
  while changed:
   more={p for p,v in table.items() if v['ppid'] in owned};changed=not more<=owned;owned|=more
  for p in owned:known[p]=table[p]['start'];groups.add(table[p]['pgrp'])
 live={p for p in owned if table[p]['state']!='Z'};ids=live|({supervisor,os.getpid()}&table.keys());aggregate=sum(table[p]['rss'] for p in ids);value=aggregate if live and aggregate>0 else None;samples+=1
 if value is None:missing+=1
 else:peak=value if peak is None else max(peak,value)
 try:c.append_record(R/'rss-samples.jsonl.gz',{'epoch':time.time(),'root':pid,'aggregate_RSS':value,'pids':sorted(live)})
 except Exception:kill('raw-resource-report-prewrite-bound');break
 if not live:break
 if value is not None and value>3221225472:kill('native-aggregate3GiB')
 if any(table[p]['rss']>limit for p in live):kill('process-RSS-limit')
 if time.time()>=c.CUTOFF:kill('fixed-stage-functional-cutoff')
 if os.statvfs(c.ROOT).f_bavail*os.statvfs(c.ROOT).f_frsize<21474836480:kill('native-free20GiB')
 if disk and time.monotonic()-last_disk>1:
  x=c.ownership();last_disk=time.monotonic()
  if x['combined_bound_bytes']>c.CFG['lane_cap_bytes']-1048576:kill('total-soft-stop')
  if x['combined_bound_files']>c.CFG['lane_files_cap']-50:kill('file-soft-stop')
  if x['fixtures']['bytes']>c.CFG['fixture_cap_bytes']:kill('combined-fixture224MiB')
  if x['new_fixture']['bytes']>c.CFG['new_fixture_cap_bytes']:kill('fresh-fixture52MiB')
 if bad:break
 if pid not in live:kill(None);break
 time.sleep(.1)
timer.cancel();time.sleep(.1);remaining=[]
for p,start in known.items():
 try:
  s=Path(f'/proc/{p}/stat').read_text();r=s[s.rfind(')')+2:].split()
  if int(r[19])==start and r[0]!='Z':remaining.append(p)
 except (OSError,ValueError,IndexError):pass
out={'root_pid':pid,'supervisor_pid':supervisor,'watchdog_pid':os.getpid(),'seconds_limit':seconds,'per_process_limit':limit,'aggregate_limit':3221225472,'observed_aggregate_peak':peak,'exact_continuous_peak':None,'missing_samples':missing,'sample_count':samples,'violations':bad,'remaining_live_pids':remaining,'timer_independent_of_census_and_worker':True};data=json.dumps(out,separators=(',',':')).encode();assert len(data)<8192;assert c.report_bytes()+len(data)<c.CFG['reports_cap_bytes']-c.CFG['controller_future_reports_reserve'];assert not output.exists();output.write_bytes(data)

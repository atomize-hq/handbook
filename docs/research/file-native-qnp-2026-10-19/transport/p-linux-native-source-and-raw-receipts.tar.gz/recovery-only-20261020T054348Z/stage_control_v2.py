import os,sys,json,time,hashlib,gzip,subprocess,threading,signal,contextlib,fcntl
from pathlib import Path
ROOT=Path('/home/spenser/file-native-p-linux-20261020');R=ROOT/'recovery-only-20261020T054348Z';F=R/'fixture-complete';FAILED=R/'fixture';CFG=json.loads((R/'config.json').read_text());CUTOFF=CFG['functional_cutoff_epoch'];EXE=ROOT/'bin/candidate-linux-final';EXPECTED='a8501737ca4fdd5cfc177620860c1ae103d56f2e9b2151104a922df511a3d84b';lock=threading.RLock();local=threading.local();counter=0;reservations={};counts={}
class Refused(RuntimeError):pass
def census(p):
 bs=fs=0;p=Path(p)
 if not p.exists():return {'bytes':0,'files':0}
 for b,ds,ns in os.walk(p,followlinks=False):
  for n in ns:
   q=Path(b)/n
   try:
    if q.is_symlink():raise Refused('unexpected-owned-symlink:'+str(q))
    bs+=q.stat().st_size;fs+=1
   except FileNotFoundError:pass
 return {'bytes':bs,'files':fs}
def report_bytes():
 total=0
 for base,ds,ns in os.walk(R):
  if Path(base)==R:ds[:]=[d for d in ds if d not in ['fixture','fixture-complete']]
  for name in ns:
   p=Path(base)/name
   try:total+=p.stat().st_size
   except FileNotFoundError:pass
 return total
def ownership():
 stage=census(R);fresh=census(F);failed=census(FAILED);fresh={'bytes':fresh['bytes']+failed['bytes'],'files':fresh['files']+failed['files']};native={'bytes':CFG['frozen_native_base_bytes']+stage['bytes'],'files':CFG['frozen_native_base_files']+stage['files']};return {'native':native,'new_fixture':fresh,'fixtures':{'bytes':fresh['bytes']+CFG['old_fixture_bytes'],'files':fresh['files']+CFG['old_fixture_files']},'combined_bound_bytes':native['bytes']+CFG['cache_growth_bytes']+CFG['controller_shared_future_bound_bytes'],'combined_bound_files':native['files']+CFG['cache_new_files']+CFG['controller_future_files'],'native_report_bytes':report_bytes(),'free_bytes':os.statvfs(ROOT).f_bavail*os.statvfs(ROOT).f_frsize}
def append_record(file,row,emergency=False):
 raw=(json.dumps(row,separators=(',',':'))+'\n').encode();data=gzip.compress(raw,compresslevel=5,mtime=0) if str(file).endswith('.gz') else raw
 with (R/'.io.lock').open('ab') as lk:
  fcntl.flock(lk,fcntl.LOCK_EX)
  if report_bytes()+len(data)+65536>CFG['reports_cap_bytes']:raise Refused('new-stage-report-16MiB-prewrite')
  if CFG['frozen_combined_base_bound_bytes']+CFG['new_fixture_cap_bytes']+report_bytes()+len(data)>CFG['lane_cap_bytes']:raise Refused('new-stage-total280MiB-prewrite')
  with Path(file).open('ab') as f:f.write(data)
  fcntl.flock(lk,fcntl.LOCK_UN)
@contextlib.contextmanager
def reserve(bs,files,name,covered=False):
 if getattr(local,'covered',0):yield;return
 global counter
 with lock:
  x=ownership();rb=sum(v[0] for v in reservations.values());rf=sum(v[1] for v in reservations.values())
  if x['combined_bound_bytes']+rb+bs+65536>CFG['lane_cap_bytes']:raise Refused('whole-op-total280MiB:'+name)
  if x['new_fixture']['bytes']+rb+bs>CFG['new_fixture_cap_bytes']:raise Refused('whole-op-fresh52MiB:'+name)
  if x['fixtures']['bytes']+rb+bs>CFG['fixture_cap_bytes']:raise Refused('whole-op-combined224MiB:'+name)
  if x['combined_bound_files']+rf+files+20>CFG['lane_files_cap']:raise Refused('whole-op-files30k:'+name)
  if x['free_bytes']<21474836480:raise Refused('native-free20GiB')
  counter+=1;key=(os.getpid(),counter);reservations[key]=(bs,files);append_record(R/'operation-forecasts.jsonl.gz',{'epoch':time.time(),'name':name,'max_new_bytes':bs,'max_new_files':files,'existing':x,'other_reserved_bytes':rb})
 if covered:local.covered=getattr(local,'covered',0)+1
 try:yield
 finally:
  if covered:local.covered-=1
  with lock:reservations.pop(key,None)
def engine_forecast(payload):
 root=Path(payload['root']).resolve();assert root.is_relative_to(F)
 action=payload['action']
 if action=='init':counts[str(root)]=payload.get('count',16);assert counts[str(root)] in [16,128]
 if action in ['resolve','point','inspect','dump','audit']:return 65536,32
 n=counts.get(str(root),128);return (8388608,768) if n>16 else (2097152,384)
def atomic_events(path,text,encoding='utf-8'):
 global counter
 data=text.encode(encoding);assert len(data)<=CFG['events_json_bound_bytes'];old=path.stat().st_size if path.exists() else 0
 with (R/'.io.lock').open('ab') as lk:
  fcntl.flock(lk,fcntl.LOCK_EX);x=ownership();peak=report_bytes()+len(data)
  if peak+65536>CFG['reports_cap_bytes']:raise Refused('actual-atomic-event-temp-16MiB')
  if x['combined_bound_bytes']+len(data)+65536>CFG['lane_cap_bytes']:raise Refused('actual-atomic-event-temp-total280MiB')
  if x['new_fixture']['bytes']+max(0,len(data)-old)>CFG['new_fixture_cap_bytes']:raise Refused('actual-events-committed-fixture52MiB')
  counter+=1;temp=R/('.events-next-'+str(os.getpid())+'-'+str(counter)+'.utf8-json.tmp');assert not temp.exists()
  with temp.open('xb') as f:assert f.write(data)==len(data);f.flush();os.fsync(f.fileno())
  assert json.loads(temp.read_text(encoding='utf-8'))==json.loads(text);os.replace(temp,path);fcntl.flock(lk,fcntl.LOCK_UN)
 append_record(R/'atomic-events-writes.jsonl',{'epoch':time.time(),'path':str(path),'format':'UTF-8 JSON original F events.json','old_bytes':old,'new_bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'report_with_temp_preflight_bytes':peak,'whole_with_temp_preflight_bytes':x['combined_bound_bytes']+len(data),'rows':len(json.loads(text))});return len(text)
def run(argv,seconds,name,input=None,env=None,limit=2147483648,disk=False):
 global counter
 if time.time()>=CUTOFF:raise Refused('new-recovery-stage-cutoff')
 with lock:counter+=1;ident=f'{name}-{os.getpid()}-{counter}'
 process=R/'process';process.mkdir(exist_ok=True);guardfile=process/(ident+'.guard.json');start=time.monotonic();p=subprocess.Popen(list(map(str,argv)),stdin=subprocess.PIPE if input is not None else subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,start_new_session=True);g=subprocess.Popen([sys.executable,'-B',str(R/'watchdog-v2.py'),str(p.pid),str(os.getpid()),str(min(seconds,max(.01,CUTOFF-time.time()))),str(limit),str(guardfile),str(int(disk))],start_new_session=True)
 try:out,err=p.communicate(input,timeout=min(seconds+4,max(.01,CUTOFF-time.time()+4)))
 except subprocess.TimeoutExpired:
  try:os.killpg(p.pid,signal.SIGKILL)
  except ProcessLookupError:pass
  out,err=p.communicate(timeout=3)
 g.wait(timeout=6);guard=json.loads(guardfile.read_text());append_record(R/'raw-process-events.jsonl.gz',{'epoch':time.time(),'name':name,'argv':list(map(str,argv)),'input':input.decode() if input is not None else None,'env_EXP':{k:v for k,v in (env or {}).items() if k.startswith('EXP_')},'exit':p.returncode,'seconds':time.monotonic()-start,'stdout':out.decode(),'stderr':err.decode(),'stdout_sha256':hashlib.sha256(out).hexdigest(),'stderr_sha256':hashlib.sha256(err).hexdigest(),'guard':str(guardfile)})
 if guard['violations'] or guard['remaining_live_pids']:raise Refused('native-guard-failure:'+name)
 return subprocess.CompletedProcess(argv,p.returncode,out,err),{'seconds':time.monotonic()-start,'guard':guard}

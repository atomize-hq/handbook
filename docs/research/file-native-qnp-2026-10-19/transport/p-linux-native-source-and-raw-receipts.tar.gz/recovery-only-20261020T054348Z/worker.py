import os,sys,json,time,hashlib,gzip,importlib.util,subprocess,types,stat,shutil,contextlib
from pathlib import Path
ROOT=Path('/home/spenser/file-native-p-linux-20261020');R=ROOT/'recovery-only-20261020T054348Z';sys.path.insert(0,str(R));import stage_control as c
S=ROOT/'source-final';E=S/'docs/research';sys.path.insert(0,str(E/'file-native-navigation-2026-10-19'));sys.path.insert(0,str(E/'file-native-recovery-reclamation-2026-10-19'))
def digest(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for x in iter(lambda:f.read(65536),b''):h.update(x)
 return h.hexdigest()
def source_check():
 m=json.loads((ROOT/'final-source-stage/source-manifest.json').read_text());assert m['core_commit']=='d70f3864f2888d46d9112213b4a03f8d82745a8e' and len(m['files'])==145 and len(m['final_core_files'])==18
 for row in m['files']:
  b=(S/row['path']).read_bytes();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'] and hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==row['git_blob_sha1']
 old=json.loads((ROOT/'preparation/source-manifest.json').read_text())
 for row in old['files']:
  p=ROOT/'source'/row['path'];assert p.stat().st_size==row['bytes'] and digest(p)==row['sha256']
 assert digest(c.EXE)==c.EXPECTED and digest(ROOT/'bin/candidate-linux')=='063342e6bbd6bfb49729ff856462b9fdaa4a8d7cdf51d941d2a60f356d2c0cbe'
 qn=[]
 for name in ['file-native-n-linux-20261019','file-native-q-linux-20261019-final']:
  p=Path('/home/spenser')/name;m0=json.loads((p/'source-manifest.json').read_text());fs=m0.get('files',m0)
  for rel,x in fs.items():assert (p/'source'/rel).stat().st_size==x['bytes'] and digest(p/'source'/rel)==x['sha256']
  qn.append({'root':str(p),'source_files':len(fs),'all_match':True})
 return {'source145_core18_match':True,'old_source139_match':True,'old063_sha256':digest(ROOT/'bin/candidate-linux'),'new_a850_sha256':digest(c.EXE),'old_QN_source_bindings':qn}
def frozen_old_tree():
 rows=[]
 for b,ds,ns in os.walk(ROOT,followlinks=False):
  if Path(b)==ROOT:ds[:]=[d for d in ds if d!=R.name]
  for name in ns:
   p=Path(b)/name;assert not p.is_symlink();rows.append([str(p.relative_to(ROOT)),p.stat().st_size,digest(p)])
 rows.sort();return rows
assert time.time()<c.CUTOFF and not c.F.exists();before=source_check();old_tree=frozen_old_tree();(R/'old-native-tree-before.json.gz').write_bytes(gzip.compress(json.dumps(old_tree,separators=(',',':')).encode(),mtime=0));(R/'source-before.json').write_text(json.dumps(before,indent=2));current=c.ownership();whole=current['combined_bound_bytes']+54525952+16777216;assert whole<=293601280 and current['combined_bound_files']+7000<30000
(R/'launch-admission.json').write_text(json.dumps({'epoch':time.time(),'current_ownership':current,'complete_remaining_forecast_bytes':whole,'52MiB_fresh_fixture_includes_committed_events_JSON':True,'16MiB_reports_temp_excludes_fixture':True,'old_plus_new_atomic_events_coexistence_preflighted':True,'old_partial_compressed_encoding_frozen':True},indent=2))
# Only the original F event report is atomically adapted; format remains UTF-8 JSON.
_original_text=Path.write_text;_original_bytes=Path.write_bytes

def events_text(self,text,*args,**kw):
 if self==c.F/'events.json':return c.atomic_events(self,text,kw.get('encoding') or 'utf-8')
 if self.is_relative_to(c.F):
  with c.reserve(len(text.encode(kw.get('encoding') or 'utf-8'))+65536,4,'F-write-text:'+self.name):return _original_text(self,text,*args,**kw)
 return _original_text(self,text,*args,**kw)
def fixture_bytes(self,data):
 if self.is_relative_to(c.F):
  with c.reserve(len(data)+65536,4,'F-write-bytes:'+self.name):return _original_bytes(self,data)
 return _original_bytes(self,data)
Path.write_text=events_text;Path.write_bytes=fixture_bytes
import operational_backup as backup
spec=importlib.util.spec_from_file_location('frozen_actual_F_recovery',E/'file-native-recovery-reclamation-2026-10-19/capsule.py');prior=importlib.util.module_from_spec(spec);spec.loader.exec_module(prior);_capture=prior.capture;_restore=prior.restore

def capture(root,dest,*args,**kw):
 root=Path(root);assert root.is_relative_to(c.F) and Path(dest).is_relative_to(c.F);count=total=framed=inventory=0
 for p in backup.paths(root):
  rel=p.relative_to(root).as_posix()
  if rel in backup.EXCLUDED:continue
  size=p.stat().st_size;count+=1;total+=size;framed+=12+len(rel.encode())+size+32;inventory+=len(json.dumps({'path':rel,'bytes':size,'sha256':'0'*64},separators=(',',':')).encode())+1
 # Streaming gzip needs no uncompressed filesystem duplicate. This bound includes
 # incompressible framing expansion, full original inventory and manifest.
 bound=(framed+6)*101//100+inventory+131072
 with c.reserve(bound,count+16,'complete-F-capture:'+str(dest),covered=True):return _capture(root,dest,*args,**kw)
def restore(source,dest,*args,**kw):
 source=Path(source);dest=Path(dest);m=json.loads((source/'manifest.json').read_bytes());assert dest.is_relative_to(c.F);rows=[json.loads(line) for line in (source/'files.jsonl').read_text().splitlines()];assert sum(x['bytes'] for x in rows)==m['logical_bytes'] and len(rows)==m['files'];c.counts[str(dest.resolve())]=c.counts.get(str(Path(m['original']).resolve()),128)
 with c.reserve(m['logical_bytes']+65536,m['files']+16,'complete-F-restore-raw-length:'+str(dest),covered=True):return _restore(source,dest,*args,**kw)
prior.capture=capture;prior.restore=restore
rows=[]
def bounded(argv,input=None,env=None,**kwargs):
 payload=json.loads(input);bs,files=c.engine_forecast(payload);limit=268435456 if payload['action'] in ['resolve','point','inspect'] else 2147483648
 with c.reserve(bs,files,'original-F-engine:'+payload['action']):p,res=c.run(list(map(str,argv)),115,'F-'+payload['action'],input=input,env=env,limit=limit)
 rows.append({'action':payload['action'],'exit':p.returncode,'seconds':res['seconds'],'guard':res['guard']});return p
prior.subprocess=types.SimpleNamespace(run=bounded)
result=prior.run(c.EXE,c.F);assert len(result['cases'])==24 and result['events']==282
# Report must be the original UTF-8 JSON file, not compressed bytes or an alias.
raw=(c.F/'events.json').read_bytes();assert not raw.startswith(b'\x1f\x8b');events=json.loads(raw.decode('utf-8'));assert len(events)==282 and not (c.F/'events.json.gz').exists();after=source_check();assert after==before;after_tree=frozen_old_tree();assert after_tree==old_tree
summary={'epoch':time.time(),'status':'FRESH_ORIGINAL_F_24_CASES_282_EVENTS_PASS','core':'d70f3864f2888d46d9112213b4a03f8d82745a8e','exe_sha256':c.EXPECTED,'fixture':str(c.F),'cases':result['cases'],'events':282,'original_events_UTF8_JSON':{'path':str(c.F/'events.json'),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'rows':282,'compressed':False},'source_before_after':after,'old_entire_native_tree_unchanged_including_compressed_prefix':True,'old_tree_files':len(old_tree),'old_tree_inventory_path':str(R/'old-native-tree-before.json.gz'),'old_tree_inventory_sha256':digest(R/'old-native-tree-before.json.gz'),'ownership':c.ownership(),'resources':rows,'new_stage_only_repeated_F_recovery_authorized':True,'old_phase_partial_not_relabelled':True,'global_P_pass':None};(R/'result.json').write_text(json.dumps(summary,indent=2));print(json.dumps({k:v for k,v in summary.items() if k not in ['resources','cases']},indent=2))
